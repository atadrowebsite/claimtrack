<?php
if (!defined('ABSPATH')) { exit; }

class ClaimTrack_DB {
    const DB_VERSION = '1.6.2';

    public static function tables() {
        global $wpdb;
        return array(
            'units'     => $wpdb->prefix . 'claimtrack_units',
            'programs'  => $wpdb->prefix . 'claimtrack_programs',
            'providers' => $wpdb->prefix . 'claimtrack_providers',
            'entries'   => $wpdb->prefix . 'claimtrack_entries',
            'debitur'   => $wpdb->prefix . 'claimtrack_debitur_nominatif',
        );
    }

    public static function activate() {
        self::install_schema();
        self::seed_master_data();
        self::seed_demo_data();
        self::seed_demo_debitur_kdp();
        self::add_roles_caps();
        update_option('claimtrack_db_version', self::DB_VERSION);
        if (!get_option('claimtrack_settings')) {
            add_option('claimtrack_settings', array(
                'dashboard_title' => 'DASHBOARD MONITORING KLAIM DALAM PROSES',
                'department'      => 'Commercial Credit Operation Department',
                'region_label'    => 'REGION 18',
                'input_unit'      => 'Juta Rupiah',
                'turnstile_enabled'   => 0,
                'turnstile_site_key'  => '',
                'turnstile_secret_key'=> '',
                'admin_whatsapp'       => '',
                'logo_id'              => 0,
                'logo_url'             => '',
                'color_sidebar'        => '#0c2545',
                'color_sidebar_deep'   => '#081a31',
                'color_header'         => '#0b2038',
                'color_nav_active'     => '#153a66',
                'color_sidebar_line'   => '#163863',
                'color_workspace'      => '#dce3ed',
                'color_panel'          => '#ffffff',
                'color_kpi'            => '#229e55',
                'color_kpi_dark'       => '#198644',
                'color_kpi_border'     => '#33cb6d',
                'color_button'         => '#0f4277',
                'color_table'          => '#0f62ac',
                'color_table_sub'      => '#1573c9',
                'color_phase_table'    => '#2a124d',
                'color_phase_table_sub'=> '#351960',
                'color_danger'         => '#e74c3c',
                'color_text'           => '#333333',
                'color_muted'          => '#8fa0b5',
                'color_login_blue'     => '#084c7a',
                'color_login_footer'   => '#000000',
                'color_login_button'   => '#0877c9',
            ));
        }

        /*
         * Do not create Pages or flush rewrite rules from the activation callback.
         * Depending on how WordPress activates/replaces a plugin, the rewrite
         * subsystem may not be ready. The next init request will finish the work.
         */
        update_option('claimtrack_pages_sync_pending', 1, false);
        update_option('claimtrack_rewrite_flush_pending', 1, false);
        self::mark_cpt_sync_dirty();
    }

    public static function deactivate() {
        flush_rewrite_rules();
    }

    public static function maybe_upgrade() {
        if (get_option('claimtrack_db_version') !== self::DB_VERSION) {
            self::install_schema();
            self::seed_master_data();
            self::seed_demo_data();
            self::add_roles_caps();
            update_option('claimtrack_db_version', self::DB_VERSION);
            update_option('claimtrack_pages_sync_pending', 1, false);
            update_option('claimtrack_rewrite_flush_pending', 1, false);
        }

        /*
         * Self-healing master data is safe on init. Managed WordPress Pages are
         * also repaired here, but only after WP_Rewrite exists.
         */
        self::seed_master_data();
        self::add_roles_caps();

        // Isi contoh profesional hanya pada bagian yang masih kosong atau masih
        // berisi seed demo bawaan. Data input pengguna tidak pernah ditimpa.
        self::seed_professional_demo_content();

        // Pastikan berita lama langsung dapat dikomentari setelah upgrade.
        if (get_option('claimtrack_news_comments_enabled') !== '1') {
            global $wpdb;
            $wpdb->query("UPDATE {$wpdb->posts} SET comment_status='open' WHERE post_type='ct_news' AND post_status='publish'");
            update_option('claimtrack_news_comments_enabled', '1', false);
        }

        if (!self::rewrite_is_ready()) {
            update_option('claimtrack_pages_sync_pending', 1, false);
            return;
        }

        self::ensure_app_pages();
        self::set_as_front_page();
        delete_option('claimtrack_pages_sync_pending');

        if (get_option('claimtrack_rewrite_flush_pending')) {
            flush_rewrite_rules(false);
            delete_option('claimtrack_rewrite_flush_pending');
        }

        // CPT di wp-admin merupakan mirror database ClaimTrack. Sinkronkan ketika
        // plugin baru di-upgrade, restore dilakukan, atau data berubah.
        if (get_option('claimtrack_cpt_sync_pending') || get_option('claimtrack_cpt_mirror_version') !== self::DB_VERSION) {
            self::sync_cpt_mirror(true);
        }
    }

    /**
     * WordPress core permalink helpers depend on the global WP_Rewrite object.
     * This guard prevents wp_insert_post()/wp_update_post() from running during
     * plugins_loaded or another early bootstrap stage.
     */
    private static function rewrite_is_ready() {
        global $wp_rewrite;
        return ($wp_rewrite instanceof WP_Rewrite);
    }

    private static function install_schema() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $t = self::tables();

        $sql_units = "CREATE TABLE {$t['units']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            code VARCHAR(40) NOT NULL,
            name VARCHAR(160) NOT NULL,
            sort_order INT NOT NULL DEFAULT 0,
            active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY code (code),
            KEY active_sort (active, sort_order)
        ) $charset;";

        $sql_programs = "CREATE TABLE {$t['programs']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            code VARCHAR(40) NOT NULL,
            phase_label VARCHAR(80) NOT NULL DEFAULT '',
            name VARCHAR(160) NOT NULL,
            color VARCHAR(20) NOT NULL DEFAULT '#22b455',
            dashboard_order INT NOT NULL DEFAULT 0,
            show_dashboard TINYINT(1) NOT NULL DEFAULT 0,
            active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY code (code),
            KEY active_order (active, dashboard_order)
        ) $charset;";

        $sql_providers = "CREATE TABLE {$t['providers']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            code VARCHAR(40) NOT NULL,
            name VARCHAR(160) NOT NULL,
            sort_order INT NOT NULL DEFAULT 0,
            active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY code (code),
            KEY active_sort (active, sort_order)
        ) $charset;";

        $sql_entries = "CREATE TABLE {$t['entries']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            unit_id BIGINT UNSIGNED NOT NULL,
            program_id BIGINT UNSIGNED NOT NULL,
            provider_id BIGINT UNSIGNED NOT NULL,
            year SMALLINT UNSIGNED NOT NULL,
            month TINYINT UNSIGNED NOT NULL,
            week TINYINT UNSIGNED NOT NULL,
            amount_million DECIMAL(20,2) NOT NULL DEFAULT 0,
            note VARCHAR(255) NOT NULL DEFAULT '',
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY entry_key (unit_id, program_id, provider_id, year, month, week),
            KEY period_program (year, month, program_id),
            KEY unit_period (unit_id, year, month)
        ) $charset;";


        $sql_debitur = "CREATE TABLE {$t['debitur']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            unit_id BIGINT UNSIGNED NOT NULL,
            program_id BIGINT UNSIGNED NOT NULL,
            provider_id BIGINT UNSIGNED DEFAULT 0,
            nama_nasabah VARCHAR(180) NOT NULL,
            nomor_klaim VARCHAR(80) NOT NULL DEFAULT '',
            amount_million DECIMAL(20,2) NOT NULL DEFAULT 0,
            status_klaim VARCHAR(80) NOT NULL DEFAULT 'Dalam Proses',
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY unit_program (unit_id, program_id)
        ) $charset;";

        dbDelta($sql_units);
        dbDelta($sql_programs);
        dbDelta($sql_providers);
        dbDelta($sql_entries);
        dbDelta($sql_debitur);
    }


    /**
     * Demo Data Debitur KDP untuk instalasi baru.
     * Data ini dapat dihapus melalui SW Admin > Data Debitur.
     */
    private static function seed_demo_debitur_kdp() {
        global $wpdb;
        $t=self::tables();
        $count=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['debitur']}");
        if($count>0){ return; }
        $unit=(int)$wpdb->get_var("SELECT id FROM {$t['units']} ORDER BY id ASC LIMIT 1");
        $program=(int)$wpdb->get_var("SELECT id FROM {$t['programs']} WHERE code='KDP' LIMIT 1");
        $provider=(int)$wpdb->get_var("SELECT id FROM {$t['providers']} ORDER BY id ASC LIMIT 1");
        if(!$unit || !$program){ return; }
        $rows=array(
            array('Debitur Demo KDP 001','KDP-2025-0001',125.50,'Monitoring JT Tempo Klaim'),
            array('Debitur Demo KDP 002','KDP-2025-0002',80.00,'Pra Klaim'),
            array('Debitur Demo KDP 003','KDP-2025-0003',210.00,'Best Performance'),
            array('Debitur Demo KDP 004','KDP-2025-0004',65.75,'Klaim Ditolak 2025')
        );
        foreach($rows as $r){
            $wpdb->insert($t['debitur'],array(
                'unit_id'=>$unit,'program_id'=>$program,'provider_id'=>$provider,
                'nama_nasabah'=>$r[0],'nomor_klaim'=>$r[1],
                'amount_million'=>$r[2],'status_klaim'=>$r[3],
                'created_at'=>self::now(),'updated_at'=>self::now()
            ));
        }
    }

    private static function now() {
        return current_time('mysql');
    }

    private static function seed_master_data() {
        global $wpdb;
        $t = self::tables();
        $now = self::now();

        $units = array(
            array('ABEPURA', 'Abepura'), array('BIAK', 'Biak'), array('BINTUNI', 'Bintuni'),
            array('FAKFAK', 'Fak Fak'), array('JAYAPURA', 'Jayapura'), array('MANOKWARI', 'Manokwari'),
            array('MERAUKE', 'Merauke'), array('NABIRE', 'Nabire'), array('SENTANI', 'Sentani'),
            array('SERUI', 'Serui'), array('SORONG', 'Sorong'), array('TIMIKA', 'Timika'), array('WAMENA', 'Wamena')
        );
        foreach ($units as $i => $u) {
            $wpdb->query($wpdb->prepare(
                "INSERT IGNORE INTO {$t['units']} (code,name,sort_order,active,created_at,updated_at) VALUES (%s,%s,%d,1,%s,%s)",
                $u[0], $u[1], $i + 1, $now, $now
            ));
        }

        $programs = array(
            array('KDP', '', 'Fase 1 Berkas Belum Lengkap', '#23b653', 1, 1),
            array('DOK_LENGKAP', '', 'Fase 2 Berkas Lengkap', '#23b653', 2, 1),
            array('TERBUKU', '', 'Fase 3 Klaim Terbuku', '#23b653', 3, 1),
            array('SUBROGASI', '', 'Potensi Subrogasi', '#0b79ba', 4, 0),
            array('PENCAPAIAN', '', 'Pencapaian', '#0b79ba', 5, 0),
        );
        foreach ($programs as $p) {
            $wpdb->query($wpdb->prepare(
                "INSERT IGNORE INTO {$t['programs']} (code,phase_label,name,color,dashboard_order,show_dashboard,active,created_at,updated_at) VALUES (%s,%s,%s,%s,%d,%d,1,%s,%s)",
                $p[0], $p[1], $p[2], $p[3], $p[4], $p[5], $now, $now
            ));
            // Keep the requested phase labels synchronized on existing sites too.
            $wpdb->query($wpdb->prepare(
                "UPDATE {$t['programs']} SET phase_label=%s,name=%s,color=%s,dashboard_order=%d,show_dashboard=%d,active=1,updated_at=%s WHERE code=%s",
                $p[1], $p[2], $p[3], $p[4], $p[5], $now, $p[0]
            ));
        }

        $providers = array(
            array('ASKRINDO', 'Askrindo'),
            array('JAMKRINDO', 'Jamkrindo'),
            array('BSM_A3M', 'BSM A3M'),
            array('BRINS_FLPP', 'BRINS FLPP'),
        );
        foreach ($providers as $i => $p) {
            $wpdb->query($wpdb->prepare(
                "INSERT IGNORE INTO {$t['providers']} (code,name,sort_order,active,created_at,updated_at) VALUES (%s,%s,%d,1,%s,%s)",
                $p[0], $p[1], $i + 1, $now, $now
            ));
        }
    }

    private static function seed_demo_data() {
        global $wpdb;
        $t = self::tables();

        // Jangan mencampur data demo dengan transaksi yang sudah dimiliki pengguna.
        $existing = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$t['entries']}");
        if ($existing > 0) { return; }

        $units = array();
        foreach ($wpdb->get_results("SELECT id,code FROM {$t['units']}") as $r) { $units[$r->code] = (int)$r->id; }
        $programs = array();
        foreach ($wpdb->get_results("SELECT id,code FROM {$t['programs']}") as $r) { $programs[$r->code] = (int)$r->id; }
        $providers = array();
        foreach ($wpdb->get_results("SELECT id,code FROM {$t['providers']}") as $r) { $providers[$r->code] = (int)$r->id; }
        if (empty($units) || empty($programs) || empty($providers)) { return; }

        $now = self::now();
        $put = function($unitCode, $programCode, $providerCode, $year, $month, $week, $amount, $note='Data demo referensi ClaimTrack') use ($wpdb,$t,$units,$programs,$providers,$now) {
            if (!isset($units[$unitCode], $programs[$programCode], $providers[$providerCode])) { return; }
            $wpdb->query($wpdb->prepare(
                "INSERT IGNORE INTO {$t['entries']} (unit_id,program_id,provider_id,year,month,week,amount_million,note,created_at,updated_at) VALUES (%d,%d,%d,%d,%d,%d,%f,%s,%s,%s)",
                $units[$unitCode], $programs[$programCode], $providers[$providerCode], $year, $month, $week, (float)$amount, $note, $now, $now
            ));
        };

        $unitOrder = array('ABEPURA','BIAK','BINTUNI','FAKFAK','JAYAPURA','MANOKWARI','MERAUKE','NABIRE','SENTANI','SERUI','SORONG','TIMIKA','WAMENA');

        // FASE 1 - KDP, September 2026. Nilai diselaraskan agar total kolom sesuai tabel referensi.
        $kdp = array(
            'ASKRINDO'   => array(2702,1778,334,1102,1550,1294,5722,903,1870,44,8994,1781,1129),
            'JAMKRINDO'  => array(4525,168,0,13,555,14,580,891,351,0,4800,585,137),
            'BSM_A3M'    => array(0,0,0,0,0,0,0,0,0,0,0,0,0),
            'BRINS_FLPP' => array(321,0,0,0,1939,509,172,0,597,0,3301,566,0),
        );
        foreach ($kdp as $providerCode=>$vals) {
            foreach ($unitOrder as $i=>$unitCode) { if ((float)$vals[$i] != 0.0) { $put($unitCode,'KDP',$providerCode,2026,9,1,$vals[$i]); } }
        }

        // FASE 2 - Dokumen Lengkap Belum Terbayar, September 2026.
        $dok = array(
            'ASKRINDO'   => array(511,760,0,245,293,1334,124,452,220,170,1519,509,75),
            'JAMKRINDO'  => array(30,200,28,17,300,2,108,4,153,56,382,19,0),
            'BSM_A3M'    => array(344,1867,0,0,1427,39,1456,1194,0,225,93,0,0),
            'BRINS_FLPP' => array(0,0,0,0,0,0,0,0,0,0,0,0,0),
        );
        foreach ($dok as $providerCode=>$vals) {
            foreach ($unitOrder as $i=>$unitCode) { if ((float)$vals[$i] != 0.0) { $put($unitCode,'DOK_LENGKAP',$providerCode,2026,9,1,$vals[$i]); } }
        }

        // Klaim terbuku 2025 untuk Agustus dan September per unit kerja.
        $terbuku2025 = array(
            8 => array(2781,506,192,135,1010,290,518,317,439,402,1060,191,553),
            9 => array(738,1240,349,35,919,711,490,161,797,383,1221,89,334),
        );
        foreach ($terbuku2025 as $month=>$vals) {
            foreach ($unitOrder as $i=>$unitCode) { if ((float)$vals[$i] != 0.0) { $put($unitCode,'TERBUKU','ASKRINDO',2025,$month,1,$vals[$i]); } }
        }

        // Klaim terbuku 2026 Agustus dan September, termasuk pembagian per mitra.
        $terbuku2026Aug = array(
            'ASKRINDO'  => array(186,330,168,257,29,128,5,143,78,25,1460,261,19),
            'JAMKRINDO' => array(420,343,33,14,671,15,325,357,427,149,255,73,100),
            'BSM_A3M'   => array(0,0,0,0,0,0,0,0,1189,604,0,276,0),
            'BRINS_FLPP'=> array(0,0,0,0,0,0,0,0,0,0,0,0,0),
        );
        $terbuku2026Sep = array(
            'ASKRINDO'  => array(44,45,0,0,53,0,30,0,50,0,126,23,33),
            'JAMKRINDO' => array(142,128,0,0,221,0,0,0,98,0,28,41,12),
            'BSM_A3M'   => array(0,0,0,0,0,0,0,0,0,0,0,0,0),
            'BRINS_FLPP'=> array(0,0,0,0,0,0,0,0,0,0,0,0,0),
        );
        foreach ($terbuku2026Aug as $providerCode=>$vals) {
            foreach ($unitOrder as $i=>$unitCode) { if ((float)$vals[$i] != 0.0) { $put($unitCode,'TERBUKU',$providerCode,2026,8,1,$vals[$i]); } }
        }
        foreach ($terbuku2026Sep as $providerCode=>$vals) {
            foreach ($unitOrder as $i=>$unitCode) { if ((float)$vals[$i] != 0.0) { $put($unitCode,'TERBUKU',$providerCode,2026,9,1,$vals[$i]); } }
        }

        // Data bulanan pembayaran klaim untuk grafik. Agustus/September sudah diisi dari tabel rinci.
        $monthly2025 = array(1=>9080,2=>13719,3=>7324,4=>6563,5=>7842,6=>8677,7=>5105,10=>13340,11=>13828,12=>15604);
        $monthly2026 = array(1=>10786,2=>6663,3=>12949,4=>9615,5=>5579,6=>9443,7=>11034);
        foreach ($monthly2025 as $m=>$v) { $put('ABEPURA','TERBUKU','ASKRINDO',2025,$m,1,$v); }
        foreach ($monthly2026 as $m=>$v) { $put('ABEPURA','TERBUKU','ASKRINDO',2026,$m,1,$v); }

        // Demo Data Debitur (tersimpan permanen di tabel nominatif)
        if ((int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['debitur']}") === 0) {
            $demoDebitur = array(
                array('ABEPURA','KDP','ASKRINDO','BUDI SANTOSO','KDP-001',125.50,'Dalam Proses'),
                array('JAYAPURA','KDP','JAMKRINDO','SITI RAHAYU','KDP-002',245.00,'Selesai'),
                array('SORONG','DOK_LENGKAP','BRINS_FLPP','ANDI WIJAYA','DOC-003',87.75,'Dalam Proses'),
                array('TIMIKA','TERBUKU','ASKRINDO','RUDI HARTONO','TBK-004',310.25,'Ditolak')
            );
            foreach($demoDebitur as $d){
                if(isset($units[$d[0]],$programs[$d[1]],$providers[$d[2]])){
                    $wpdb->insert($t['debitur'],array(
                        'unit_id'=>$units[$d[0]],'program_id'=>$programs[$d[1]],'provider_id'=>$providers[$d[2]],
                        'nama_nasabah'=>$d[3],'nomor_klaim'=>$d[4],'amount_million'=>$d[5],
                        'status_klaim'=>$d[6],'created_at'=>$now,'updated_at'=>$now
                    ));
                }
            }
        }

        update_option('claimtrack_demo_seeded_version', self::DB_VERSION, false);
    }

    /**
     * Menyediakan demo profesional untuk instalasi baru maupun instalasi lama
     * yang masih memiliki bagian kosong. Metode ini idempotent dan hanya
     * mengganti record yang jelas berasal dari seed demo ClaimTrack. Record
     * input pengguna (note kosong / note lain) tidak disentuh.
     */
    private static function seed_professional_demo_content() {
        if ((string)get_option('claimtrack_professional_demo_version', '') === '1.15.6') { return; }

        global $wpdb;
        $t = self::tables();
        $year = (int) wp_date('Y');
        $month = (int) wp_date('n');
        $now = self::now();

        $units = array();
        foreach ($wpdb->get_results("SELECT id,code FROM {$t['units']} WHERE active=1 ORDER BY sort_order,id") as $r) {
            $units[(string)$r->code] = (int)$r->id;
        }
        $programs = array();
        foreach ($wpdb->get_results("SELECT id,code FROM {$t['programs']} WHERE active=1") as $r) {
            $programs[(string)$r->code] = (int)$r->id;
        }
        $providers = array();
        foreach ($wpdb->get_results("SELECT id,code FROM {$t['providers']} WHERE active=1 ORDER BY sort_order,id") as $r) {
            $providers[(string)$r->code] = (int)$r->id;
        }

        $unitOrder = array('ABEPURA','BIAK','BINTUNI','FAKFAK','JAYAPURA','MANOKWARI','MERAUKE','NABIRE','SENTANI','SERUI','SORONG','TIMIKA','WAMENA');
        $weights = array(1=>0.38, 2=>0.27, 3=>0.20, 4=>0.15);
        $demoNote = 'Demo ClaimTrack v1.15.6';

        $periodIsSafeForDemo = function($programId) use ($wpdb,$t,$year,$month) {
            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT note FROM {$t['entries']} WHERE program_id=%d AND year=%d AND month=%d",
                (int)$programId, $year, $month
            ));
            if (!$rows) { return true; }
            foreach ($rows as $row) {
                $note = trim((string)$row->note);
                if (stripos($note, 'Data demo') !== 0 && stripos($note, 'Demo ClaimTrack') !== 0) {
                    return false;
                }
            }
            return true;
        };

        $seedMatrix = function($programCode, $matrix) use ($wpdb,$t,$year,$month,$now,$units,$programs,$providers,$unitOrder,$weights,$demoNote,$periodIsSafeForDemo) {
            if (!isset($programs[$programCode]) || !$periodIsSafeForDemo($programs[$programCode])) { return false; }
            $programId = (int)$programs[$programCode];

            // Bersihkan hanya record demo lama pada periode yang sama.
            $wpdb->query($wpdb->prepare(
                "DELETE FROM {$t['entries']} WHERE program_id=%d AND year=%d AND month=%d AND (note LIKE %s OR note LIKE %s)",
                $programId, $year, $month, 'Data demo%', 'Demo ClaimTrack%'
            ));

            foreach ($matrix as $providerCode => $totals) {
                if (!isset($providers[$providerCode])) { continue; }
                $providerId = (int)$providers[$providerCode];
                foreach ($unitOrder as $i => $unitCode) {
                    if (!isset($units[$unitCode])) { continue; }
                    $total = isset($totals[$i]) ? (float)$totals[$i] : 0.0;
                    if ($total <= 0) { continue; }
                    $remaining = round($total, 2);
                    foreach ($weights as $week => $weight) {
                        $amount = ($week === 4) ? $remaining : round($total * $weight, 2);
                        $remaining = round($remaining - $amount, 2);
                        if ($amount <= 0) { continue; }
                        $wpdb->query($wpdb->prepare(
                            "INSERT INTO {$t['entries']} (unit_id,program_id,provider_id,year,month,week,amount_million,note,created_at,updated_at)
                             VALUES (%d,%d,%d,%d,%d,%d,%f,%s,%s,%s)
                             ON DUPLICATE KEY UPDATE amount_million=VALUES(amount_million),note=VALUES(note),updated_at=VALUES(updated_at)",
                            (int)$units[$unitCode], $programId, $providerId, $year, $month, (int)$week,
                            $amount, $demoNote, $now, $now
                        ));
                    }
                }
            }
            return true;
        };

        // FASE 1 - KDP. Semua asuradur diberi contoh agar card, tabel dan grafik terisi.
        $phase1 = array(
            'ASKRINDO'   => array(2702,1778,334,1102,1550,1295,5723,903,1870,144,8994,1781,1128),
            'JAMKRINDO'  => array(4525,268,120,113,555,214,580,891,351,90,4800,585,237),
            'BSM_A3M'    => array(180,95,55,75,120,85,140,70,110,35,250,95,45),
            'BRINS_FLPP' => array(321,85,60,55,1939,509,172,75,597,45,3301,566,90),
        );

        // FASE 2 - Dokumen Lengkap. Data contoh dibuat tersebar agar input Minggu I-IV terlihat hidup.
        $phase2 = array(
            'ASKRINDO'   => array(511,760,180,245,293,1334,324,452,220,170,1519,509,175),
            'JAMKRINDO'  => array(130,200,128,117,300,102,208,104,153,156,382,119,90),
            'BSM_A3M'    => array(344,867,140,160,1427,239,456,594,180,225,293,140,120),
            'BRINS_FLPP' => array(95,160,75,90,210,115,185,130,155,70,340,125,85),
        );

        // FASE 3 - Terbuku. Nilai lebih kecil untuk menunjukkan alur progres dari fase sebelumnya.
        $phase3 = array(
            'ASKRINDO'   => array(186,173,101,142,229,118,205,143,178,85,460,161,119),
            'JAMKRINDO'  => array(120,143,83,74,171,95,125,157,127,79,255,93,100),
            'BSM_A3M'    => array(48,65,35,42,89,55,76,61,109,44,118,76,39),
            'BRINS_FLPP' => array(72,84,45,50,119,78,92,66,97,55,166,88,52),
        );

        // Potensi Subrogasi. Digunakan pada menu monitoring dan input /sw-admin.
        $subrogation = array(
            'ASKRINDO'   => array(320,185,95,140,260,175,410,155,225,80,520,190,130),
            'JAMKRINDO'  => array(180,110,65,85,145,95,220,90,135,55,275,105,75),
            'BSM_A3M'    => array(75,55,30,40,70,50,95,45,65,25,120,55,35),
            'BRINS_FLPP' => array(110,70,40,55,95,65,135,60,85,35,165,70,45),
        );

        $changed = false;
        $changed = $seedMatrix('KDP', $phase1) || $changed;
        $changed = $seedMatrix('DOK_LENGKAP', $phase2) || $changed;
        $changed = $seedMatrix('TERBUKU', $phase3) || $changed;
        $changed = $seedMatrix('SUBROGASI', $subrogation) || $changed;

        // Berita demo hanya dibuat ketika belum ada berita sama sekali.
        $newsCount = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type='ct_news' AND post_status NOT IN ('trash','auto-draft')");
        if ($newsCount === 0 && post_type_exists('ct_news')) {
            $news = array(
                array(
                    'title'=>'Update Monitoring Klaim September 2026',
                    'excerpt'=>'Ringkasan posisi klaim dan fokus tindak lanjut operasional untuk periode berjalan.',
                    'content'=>'<p>Monitoring klaim periode berjalan telah diperbarui pada dashboard ClaimTrack. Seluruh Unit Kerja dapat menggunakan ringkasan fase untuk melihat posisi KDP, kelengkapan dokumen, dan klaim terbuku.</p><p><strong>Fokus minggu ini:</strong></p><ul><li>Validasi data FASE 1 dan FASE 2.</li><li>Percepatan tindak lanjut dokumen yang belum lengkap.</li><li>Pemantauan klaim terbuku dan potensi subrogasi.</li></ul>',
                    'featured'=>1,
                ),
                array(
                    'title'=>'Fokus Penyelesaian Dokumen Klaim FASE 2',
                    'excerpt'=>'Pastikan dokumen pendukung telah diverifikasi sebelum dilanjutkan ke proses pembukuan klaim.',
                    'content'=>'<p>FASE 2 menjadi titik penting untuk memastikan dokumen klaim telah lengkap dan konsisten. Gunakan tabel per Unit Kerja untuk memantau nilai yang masih membutuhkan tindak lanjut.</p><p>Koordinasikan koreksi dokumen secara berkala agar proses dapat bergerak ke FASE 3 tanpa penundaan yang tidak diperlukan.</p>',
                    'featured'=>0,
                ),
                array(
                    'title'=>'Penguatan Monitoring Potensi Subrogasi',
                    'excerpt'=>'Potensi subrogasi kini dapat dipantau per Unit Kerja, Asuradur, periode, dan minggu.',
                    'content'=>'<p>Menu Potensi Subrogasi digunakan untuk mencatat nilai yang memerlukan monitoring lanjutan. Admin dapat memperbarui data melalui portal pengelolaan, sedangkan karyawan dapat membaca posisi terbaru dari dashboard.</p><p>Gunakan data ini sebagai bahan koordinasi dan prioritas tindak lanjut operasional.</p>',
                    'featured'=>0,
                ),
                array(
                    'title'=>'E-Knowledge Baru: Panduan Input dan Pelaporan',
                    'excerpt'=>'Empat materi contoh tersedia untuk membantu penggunaan ClaimTrack secara konsisten.',
                    'content'=>'<p>Pusat E-Knowledge telah dilengkapi materi contoh mengenai input fase klaim, verifikasi dokumen, potensi subrogasi, serta pembacaan dashboard dan pelaporan.</p><p>Admin dapat mengganti, mengedit, atau menghapus materi contoh sesuai kebutuhan internal.</p>',
                    'featured'=>0,
                ),
            );
            foreach ($news as $i => $item) {
                $postId = wp_insert_post(array(
                    'post_type'=>'ct_news', 'post_status'=>'publish', 'post_title'=>$item['title'],
                    'post_excerpt'=>$item['excerpt'], 'post_content'=>$item['content'], 'menu_order'=>$i+1,
                    'comment_status'=>'open',
                    'post_date'=>wp_date('Y-m-d H:i:s', current_time('timestamp') - ($i * DAY_IN_SECONDS)),
                ), true);
                if (!is_wp_error($postId) && $postId) {
                    update_post_meta((int)$postId, '_claimtrack_news_featured', (string)$item['featured']);
                    update_post_meta((int)$postId, '_claimtrack_demo_seed', '1');
                }
            }
        }

        // E-Knowledge demo dengan PDF bawaan plugin. Materi dapat diedit/hapus dari /sw-admin.
        $knowledgeCount = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type='ct_knowledge' AND post_status NOT IN ('trash','auto-draft')");
        if ($knowledgeCount === 0 && post_type_exists('ct_knowledge')) {
            $baseUrl = defined('CLAIMTRACK_URL') ? trailingslashit(CLAIMTRACK_URL).'assets/demo/' : '';
            $knowledge = array(
                array('Panduan Input Fase Klaim','Langkah pengisian FASE 1, FASE 2, dan FASE 3 per Unit Kerja, Asuradur, dan Minggu.','panduan-input-fase-klaim.pdf'),
                array('SOP Verifikasi Dokumen Klaim','Checklist ringkas untuk membantu memastikan dokumen klaim siap diproses ke fase berikutnya.','sop-verifikasi-dokumen-klaim.pdf'),
                array('Panduan Potensi Subrogasi','Panduan pencatatan dan monitoring potensi subrogasi pada dashboard ClaimTrack.','panduan-potensi-subrogasi.pdf'),
                array('Panduan Dashboard dan Pelaporan','Cara membaca card monitoring, grafik, pencapaian, serta melakukan pengamanan data berkala.','panduan-dashboard-pelaporan.pdf'),
            );
            foreach ($knowledge as $i => $item) {
                $postId = wp_insert_post(array(
                    'post_type'=>'ct_knowledge', 'post_status'=>'publish', 'post_title'=>$item[0],
                    'post_content'=>'<p>'.esc_html($item[1]).'</p>', 'menu_order'=>$i+1,
                ), true);
                if (!is_wp_error($postId) && $postId) {
                    update_post_meta((int)$postId, '_claimtrack_knowledge_pdf_id', 0);
                    update_post_meta((int)$postId, '_claimtrack_knowledge_pdf_url', $baseUrl.$item[2]);
                    update_post_meta((int)$postId, '_claimtrack_demo_seed', '1');
                }
            }
        }

        if ($changed) { self::mark_cpt_sync_dirty(); }
        update_option('claimtrack_professional_demo_version', '1.15.6', false);
    }

    private static function add_roles_caps() {
        // ClaimTrack memakai satu Administrator Utama dan akun pengguna lain
        // selalu menggunakan role Viewer. Role Manager lama dimigrasikan agar
        // tidak menjadi jalur untuk membuat administrator kedua.
        $caps_viewer = array(
            'read' => true,
            'claimtrack_view' => true,
        );
        add_role('claimtrack_viewer', 'ClaimTrack Viewer', $caps_viewer);

        // Migrasikan akun ClaimTrack Manager lama menjadi Viewer sebelum role
        // lama dihapus. Akun utama "atadro" dipertahankan sebagai Administrator.
        $legacy_managers = get_users(array('role' => 'claimtrack_manager'));
        foreach ($legacy_managers as $legacy_user) {
            if (strtolower((string)$legacy_user->user_login) === 'atadro') { continue; }
            $legacy_user->set_role('claimtrack_viewer');
            $legacy_user->remove_cap('claimtrack_manage');
            $legacy_user->remove_cap('claimtrack_import_export');
            $legacy_user->remove_cap('manage_options');
        }
        if (get_role('claimtrack_manager')) { remove_role('claimtrack_manager'); }

        $admin = get_role('administrator');
        if ($admin) {
            $admin->add_cap('claimtrack_view');
            $admin->add_cap('claimtrack_manage');
            $admin->add_cap('claimtrack_import_export');
        }
    }

    /**
     * Definisi laman WordPress yang dikelola ClaimTrack.
     * Setiap menu utama memiliki post_type=page sendiri sehingga navigasi tidak
     * hanya bergantung pada query string. Ini juga membuat laman dapat dilihat
     * dari menu Pages/Laman pada wp-admin.
     */
    public static function app_page_definitions() {
        return array(
            'home' => array(
                'title' => 'Home ClaimTrack',
                'slug' => 'home-claimtrack',
                'view' => 'home',
                'program_code' => '',
            ),
            'dashboard' => array(
                'title' => 'ClaimTrack',
                'slug' => 'claimtrack',
                'view' => 'dashboard',
                'program_code' => '',
            ),
            'phase_kdp' => array(
                'title' => 'FASE 1 - KDP',
                'slug' => 'fase-1-kdp',
                'view' => 'phase',
                'program_code' => 'KDP',
            ),
            'phase_dok_lengkap' => array(
                'title' => 'FASE 2 - Dok. Lengkap',
                'slug' => 'fase-2-dok-lengkap',
                'view' => 'phase',
                'program_code' => 'DOK_LENGKAP',
            ),
            'phase_terbuku' => array(
                'title' => 'FASE 3 - Terbuku',
                'slug' => 'fase-3-terbuku',
                'view' => 'phase',
                'program_code' => 'TERBUKU',
            ),
            'sw_admin' => array(
                'title' => 'SW Admin ClaimTrack',
                'slug' => 'sw-admin',
                'view' => 'admin',
                'program_code' => '',
            ),
            'matrix' => array(
                'title' => 'Input Mingguan ClaimTrack',
                'slug' => 'input-mingguan-claimtrack',
                'view' => 'matrix',
                'program_code' => '',
            ),
            'units' => array(
                'title' => 'Unit Kerja ClaimTrack',
                'slug' => 'unit-kerja-claimtrack',
                'view' => 'units',
                'program_code' => '',
            ),
            'programs' => array(
                'title' => 'Program ClaimTrack',
                'slug' => 'program-claimtrack',
                'view' => 'programs',
                'program_code' => '',
            ),
            'providers' => array(
                'title' => 'Mitra ClaimTrack',
                'slug' => 'mitra-claimtrack',
                'view' => 'providers',
                'program_code' => '',
            ),
            'import' => array(
                'title' => 'Import & Export ClaimTrack',
                'slug' => 'import-export-claimtrack',
                'view' => 'import',
                'program_code' => '',
            ),
            'settings' => array(
                'title' => 'Pengaturan ClaimTrack',
                'slug' => 'pengaturan-claimtrack',
                'view' => 'settings',
                'program_code' => '',
            ),
            'knowledge' => array(
                'title' => 'E-Knowledge ClaimTrack',
                'slug' => 'e-knowledge-claimtrack',
                'view' => 'knowledge',
                'program_code' => '',
            ),
            'achievement' => array(
                'title' => 'Pencapaian ClaimTrack',
                'slug' => 'pencapaian-claimtrack',
                'view' => 'achievement',
                'program_code' => '',
            ),
        );
    }

    /**
     * Membuat/menyembuhkan seluruh laman ClaimTrack sebagai WordPress Pages.
     * Data aplikasi tetap disimpan pada tabel WordPress, sedangkan routing UI
     * disimpan pada wp_posts + wp_postmeta.
     */
    public static function ensure_app_pages() {
        $stored = get_option('claimtrack_page_ids', array());
        if (!is_array($stored)) { $stored = array(); }

        /*
         * Critical safety guard. wp_insert_post() may run permalink-related hooks.
         * If WP_Rewrite is not ready, defer the sync instead of touching Pages.
         */
        if (!self::rewrite_is_ready()) {
            update_option('claimtrack_pages_sync_pending', 1, false);
            return $stored;
        }

        // v1.15.1: Fase Klaim bukan lagi sebuah halaman. Ia hanya menjadi
        // grup menu yang membuka sub-menu FASE 1, FASE 2, dan FASE 3.
        // Hanya laman lama yang memang dikelola ClaimTrack yang dipindahkan
        // ke Trash agar tidak menghapus halaman buatan pengguna.
        $legacy_phase_id = (int)($stored['phases'] ?? 0);
        if ($legacy_phase_id > 0) {
            $legacy_phase = get_post($legacy_phase_id);
            if ($legacy_phase instanceof WP_Post
                && $legacy_phase->post_type === 'page'
                && (string)get_post_meta($legacy_phase_id, '_claimtrack_managed', true) === '1'
                && (string)get_post_meta($legacy_phase_id, '_claimtrack_route_key', true) === 'phases'
                && $legacy_phase->post_status !== 'trash') {
                wp_trash_post($legacy_phase_id);
                update_option('claimtrack_rewrite_flush_pending', 1, false);
            }
            unset($stored['phases']);
        } else {
            $legacy_phase = get_page_by_path('fase-klaim', OBJECT, 'page');
            if ($legacy_phase instanceof WP_Post
                && (string)get_post_meta($legacy_phase->ID, '_claimtrack_managed', true) === '1'
                && (string)get_post_meta($legacy_phase->ID, '_claimtrack_route_key', true) === 'phases'
                && $legacy_phase->post_status !== 'trash') {
                wp_trash_post((int)$legacy_phase->ID);
                update_option('claimtrack_rewrite_flush_pending', 1, false);
            }
        }


        $defs = self::app_page_definitions();
        $changed = false;

        foreach ($defs as $key => $def) {
            $page = null;
            $known_id = isset($stored[$key]) ? (int)$stored[$key] : 0;
            if ($known_id > 0) {
                $candidate = get_post($known_id);
                if ($candidate instanceof WP_Post && $candidate->post_type === 'page' && $candidate->post_status !== 'trash') {
                    $page = $candidate;
                }
            }
            if (!$page) {
                $candidate = get_page_by_path($def['slug'], OBJECT, 'page');
                if ($candidate instanceof WP_Post && $candidate->post_status !== 'trash') { $page = $candidate; }
            }

            $postarr = array(
                'post_title' => $def['title'],
                'post_name' => $def['slug'],
                'post_status' => 'publish',
                'post_type' => 'page',
                'post_content' => '[claimtrack_app]',
            );

            if ($page) {
                $update = array('ID' => (int)$page->ID);
                if ((string)$page->post_title !== (string)$def['title']) { $update['post_title'] = $def['title']; }
                if ((string)$page->post_name !== (string)$def['slug']) { $update['post_name'] = $def['slug']; }
                if ((string)$page->post_status !== 'publish') { $update['post_status'] = 'publish'; }
                if (strpos((string)$page->post_content, '[claimtrack_app]') === false) { $update['post_content'] = '[claimtrack_app]'; }
                if (count($update) > 1) {
                    wp_update_post($update);
                    $changed = true;
                }
                $page_id = (int)$page->ID;
            } else {
                $page_id = (int)wp_insert_post($postarr);
                if ($page_id > 0) { $changed = true; }
            }

            if ($page_id <= 0) { continue; }
            if ((int)($stored[$key] ?? 0) !== $page_id) { $stored[$key] = $page_id; $changed = true; }

            $meta = array(
                '_claimtrack_managed' => '1',
                '_claimtrack_route_key' => $key,
                '_claimtrack_view' => $def['view'],
                '_claimtrack_program_code' => $def['program_code'],
            );
            foreach ($meta as $meta_key => $meta_value) {
                if ((string)get_post_meta($page_id, $meta_key, true) !== (string)$meta_value) {
                    update_post_meta($page_id, $meta_key, $meta_value);
                    $changed = true;
                }
            }
        }

        update_option('claimtrack_page_ids', $stored, false);
        if ($changed) {
            /* Flush once after all managed Pages have been created/updated. */
            update_option('claimtrack_rewrite_flush_pending', 1, false);
        }
        return $stored;
    }

    public static function get_app_page_id($key) {
        $defs = self::app_page_definitions();
        if (!isset($defs[$key])) { return 0; }
        $stored = get_option('claimtrack_page_ids', array());
        $id = is_array($stored) ? (int)($stored[$key] ?? 0) : 0;
        if ($id > 0) {
            $p = get_post($id);
            if ($p instanceof WP_Post && $p->post_type === 'page' && $p->post_status !== 'trash') { return $id; }
        }
        $page = get_page_by_path($defs[$key]['slug'], OBJECT, 'page');
        return ($page instanceof WP_Post) ? (int)$page->ID : 0;
    }

    public static function get_app_page_url($key, $args = array()) {
        $id = self::get_app_page_id($key);
        $url = $id ? get_permalink($id) : home_url('/');
        return $args ? add_query_arg($args, $url) : $url;
    }

    public static function get_route_for_page($post_id) {
        $post_id = (int)$post_id;
        if ($post_id <= 0) { return array(); }
        if ((string)get_post_meta($post_id, '_claimtrack_managed', true) !== '1') {
            $post = get_post($post_id);
            if (!($post instanceof WP_Post) || strpos((string)$post->post_content, '[claimtrack_app]') === false) { return array(); }
        }
        $view = sanitize_key((string)get_post_meta($post_id, '_claimtrack_view', true));
        $program_code = self::normalize_code((string)get_post_meta($post_id, '_claimtrack_program_code', true));
        if ($view === '') { $view = 'dashboard'; }
        return array('view' => $view, 'program_code' => $program_code);
    }

    /** Backward compatibility untuk instalasi lama. */
    private static function create_app_page() {
        $pages = self::ensure_app_pages();
        return (int)($pages['home'] ?? ($pages['dashboard'] ?? 0));
    }

    private static function set_as_front_page() {
        $page_id = self::get_app_page_id('home');
        if ($page_id <= 0) { return; }
        if (get_option('show_on_front') !== 'page') { update_option('show_on_front', 'page'); }
        if ((int)get_option('page_on_front') !== $page_id) { update_option('page_on_front', $page_id); }
    }


    /**
     * Register mirror Custom Post Types agar seluruh data ClaimTrack dapat
     * diaudit dari wp-admin. Sumber data utama tetap tabel ClaimTrack.
     */
    public static function register_post_types() {
        $common = array(
            'public' => false,
            'publicly_queryable' => false,
            'show_ui' => true,
            'show_in_menu' => 'claimtrack-data',
            'show_in_rest' => false,
            'rewrite' => false,
            'query_var' => false,
            'supports' => array('title'),
            'map_meta_cap' => false,
            'capabilities' => array(
                'edit_post' => 'do_not_allow',
                'read_post' => 'manage_options',
                'delete_post' => 'do_not_allow',
                'edit_posts' => 'manage_options',
                'edit_others_posts' => 'manage_options',
                'publish_posts' => 'do_not_allow',
                'read_private_posts' => 'manage_options',
                'create_posts' => 'do_not_allow',
            ),
        );
        $types = array(
            'ct_unit' => array('name'=>'Unit Kerja','singular_name'=>'Unit Kerja','menu_name'=>'Unit Kerja'),
            'ct_program' => array('name'=>'Program / Fase','singular_name'=>'Program','menu_name'=>'Program / Fase'),
            'ct_provider' => array('name'=>'Mitra / Asuradur','singular_name'=>'Mitra','menu_name'=>'Mitra / Asuradur'),
            'ct_entry' => array('name'=>'Data Klaim','singular_name'=>'Data Klaim','menu_name'=>'Data Klaim'),
        );
        foreach ($types as $post_type => $labels) {
            $args = $common;
            $args['labels'] = array_merge($labels, array(
                'all_items' => $labels['name'],
                'search_items' => 'Cari ' . $labels['name'],
                'not_found' => 'Data tidak ditemukan.',
            ));
            register_post_type($post_type, $args);
        }

        // E-Knowledge adalah data WordPress native yang dapat dikelola.
        register_post_type('ct_knowledge', array(
            'labels'=>array(
                'name'=>'E-Knowledge','singular_name'=>'Materi E-Knowledge','menu_name'=>'E-Knowledge',
                'add_new'=>'Tambah Materi','add_new_item'=>'Tambah Materi E-Knowledge','edit_item'=>'Edit Materi E-Knowledge',
                'new_item'=>'Materi Baru','view_item'=>'Lihat Materi','search_items'=>'Cari E-Knowledge','not_found'=>'Materi tidak ditemukan.','all_items'=>'E-Knowledge',
            ),
            'public'=>false,'publicly_queryable'=>false,'show_ui'=>true,'show_in_menu'=>'claimtrack-data','show_in_rest'=>false,
            'rewrite'=>false,'query_var'=>false,'supports'=>array('title','editor','thumbnail','page-attributes'),
            'map_meta_cap'=>false,
            'capabilities'=>array(
                'edit_post'=>'manage_options','read_post'=>'manage_options','delete_post'=>'manage_options',
                'edit_posts'=>'manage_options','edit_others_posts'=>'manage_options','publish_posts'=>'manage_options',
                'read_private_posts'=>'manage_options','delete_posts'=>'manage_options','delete_private_posts'=>'manage_options',
                'delete_published_posts'=>'manage_options','delete_others_posts'=>'manage_options','edit_private_posts'=>'manage_options',
                'edit_published_posts'=>'manage_options','create_posts'=>'manage_options',
            ),
        ));


        // Berita internal karyawan, dikelola dari portal /sw-admin.
        register_post_type('ct_news', array(
            'labels'=>array(
                'name'=>'Berita ClaimTrack','singular_name'=>'Berita','menu_name'=>'Berita',
                'add_new'=>'Tambah Berita','add_new_item'=>'Tambah Berita','edit_item'=>'Edit Berita',
                'new_item'=>'Berita Baru','view_item'=>'Lihat Berita','search_items'=>'Cari Berita','not_found'=>'Berita tidak ditemukan.','all_items'=>'Berita',
            ),
            'public'=>false,'publicly_queryable'=>false,'show_ui'=>true,'show_in_menu'=>'claimtrack-data','show_in_rest'=>false,
            'rewrite'=>false,'query_var'=>false,'supports'=>array('title','editor','excerpt','thumbnail','page-attributes','comments'),
            'map_meta_cap'=>false,
            'capabilities'=>array(
                'edit_post'=>'manage_options','read_post'=>'manage_options','delete_post'=>'manage_options',
                'edit_posts'=>'manage_options','edit_others_posts'=>'manage_options','publish_posts'=>'manage_options',
                'read_private_posts'=>'manage_options','delete_posts'=>'manage_options','delete_private_posts'=>'manage_options',
                'delete_published_posts'=>'manage_options','delete_others_posts'=>'manage_options','edit_private_posts'=>'manage_options',
                'edit_published_posts'=>'manage_options','create_posts'=>'manage_options',
            ),
        ));

        foreach (array_keys($types) as $pt) {
            add_filter('post_row_actions', function($actions, $post) use ($pt) {
                if ($post instanceof WP_Post && $post->post_type === $pt) { return array(); }
                return $actions;
            }, 20, 2);
            add_filter('bulk_actions-edit-' . $pt, '__return_empty_array');
        }

        add_filter('manage_ct_unit_posts_columns', array(__CLASS__, 'unit_columns'));
        add_action('manage_ct_unit_posts_custom_column', array(__CLASS__, 'render_cpt_column'), 10, 2);
        add_filter('manage_ct_program_posts_columns', array(__CLASS__, 'program_columns'));
        add_action('manage_ct_program_posts_custom_column', array(__CLASS__, 'render_cpt_column'), 10, 2);
        add_filter('manage_ct_provider_posts_columns', array(__CLASS__, 'provider_columns'));
        add_action('manage_ct_provider_posts_custom_column', array(__CLASS__, 'render_cpt_column'), 10, 2);
        add_filter('manage_ct_entry_posts_columns', array(__CLASS__, 'entry_columns'));
        add_action('manage_ct_entry_posts_custom_column', array(__CLASS__, 'render_cpt_column'), 10, 2);
        add_filter('manage_ct_knowledge_posts_columns', array(__CLASS__, 'knowledge_columns'));
        add_action('manage_ct_knowledge_posts_custom_column', array(__CLASS__, 'render_cpt_column'), 10, 2);
        add_filter('manage_ct_news_posts_columns', array(__CLASS__, 'news_columns'));
        add_action('manage_ct_news_posts_custom_column', array(__CLASS__, 'render_cpt_column'), 10, 2);
    }

    public static function register_admin_menu() {
        add_menu_page(
            'ClaimTrack Data',
            'ClaimTrack Data',
            'manage_options',
            'claimtrack-data',
            array(__CLASS__, 'render_admin_data_home'),
            'dashicons-database',
            26
        );
    }

    public static function render_admin_data_home() {
        if (!current_user_can('manage_options')) { wp_die('Akses ditolak.'); }
        global $wpdb;
        $t = self::tables();
        $counts = array(
            'Unit Kerja' => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['units']}"),
            'Program / Fase' => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['programs']}"),
            'Mitra / Asuradur' => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['providers']}"),
            'Data Klaim' => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['entries']}"),
            'E-Knowledge' => (int)(wp_count_posts('ct_knowledge')->publish ?? 0),
            'Berita' => (int)(wp_count_posts('ct_news')->publish ?? 0),
        );
        echo '<div class="wrap"><h1>ClaimTrack Data</h1><p>Menu ini menampilkan mirror otomatis data ClaimTrack yang tersimpan di tabel database WordPress. Edit data melalui dashboard ClaimTrack agar tabel utama dan post type tetap sinkron.</p><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;max-width:980px;margin:20px 0">';
        foreach ($counts as $label=>$count) {
            echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:16px"><strong style="font-size:24px;display:block">'.esc_html(number_format_i18n($count)).'</strong><span>'.esc_html($label).'</span></div>';
        }
        echo '</div><p><a class="button button-primary" href="'.esc_url(admin_url('edit.php?post_type=ct_entry')).'">Lihat Data Klaim</a> <a class="button" href="'.esc_url(admin_url('edit.php?post_type=ct_knowledge')).'">Kelola E-Knowledge</a> <a class="button" href="'.esc_url(admin_url('edit.php?post_type=ct_news')).'">Kelola Berita</a></p></div>';
    }

    public static function unit_columns($cols) {
        return array('cb'=>$cols['cb']??'','title'=>'Unit Kerja','ct_code'=>'Kode','ct_active'=>'Status','ct_source_id'=>'ID Database','date'=>'Dibuat');
    }
    public static function program_columns($cols) {
        return array('cb'=>$cols['cb']??'','title'=>'Program','ct_phase'=>'Fase','ct_code'=>'Kode','ct_active'=>'Status','ct_source_id'=>'ID Database','date'=>'Dibuat');
    }
    public static function provider_columns($cols) {
        return array('cb'=>$cols['cb']??'','title'=>'Mitra / Asuradur','ct_code'=>'Kode','ct_active'=>'Status','ct_source_id'=>'ID Database','date'=>'Dibuat');
    }
    public static function entry_columns($cols) {
        return array('cb'=>$cols['cb']??'','title'=>'Data Klaim','ct_unit'=>'Unit','ct_program'=>'Program','ct_provider'=>'Mitra','ct_period'=>'Periode','ct_week'=>'Minggu','ct_amount'=>'Nominal (Juta)','ct_source_id'=>'ID Database');
    }
    public static function knowledge_columns($cols) {
        return array('cb'=>$cols['cb']??'','title'=>'Judul Materi','ct_knowledge_pdf'=>'PDF','ct_knowledge_cover'=>'Cover','menu_order'=>'Urutan','date'=>'Diperbarui');
    }
    public static function news_columns($cols) {
        return array('cb'=>$cols['cb']??'','title'=>'Judul Berita','ct_news_featured'=>'Utama','ct_news_cover'=>'Cover','menu_order'=>'Urutan','date'=>'Diterbitkan');
    }
    public static function render_cpt_column($column, $post_id) {
        $meta = function($key) use ($post_id) { return (string)get_post_meta($post_id, $key, true); };
        switch ($column) {
            case 'ct_code': echo esc_html($meta('_claimtrack_code')); break;
            case 'ct_phase': echo esc_html($meta('_claimtrack_phase_label')); break;
            case 'ct_active': echo $meta('_claimtrack_active') === '1' ? 'Aktif' : 'Nonaktif'; break;
            case 'ct_source_id': echo esc_html($meta('_claimtrack_source_id')); break;
            case 'ct_unit': echo esc_html($meta('_claimtrack_unit_name')); break;
            case 'ct_program': echo esc_html($meta('_claimtrack_program_name')); break;
            case 'ct_provider': echo esc_html($meta('_claimtrack_provider_name')); break;
            case 'ct_period': echo esc_html($meta('_claimtrack_month') . '/' . $meta('_claimtrack_year')); break;
            case 'ct_week': echo esc_html($meta('_claimtrack_week')); break;
            case 'ct_amount': echo esc_html(number_format_i18n((float)$meta('_claimtrack_amount_million'), 2)); break;
            case 'ct_knowledge_pdf':
                $pdf_id=(int)get_post_meta($post_id,'_claimtrack_knowledge_pdf_id',true);
                $url=$pdf_id?wp_get_attachment_url($pdf_id):(string)get_post_meta($post_id,'_claimtrack_knowledge_pdf_url',true);
                echo $url?'<a href="'.esc_url($url).'" target="_blank" rel="noopener">Buka PDF</a>':'-';
                break;
            case 'ct_knowledge_cover':
                $cover_id=(int)get_post_meta($post_id,'_claimtrack_knowledge_cover_id',true);
                echo $cover_id?wp_get_attachment_image($cover_id,array(54,54),false,array('style'=>'width:54px;height:54px;object-fit:cover;border-radius:8px')):'-';
                break;
            case 'ct_news_featured': echo get_post_meta($post_id,'_claimtrack_news_featured',true)==='1'?'Ya':'Tidak'; break;
            case 'ct_news_cover':
                $cover_id=(int)get_post_thumbnail_id($post_id);
                echo $cover_id?wp_get_attachment_image($cover_id,array(54,54),false,array('style'=>'width:54px;height:54px;object-fit:cover;border-radius:8px')):'-';
                break;
            case 'menu_order': $p=get_post($post_id); echo $p?(int)$p->menu_order:0; break;
        }
    }

    public static function mark_cpt_sync_dirty() {
        update_option('claimtrack_cpt_sync_pending', 1, false);
    }

    /**
     * Mirror semua record tabel ClaimTrack ke wp_posts/wp_postmeta. Post type ini
     * bersifat read-only agar tidak terjadi dua sumber data yang saling konflik.
     */
    public static function sync_cpt_mirror($force = false) {
        if (!$force && !get_option('claimtrack_cpt_sync_pending')) { return true; }
        if (!post_type_exists('ct_unit')) { self::mark_cpt_sync_dirty(); return false; }
        global $wpdb;
        $t = self::tables();
        $units = $wpdb->get_results("SELECT * FROM {$t['units']} ORDER BY id", ARRAY_A);
        $programs = $wpdb->get_results("SELECT * FROM {$t['programs']} ORDER BY id", ARRAY_A);
        $providers = $wpdb->get_results("SELECT * FROM {$t['providers']} ORDER BY id", ARRAY_A);
        $entries = $wpdb->get_results("SELECT * FROM {$t['entries']} ORDER BY id", ARRAY_A);

        $unit_names = array(); foreach ($units as $r) { $unit_names[(int)$r['id']] = $r['name']; }
        $program_names = array(); foreach ($programs as $r) { $program_names[(int)$r['id']] = trim(($r['phase_label'] ? $r['phase_label'].' - ' : '').$r['name']); }
        $provider_names = array(); foreach ($providers as $r) { $provider_names[(int)$r['id']] = $r['name']; }

        self::sync_cpt_type('ct_unit', $units, function($r) {
            return array(
                'title' => $r['name'],
                'meta' => array(
                    '_claimtrack_code'=>$r['code'], '_claimtrack_name'=>$r['name'], '_claimtrack_sort_order'=>$r['sort_order'], '_claimtrack_active'=>$r['active'],
                    '_claimtrack_created_at'=>$r['created_at'], '_claimtrack_updated_at'=>$r['updated_at'],
                ),
            );
        });
        self::sync_cpt_type('ct_program', $programs, function($r) {
            return array(
                'title' => trim(($r['phase_label'] ? $r['phase_label'].' - ' : '').$r['name']),
                'meta' => array(
                    '_claimtrack_code'=>$r['code'], '_claimtrack_phase_label'=>$r['phase_label'], '_claimtrack_name'=>$r['name'], '_claimtrack_color'=>$r['color'],
                    '_claimtrack_dashboard_order'=>$r['dashboard_order'], '_claimtrack_show_dashboard'=>$r['show_dashboard'], '_claimtrack_active'=>$r['active'],
                    '_claimtrack_created_at'=>$r['created_at'], '_claimtrack_updated_at'=>$r['updated_at'],
                ),
            );
        });
        self::sync_cpt_type('ct_provider', $providers, function($r) {
            return array(
                'title' => $r['name'],
                'meta' => array(
                    '_claimtrack_code'=>$r['code'], '_claimtrack_name'=>$r['name'], '_claimtrack_sort_order'=>$r['sort_order'], '_claimtrack_active'=>$r['active'],
                    '_claimtrack_created_at'=>$r['created_at'], '_claimtrack_updated_at'=>$r['updated_at'],
                ),
            );
        });
        self::sync_cpt_type('ct_entry', $entries, function($r) use ($unit_names,$program_names,$provider_names) {
            $uid=(int)$r['unit_id']; $pid=(int)$r['program_id']; $prid=(int)$r['provider_id'];
            $unit=$unit_names[$uid]??('Unit #'.$uid); $program=$program_names[$pid]??('Program #'.$pid); $provider=$provider_names[$prid]??('Mitra #'.$prid);
            return array(
                'title' => sprintf('%s | %s | %s | %02d/%d | Minggu %d', $unit, $program, $provider, (int)$r['month'], (int)$r['year'], (int)$r['week']),
                'meta' => array(
                    '_claimtrack_unit_id'=>$uid, '_claimtrack_unit_name'=>$unit,
                    '_claimtrack_program_id'=>$pid, '_claimtrack_program_name'=>$program,
                    '_claimtrack_provider_id'=>$prid, '_claimtrack_provider_name'=>$provider,
                    '_claimtrack_year'=>$r['year'], '_claimtrack_month'=>$r['month'], '_claimtrack_week'=>$r['week'],
                    '_claimtrack_amount_million'=>$r['amount_million'], '_claimtrack_note'=>$r['note'],
                    '_claimtrack_created_at'=>$r['created_at'], '_claimtrack_updated_at'=>$r['updated_at'],
                ),
            );
        });

        delete_option('claimtrack_cpt_sync_pending');
        update_option('claimtrack_cpt_mirror_version', self::DB_VERSION, false);
        update_option('claimtrack_cpt_last_sync', current_time('mysql'), false);
        return true;
    }

    private static function sync_cpt_type($post_type, $rows, $builder) {
        $existing = get_posts(array('post_type'=>$post_type,'post_status'=>'any','posts_per_page'=>-1,'fields'=>'ids','orderby'=>'ID','order'=>'ASC','no_found_rows'=>true));
        $map = array();
        foreach ($existing as $post_id) {
            $source_id = (int)get_post_meta($post_id, '_claimtrack_source_id', true);
            if ($source_id > 0) { $map[$source_id] = (int)$post_id; }
        }
        $seen = array();
        foreach ($rows as $row) {
            $source_id = (int)($row['id'] ?? 0); if ($source_id <= 0) { continue; }
            $built = call_user_func($builder, $row);
            $postarr = array('post_type'=>$post_type,'post_status'=>'publish','post_title'=>sanitize_text_field((string)($built['title'] ?? ('Record #'.$source_id))));
            if (!empty($map[$source_id])) {
                $postarr['ID'] = $map[$source_id];
                $post_id = wp_update_post($postarr, true);
            } else {
                $post_id = wp_insert_post($postarr, true);
            }
            if (is_wp_error($post_id) || !$post_id) { continue; }
            $post_id = (int)$post_id;
            update_post_meta($post_id, '_claimtrack_mirror', '1');
            update_post_meta($post_id, '_claimtrack_source_id', $source_id);
            update_post_meta($post_id, '_claimtrack_source_table', $post_type);
            foreach ((array)($built['meta'] ?? array()) as $key=>$value) { update_post_meta($post_id, $key, $value); }
            $seen[$source_id] = true;
        }
        foreach ($map as $source_id=>$post_id) {
            if (empty($seen[$source_id])) { wp_delete_post($post_id, true); }
        }
    }

    public static function normalize_code($value) {
        $value = strtoupper(trim((string) $value));
        $value = preg_replace('/[^A-Z0-9_-]+/', '_', $value);
        return trim($value, '_');
    }

    public static function unique_code($table_key, $base) {
        global $wpdb;
        $t = self::tables();
        if (!isset($t[$table_key])) { return self::normalize_code($base); }
        $base = self::normalize_code($base);
        if ($base === '') { $base = 'ITEM'; }
        $code = substr($base, 0, 36);
        $i = 2;
        while ($wpdb->get_var($wpdb->prepare("SELECT id FROM {$t[$table_key]} WHERE code=%s LIMIT 1", $code))) {
            $suffix = '_' . $i++;
            $code = substr($base, 0, 40 - strlen($suffix)) . $suffix;
        }
        return $code;
    }
}
