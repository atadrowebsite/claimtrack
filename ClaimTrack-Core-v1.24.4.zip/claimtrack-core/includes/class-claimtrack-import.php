<?php
if (!defined('ABSPATH')) { exit; }

class ClaimTrack_Import {
    public static function import_file($path, $filename) {
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        if (!in_array($ext, array('csv','xlsx'), true)) {
            return new WP_Error('ct_file_type', 'Format file harus CSV atau XLSX.');
        }
        if (!file_exists($path) || filesize($path) > 20 * 1024 * 1024) {
            return new WP_Error('ct_file_size', 'File tidak ditemukan atau melebihi 20 MB.');
        }
        $rows = ($ext === 'csv') ? self::read_csv($path) : self::read_xlsx($path);
        if (is_wp_error($rows)) { return $rows; }
        if (count($rows) < 2) {
            return new WP_Error('ct_empty', 'File tidak memiliki data yang dapat diimpor.');
        }
        return self::process_rows($rows);
    }

    private static function read_csv($path) {
        $fh = fopen($path, 'rb');
        if (!$fh) { return new WP_Error('ct_csv_open', 'CSV tidak dapat dibaca.'); }

        $first = fgets($fh);
        if ($first === false) { fclose($fh); return array(); }
        $firstClean = preg_replace('/^\xEF\xBB\xBF/', '', trim($first));
        $declaredDelimiter = null;
        if (preg_match('/^sep=(.)$/i', $firstClean, $m)) {
            $declaredDelimiter = $m[1];
            $sample = fgets($fh);
            if ($sample === false) { fclose($fh); return array(); }
        } else {
            $sample = $first;
        }

        $delims = array(',', ';', "\t");
        if ($declaredDelimiter !== null) {
            $best = $declaredDelimiter;
        } else {
            $best = ','; $best_count = -1;
            foreach ($delims as $d) {
                $c = count(str_getcsv($sample, $d));
                if ($c > $best_count) { $best_count = $c; $best = $d; }
            }
        }

        rewind($fh);
        $rows = array();
        $lineNumber = 0;
        while (($row = fgetcsv($fh, 0, $best)) !== false) {
            $lineNumber++;
            if ($lineNumber === 1 && isset($row[0])) {
                $row[0] = preg_replace('/^\xEF\xBB\xBF/', '', $row[0]);
                if (preg_match('/^sep=/i', trim((string)$row[0]))) { continue; }
            }
            if (count($rows) === 0 && isset($row[0])) {
                $row[0] = preg_replace('/^\xEF\xBB\xBF/', '', $row[0]);
            }
            $rows[] = $row;
            if (count($rows) > 50001) { fclose($fh); return new WP_Error('ct_too_many_rows', 'Maksimal 50.000 baris per impor.'); }
        }
        fclose($fh);
        return $rows;
    }

    private static function archive_get($path, $name) {
        if (class_exists('ZipArchive')) {
            $zip = new ZipArchive();
            if ($zip->open($path) !== true) { return false; }
            $data = $zip->getFromName($name);
            $zip->close();
            return $data;
        }
        if (!class_exists('PclZip')) {
            $pcl = ABSPATH . 'wp-admin/includes/class-pclzip.php';
            if (file_exists($pcl)) { require_once $pcl; }
        }
        if (class_exists('PclZip')) {
            $archive = new PclZip($path);
            $list = $archive->extract(PCLZIP_OPT_BY_NAME, $name, PCLZIP_OPT_EXTRACT_AS_STRING);
            if (is_array($list) && !empty($list[0]['content'])) { return $list[0]['content']; }
        }
        return false;
    }

    private static function read_xlsx($path) {
        $sheetPath = 'xl/worksheets/sheet1.xml';
        $workbook = self::archive_get($path, 'xl/workbook.xml');
        $rels = self::archive_get($path, 'xl/_rels/workbook.xml.rels');
        if (!$workbook) {
            return new WP_Error('ct_xlsx_open', 'XLSX tidak dapat dibuka. Pastikan file tidak rusak.');
        }
        if ($workbook && $rels && strpos($workbook, '<!DOCTYPE') === false && strpos($rels, '<!DOCTYPE') === false) {
            $wb = @simplexml_load_string($workbook, 'SimpleXMLElement', LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING);
            $rs = @simplexml_load_string($rels, 'SimpleXMLElement', LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING);
            if ($wb && $rs) {
                $wb->registerXPathNamespace('m', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main');
                $wb->registerXPathNamespace('r', 'http://schemas.openxmlformats.org/officeDocument/2006/relationships');
                $sheets = $wb->xpath('//m:sheets/m:sheet');
                if ($sheets) {
                    $attrs = $sheets[0]->attributes('http://schemas.openxmlformats.org/officeDocument/2006/relationships');
                    $rid = (string) $attrs['id'];
                    $relChildren = $rs->children('http://schemas.openxmlformats.org/package/2006/relationships');
                    foreach ($relChildren->Relationship as $rel) {
                        if ((string)$rel['Id'] === $rid) {
                            $target = (string)$rel['Target'];
                            if (strpos($target, '/') === 0) {
                                $sheetPath = ltrim($target, '/');
                            } else {
                                $sheetPath = 'xl/' . ltrim($target, '/');
                            }
                            $sheetPath = preg_replace('#(^|/)\.\./#', '$1', $sheetPath);
                            break;
                        }
                    }
                }
            }
        }

        $shared = array();
        $ssXml = self::archive_get($path, 'xl/sharedStrings.xml');
        if ($ssXml && strpos($ssXml, '<!DOCTYPE') === false) {
            $ss = @simplexml_load_string($ssXml, 'SimpleXMLElement', LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING);
            if ($ss) {
                $ssChildren = $ss->children('http://schemas.openxmlformats.org/spreadsheetml/2006/main');
                foreach ($ssChildren->si as $si) {
                    $sic = $si->children('http://schemas.openxmlformats.org/spreadsheetml/2006/main');
                    if (isset($sic->t)) {
                        $shared[] = (string)$sic->t;
                    } else {
                        $text = '';
                        foreach ($sic->r as $r) {
                            $rc = $r->children('http://schemas.openxmlformats.org/spreadsheetml/2006/main');
                            $text .= (string)$rc->t;
                        }
                        $shared[] = $text;
                    }
                }
            }
        }

        $xml = self::archive_get($path, $sheetPath);
        if (!$xml || strpos($xml, '<!DOCTYPE') !== false) {
            return new WP_Error('ct_xlsx_sheet', 'Worksheet pertama XLSX tidak dapat dibaca.');
        }
        $sx = @simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING);
        if (!$sx) { return new WP_Error('ct_xlsx_xml', 'Struktur XLSX tidak valid.'); }
        $sx->registerXPathNamespace('m', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main');
        $xmlRows = $sx->xpath('//m:sheetData/m:row');
        $rows = array();
        $mainNs = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
        foreach ($xmlRows as $row) {
            $out = array();
            $rowChildren = $row->children($mainNs);
            foreach ($rowChildren->c as $cell) {
                $ref = (string)$cell['r'];
                $letters = preg_replace('/\d+/', '', $ref);
                $idx = self::column_index($letters);
                $type = (string)$cell['t'];
                $cc = $cell->children($mainNs);
                $value = '';
                if ($type === 's') {
                    $si = (int)$cc->v;
                    $value = isset($shared[$si]) ? $shared[$si] : '';
                } elseif ($type === 'inlineStr' && isset($cc->is)) {
                    $isc = $cc->is->children($mainNs);
                    if (isset($isc->t)) {
                        $value = (string)$isc->t;
                    } else {
                        foreach ($isc->r as $rnode) {
                            $rc = $rnode->children($mainNs);
                            $value .= (string)$rc->t;
                        }
                    }
                } else {
                    $value = isset($cc->v) ? (string)$cc->v : '';
                }
                $out[$idx] = $value;
            }
            if ($out) {
                $max = max(array_keys($out));
                $line = array();
                for ($i=0; $i <= $max; $i++) { $line[] = isset($out[$i]) ? $out[$i] : ''; }
                $rows[] = $line;
            }
            if (count($rows) > 50001) { return new WP_Error('ct_too_many_rows', 'Maksimal 50.000 baris per impor.'); }
        }
        return $rows;
    }

    private static function column_index($letters) {
        $letters = strtoupper($letters);
        $n = 0;
        for ($i=0; $i<strlen($letters); $i++) { $n = $n * 26 + (ord($letters[$i]) - 64); }
        return max(0, $n - 1);
    }

    private static function norm_header($h) {
        $h = strtolower(trim((string)$h));
        $h = str_replace(array(' ', '-', '/', '.', '(', ')'), '_', $h);
        $h = preg_replace('/_+/', '_', $h);
        return trim($h, '_');
    }

    private static function month_number($v) {
        $v = strtolower(trim((string)$v));
        if ($v === '') { return 0; }
        if (is_numeric($v)) { $n = (int)$v; return ($n >= 1 && $n <= 12) ? $n : 0; }
        $map = array(
            'januari'=>1,'jan'=>1,'februari'=>2,'feb'=>2,'maret'=>3,'mar'=>3,'april'=>4,'apr'=>4,
            'mei'=>5,'may'=>5,'juni'=>6,'jun'=>6,'juli'=>7,'jul'=>7,'agustus'=>8,'ags'=>8,'aug'=>8,
            'september'=>9,'sep'=>9,'oktober'=>10,'okt'=>10,'oct'=>10,'november'=>11,'nov'=>11,'desember'=>12,'des'=>12,'dec'=>12
        );
        return isset($map[$v]) ? $map[$v] : 0;
    }

    private static function week_number($v) {
        $v = strtoupper(trim((string)$v));
        $v = str_replace(array('MINGGU','WEEK','KE-','KE'), '', $v);
        $v = trim($v);
        $map = array('I'=>1,'II'=>2,'III'=>3,'IV'=>4,'1'=>1,'2'=>2,'3'=>3,'4'=>4);
        return isset($map[$v]) ? $map[$v] : 0;
    }

    private static function number_value($v) {
        if (is_numeric($v)) { return (float)$v; }
        $v = trim((string)$v);
        if ($v === '') { return 0.0; }
        $v = preg_replace('/[^0-9,\.\-]/', '', $v);
        $hasComma = strpos($v, ',') !== false;
        $hasDot = strpos($v, '.') !== false;
        if ($hasComma && $hasDot) {
            if (strrpos($v, ',') > strrpos($v, '.')) { $v = str_replace('.', '', $v); $v = str_replace(',', '.', $v); }
            else { $v = str_replace(',', '', $v); }
        } elseif ($hasComma) {
            $parts = explode(',', $v);
            if (count($parts) === 2 && strlen($parts[1]) <= 2) { $v = str_replace(',', '.', $v); }
            else { $v = str_replace(',', '', $v); }
        }
        return (float)$v;
    }

    private static function process_rows($rows) {
        global $wpdb;
        $t = ClaimTrack_DB::tables();
        $headers = array_map(array(__CLASS__, 'norm_header'), $rows[0]);
        $aliases = array(
            'year'=>array('tahun','year'),
            'month'=>array('bulan','month'),
            'week'=>array('minggu','week'),
            'unit_code'=>array('unit_code','kode_unit','kode_unit_kerja'),
            'unit_name'=>array('unit_name','unit_kerja','nama_unit','nama_unit_kerja'),
            'program_code'=>array('program_code','kode_program'),
            'program_name'=>array('program_name','program','nama_program'),
            'provider_code'=>array('provider_code','kode_mitra','kode_asuransi'),
            'provider_name'=>array('provider_name','mitra','asuransi','nama_mitra','nama_asuransi'),
            'amount'=>array('amount','nominal','nilai','nilai_juta','nominal_juta','amount_million'),
            'note'=>array('note','catatan','keterangan'),
        );
        $idx = array();
        foreach ($aliases as $key => $opts) {
            foreach ($opts as $o) {
                $pos = array_search($o, $headers, true);
                if ($pos !== false) { $idx[$key] = $pos; break; }
            }
        }
        foreach (array('year','month','week','unit_name','program_name','provider_name','amount') as $required) {
            if (!isset($idx[$required])) {
                return new WP_Error('ct_columns', 'Kolom wajib tidak lengkap. Gunakan template ClaimTrack: Tahun, Bulan, Minggu, Unit Kerja, Program, Mitra, Nominal.');
            }
        }

        $now = current_time('mysql');
        $imported = 0; $skipped = 0; $errors = array();
        $cache = array('units'=>array(),'programs'=>array(),'providers'=>array());

        for ($r=1; $r<count($rows); $r++) {
            $row = $rows[$r];
            $get = function($k) use ($row, $idx) { return isset($idx[$k], $row[$idx[$k]]) ? trim((string)$row[$idx[$k]]) : ''; };
            if (implode('', array_map('trim', $row)) === '') { continue; }
            $year = (int)$get('year');
            $month = self::month_number($get('month'));
            $week = self::week_number($get('week'));
            $unitName = sanitize_text_field($get('unit_name'));
            $programName = sanitize_text_field($get('program_name'));
            $providerName = sanitize_text_field($get('provider_name'));
            $amountRaw = $get('amount');
            // Baris template yang belum diisi nominal tidak membuat record nol di database.
            if (trim((string)$amountRaw) === '') { continue; }
            $amount = self::number_value($amountRaw);
            $note = isset($idx['note']) ? sanitize_text_field($get('note')) : '';
            if ($year < 2000 || $year > 2100 || !$month || !$week || $unitName === '' || $programName === '' || $providerName === '') {
                $skipped++; if (count($errors) < 5) { $errors[] = 'Baris ' . ($r+1) . ' dilewati karena periode/master data tidak valid.'; } continue;
            }

            $unitCode = isset($idx['unit_code']) ? ClaimTrack_DB::normalize_code($get('unit_code')) : '';
            $programCode = isset($idx['program_code']) ? ClaimTrack_DB::normalize_code($get('program_code')) : '';
            $providerCode = isset($idx['provider_code']) ? ClaimTrack_DB::normalize_code($get('provider_code')) : '';
            $unitId = self::master_id('units', $unitCode, $unitName, $cache, $now);
            $programId = self::master_id('programs', $programCode, $programName, $cache, $now);
            $providerId = self::master_id('providers', $providerCode, $providerName, $cache, $now);
            if (!$unitId || !$programId || !$providerId) { $skipped++; continue; }

            $sql = $wpdb->prepare(
                "INSERT INTO {$t['entries']} (unit_id,program_id,provider_id,year,month,week,amount_million,note,created_at,updated_at)
                 VALUES (%d,%d,%d,%d,%d,%d,%f,%s,%s,%s)
                 ON DUPLICATE KEY UPDATE amount_million=VALUES(amount_million), note=VALUES(note), updated_at=VALUES(updated_at)",
                $unitId,$programId,$providerId,$year,$month,$week,$amount,$note,$now,$now
            );
            $ok = $wpdb->query($sql);
            if ($ok === false) { $skipped++; if (count($errors) < 5) { $errors[] = 'Baris ' . ($r+1) . ' gagal disimpan.'; } }
            else { $imported++; }
        }
        return array('imported'=>$imported, 'skipped'=>$skipped, 'errors'=>$errors);
    }

    private static function master_id($type, $code, $name, &$cache, $now) {
        global $wpdb;
        $t = ClaimTrack_DB::tables();
        $table = $t[$type];
        $cacheKey = ($code ?: strtolower($name));
        if (isset($cache[$type][$cacheKey])) { return $cache[$type][$cacheKey]; }
        $id = 0;
        if ($code) { $id = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE code=%s LIMIT 1", $code)); }
        if (!$id) { $id = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE name=%s LIMIT 1", $name)); }
        if (!$id) {
            if (!$code) { $code = ClaimTrack_DB::unique_code($type, $name); }
            if ($type === 'programs') {
                $wpdb->insert($table, array('code'=>$code,'phase_label'=>'','name'=>$name,'color'=>'#23b653','dashboard_order'=>999,'show_dashboard'=>0,'active'=>1,'created_at'=>$now,'updated_at'=>$now), array('%s','%s','%s','%s','%d','%d','%d','%s','%s'));
            } else {
                $wpdb->insert($table, array('code'=>$code,'name'=>$name,'sort_order'=>999,'active'=>1,'created_at'=>$now,'updated_at'=>$now), array('%s','%s','%d','%d','%s','%s'));
            }
            $id = (int)$wpdb->insert_id;
        }
        $cache[$type][$cacheKey] = $id;
        return $id;
    }
}
