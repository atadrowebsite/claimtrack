<?php
if (!defined('ABSPATH')) { exit; }

class ClaimTrack_App {
    private static $login_error = '';
    private static $route_not_found = false;
    private static $resolved_route = null;
    private static $admin_portal = false;

    public static function init() {
        add_shortcode('claimtrack_app', array(__CLASS__, 'shortcode'));
        add_action('template_redirect', array(__CLASS__, 'validate_route'), 3);
        add_action('template_redirect', array(__CLASS__, 'handle_frontend_login'), 4);
        add_action('template_redirect', array(__CLASS__, 'handle_actions'), 10);
        add_action('wp_enqueue_scripts', array(__CLASS__, 'enqueue'));
        add_filter('template_include', array(__CLASS__, 'template_include'), PHP_INT_MAX);
        add_filter('show_admin_bar', '__return_false', PHP_INT_MAX);
        add_action('init', array(__CLASS__, 'enforce_user_policy'), 35);
        add_action('set_user_role', array(__CLASS__, 'guard_user_role'), 100, 3);
        add_action('user_register', array(__CLASS__, 'guard_new_user'), 100, 1);
        add_action('admin_init', array(__CLASS__, 'block_wp_admin_for_claimtrack_users'), 1);
        add_filter('login_redirect', array(__CLASS__, 'filter_login_redirect'), 20, 3);
    }

    public static function maybe_hide_admin_bar($show) {
        return false;
    }

    private static function settings_defaults() {
        return array(
            'dashboard_title'=>'DASHBOARD MONITORING KLAIM DALAM PROSES',
            'department'=>'Commercial Credit Operation Department',
            'region_label'=>'REGION 18',
            'input_unit'=>'Juta Rupiah',
            'turnstile_enabled'=>0,
            'turnstile_site_key'=>'',
            'turnstile_secret_key'=>'',
            'admin_whatsapp'=>'',
            'logo_id'=>0,
            'logo_url'=>'',
            'color_sidebar'=>'#0c2545',
            'color_sidebar_deep'=>'#081a31',
            'color_header'=>'#0b2038',
            'color_nav_active'=>'#153a66',
            'color_sidebar_line'=>'#163863',
            'color_workspace'=>'#dce3ed',
            'color_panel'=>'#ffffff',
            'color_kpi'=>'#229e55',
            'color_kpi_dark'=>'#198644',
            'color_kpi_border'=>'#33cb6d',
            'color_button'=>'#0f4277',
            'color_table'=>'#0f62ac',
            'color_table_sub'=>'#1573c9',
            'color_phase_table'=>'#2a124d',
            'color_phase_table_sub'=>'#351960',
            'color_danger'=>'#e74c3c',
            'color_text'=>'#333333',
            'color_muted'=>'#8fa0b5',
            'color_login_blue'=>'#084c7a',
            'color_login_footer'=>'#000000',
            'color_login_button'=>'#0877c9',
        );
    }

    private static function get_settings() {
        return wp_parse_args(get_option('claimtrack_settings',array()), self::settings_defaults());
    }

    private static function logo_url($settings = null,$fallback='dashboard') {
        if (!is_array($settings)) { $settings=self::get_settings(); }
        $id=absint($settings['logo_id']??0);
        $url=$id?wp_get_attachment_image_url($id,'full'):'';
        if (!$url) { $url=esc_url_raw((string)($settings['logo_url']??'')); }
        if($url){ return $url; }
        $fallbacks=array(
            'login'=>'claimtrack-logo-login.jpg',
            'admin'=>'claimtrack-logo.png',
            'default'=>'claimtrack-logo.png',
            'dashboard'=>'claimtrack-logo-dashboard.png',
        );
        return CLAIMTRACK_URL.'assets/'.($fallbacks[$fallback]??$fallbacks['dashboard']);
    }

    private static function mix_hex_colors($a, $b) {
        $a=sanitize_hex_color((string)$a) ?: '#000000';
        $b=sanitize_hex_color((string)$b) ?: '#000000';
        $ar=hexdec(substr($a,1,2)); $ag=hexdec(substr($a,3,2)); $ab=hexdec(substr($a,5,2));
        $br=hexdec(substr($b,1,2)); $bg=hexdec(substr($b,3,2)); $bb=hexdec(substr($b,5,2));
        return sprintf('#%02x%02x%02x',(int)round(($ar+$br)/2),(int)round(($ag+$bg)/2),(int)round(($ab+$bb)/2));
    }

    private static function readable_text_color($hex) {
        $hex=sanitize_hex_color((string)$hex) ?: '#000000';
        $rgb=array(hexdec(substr($hex,1,2))/255,hexdec(substr($hex,3,2))/255,hexdec(substr($hex,5,2))/255);
        foreach($rgb as &$c){ $c=($c<=0.03928)?($c/12.92):pow(($c+0.055)/1.055,2.4); }
        unset($c);
        $luminance=(0.2126*$rgb[0])+(0.7152*$rgb[1])+(0.0722*$rgb[2]);
        return $luminance>0.48 ? '#13263a' : '#ffffff';
    }

    private static function theme_style_vars($settings = null) {
        if (!is_array($settings)) { $settings = self::get_settings(); }
        $map=array(
            '--ct-ref-navy'=>'color_sidebar',
            '--ct-ref-sidebar'=>'color_sidebar',
            '--ct-ref-navy-deep'=>'color_sidebar_deep',
            '--ct-ref-sidebar-dark'=>'color_sidebar_deep',
            '--ct-ref-header'=>'color_header',
            '--ct-ref-header-2'=>'color_header',
            '--ct-ref-nav-active'=>'color_nav_active',
            '--ct-ref-nav-hover'=>'color_nav_active',
            '--ct-ref-sidebar-line'=>'color_sidebar_line',
            '--ct-ref-workspace'=>'color_workspace',
            '--ct-ref-workspace-2'=>'color_workspace',
            '--ct-ref-panel'=>'color_panel',
            '--ct-ref-green'=>'color_kpi',
            '--ct-ref-green-2'=>'color_kpi_dark',
            '--ct-ref-green-border'=>'color_kpi_border',
            '--ct-ref-blue'=>'color_button',
            '--ct-ref-blue-2'=>'color_table',
            '--ct-ref-blue-sub'=>'color_table_sub',
            '--ct-ref-purple'=>'color_phase_table',
            '--ct-ref-purple-sub'=>'color_phase_table_sub',
            '--ct-ref-red'=>'color_danger',
            '--ct-ref-text'=>'color_text',
            '--ct-ref-muted'=>'color_muted',
            '--ct-login-blue'=>'color_login_blue',
            '--ct-login-footer'=>'color_login_footer',
            '--ct-login-button'=>'color_login_button',
        );
        $parts=array();
        foreach($map as $var=>$key){
            $fallback=self::settings_defaults()[$key];
            $value=sanitize_hex_color((string)($settings[$key]??$fallback)) ?: $fallback;
            $parts[]=$var.':'.$value;
        }
        $kpi_a=sanitize_hex_color((string)($settings['color_kpi']??self::settings_defaults()['color_kpi'])) ?: self::settings_defaults()['color_kpi'];
        $kpi_b=sanitize_hex_color((string)($settings['color_kpi_dark']??self::settings_defaults()['color_kpi_dark'])) ?: self::settings_defaults()['color_kpi_dark'];
        $parts[]='--ct-ref-kpi-text:'.self::readable_text_color(self::mix_hex_colors($kpi_a,$kpi_b));
        return implode(';',$parts);
    }

    /**
     * Paksa ClaimTrack memakai template aplikasi milik plugin.
     * Dengan cara ini tampilan tidak bergantung pada theme yang sedang aktif
     * dan halaman depan tidak akan jatuh kembali ke blog WordPress/Hello world.
     */
    public static function template_include($template) {
        if (!self::is_app_page()) { return $template; }
        $app_template = CLAIMTRACK_PATH . 'templates/app.php';
        return is_readable($app_template) ? $app_template : $template;
    }

    private static function is_app_page() {
        if (is_front_page()) { return true; }
        if (!is_singular()) { return false; }
        global $post;
        return ($post instanceof WP_Post) && has_shortcode((string)$post->post_content, 'claimtrack_app');
    }

    public static function enqueue() {
        if (!self::is_app_page()) { return; }
        wp_enqueue_style('dashicons');
        wp_enqueue_style('claimtrack-app', CLAIMTRACK_URL . 'assets/css/app.css', array('dashicons'), CLAIMTRACK_VERSION);
        wp_enqueue_style('claimtrack-monitoring', CLAIMTRACK_URL . 'assets/css/monitoring.css', array('claimtrack-app'), CLAIMTRACK_VERSION);
        wp_enqueue_script('claimtrack-app', CLAIMTRACK_URL . 'assets/js/app.js', array(), CLAIMTRACK_VERSION, true);
        if (self::is_admin_portal_request() && is_user_logged_in() && self::can_manage() && function_exists('wp_enqueue_editor')) {
            wp_enqueue_editor();
        }
    }

    private static function primary_admin_login() {
        return 'atadro';
    }

    private static function is_primary_admin_user($user = null) {
        if ($user === null) { $user = wp_get_current_user(); }
        return ($user instanceof WP_User)
            && $user->exists()
            && strtolower((string)$user->user_login) === self::primary_admin_login();
    }

    private static function is_claimtrack_admin_user($user = null) {
        if ($user === null) { $user = wp_get_current_user(); }
        return ($user instanceof WP_User)
            && $user->exists()
            && in_array('claimtrack_admin', (array)$user->roles, true);
    }

    private static function user_access_label($user = null) {
        if ($user === null) { $user = wp_get_current_user(); }
        if (self::is_primary_admin_user($user)) { return 'Super Admin'; }
        if (self::is_claimtrack_admin_user($user)) { return 'Administrator'; }
        return 'Viewer';
    }

    private static function can_view() {
        return current_user_can('claimtrack_view') || self::is_primary_admin_user();
    }
    private static function can_manage() {
        // Super Admin atadro dan satu ClaimTrack Admin mempunyai akses penuh ke SW Admin.
        return self::is_primary_admin_user() || self::is_claimtrack_admin_user();
    }
    private static function can_import_export() {
        return self::can_manage();
    }

    /**
     * Kebijakan akun ClaimTrack:
     * - atadro tetap menjadi satu-satunya Administrator WordPress / Super Admin.
     * - satu akun ClaimTrack Admin dapat mengelola seluruh SW Admin, tetapi tidak dapat membuka wp-admin.
     * - akun ClaimTrack lainnya menjadi Viewer.
     */
    public static function enforce_user_policy() {
        static $running = false;
        if ($running) { return; }
        $running = true;

        if (!get_role('claimtrack_viewer')) {
            add_role('claimtrack_viewer', 'ClaimTrack Viewer', array(
                'read'=>true,
                'claimtrack_view'=>true,
            ));
        }
        if (!get_role('claimtrack_admin')) {
            add_role('claimtrack_admin', 'ClaimTrack Admin', array(
                'read'=>true,
                'upload_files'=>true,
                'claimtrack_view'=>true,
                'claimtrack_manage'=>true,
                'claimtrack_import_export'=>true,
            ));
        } else {
            $role = get_role('claimtrack_admin');
            if ($role) {
                foreach (array('read','upload_files','claimtrack_view','claimtrack_manage','claimtrack_import_export') as $cap) {
                    $role->add_cap($cap, true);
                }
                // Tidak pernah beri capability backend inti pada ClaimTrack Admin.
                foreach (array('manage_options','edit_users','create_users','delete_users','promote_users','install_plugins','activate_plugins','edit_plugins','switch_themes') as $cap) {
                    $role->remove_cap($cap);
                }
            }
        }

        $primary = get_user_by('login', self::primary_admin_login());
        if ($primary instanceof WP_User) {
            if (!in_array('administrator', (array)$primary->roles, true)) {
                $primary->set_role('administrator');
            }
            $primary->add_cap('claimtrack_view');
            $primary->add_cap('claimtrack_manage');
            $primary->add_cap('claimtrack_import_export');

            if (is_multisite() && function_exists('grant_super_admin') && !is_super_admin($primary->ID)) {
                grant_super_admin($primary->ID);
            }
        }

        // Pertahankan tepat satu ClaimTrack Admin non-atadro. Prioritas:
        // role claimtrack_admin yang sudah ada, username "admin", lalu role manager/admin legacy.
        $candidates = array();
        foreach (get_users(array('role'=>'claimtrack_admin','orderby'=>'ID','order'=>'ASC')) as $u) {
            if (!self::is_primary_admin_user($u)) { $candidates[(int)$u->ID] = $u; }
        }
        $named_admin = get_user_by('login', 'admin');
        if ($named_admin instanceof WP_User && !self::is_primary_admin_user($named_admin)) {
            $candidates = array((int)$named_admin->ID => $named_admin) + $candidates;
        }
        foreach (get_users(array('role__in'=>array('claimtrack_manager','administrator'),'orderby'=>'ID','order'=>'ASC')) as $u) {
            if (!self::is_primary_admin_user($u)) { $candidates[(int)$u->ID] = $u; }
        }

        $admin_id = 0;
        if ($candidates) {
            $first = reset($candidates);
            if ($first instanceof WP_User) { $admin_id = (int)$first->ID; }
        }

        // Bersihkan role privileged lain terlebih dahulu agar promosi admin terpilih
        // tidak bertabrakan dengan guard set_user_role.
        $privileged = get_users(array('role__in'=>array('administrator','claimtrack_manager','claimtrack_admin')));
        foreach ($privileged as $account) {
            if (self::is_primary_admin_user($account)) { continue; }
            if ($admin_id > 0 && (int)$account->ID === $admin_id) { continue; }
            $account->set_role('claimtrack_viewer');
            foreach (array('claimtrack_manage','claimtrack_import_export','manage_options','upload_files') as $cap) { $account->remove_cap($cap); }
            $account->add_cap('claimtrack_view');
        }

        if ($admin_id > 0) {
            $admin_user = get_userdata($admin_id);
            if ($admin_user instanceof WP_User) {
                if (!in_array('claimtrack_admin', (array)$admin_user->roles, true)) { $admin_user->set_role('claimtrack_admin'); }
                $admin_user->add_cap('claimtrack_view');
                $admin_user->add_cap('claimtrack_manage');
                $admin_user->add_cap('claimtrack_import_export');
                $admin_user->add_cap('upload_files');
                foreach (array('manage_options','edit_users','create_users','delete_users','promote_users','install_plugins','activate_plugins','edit_plugins','switch_themes') as $cap) {
                    $admin_user->remove_cap($cap);
                }
            }
        }

        if (get_role('claimtrack_manager')) { remove_role('claimtrack_manager'); }
        $running = false;
    }

    public static function guard_new_user($user_id) {
        self::apply_account_policy((int)$user_id);
    }

    public static function guard_user_role($user_id, $role, $old_roles) {
        self::apply_account_policy((int)$user_id);
    }

    private static function apply_account_policy($user_id) {
        static $guard = false;
        if ($guard || $user_id <= 0) { return; }
        $user = get_userdata($user_id);
        if (!($user instanceof WP_User)) { return; }
        $guard = true;

        if (self::is_primary_admin_user($user)) {
            if (!in_array('administrator', (array)$user->roles, true)) { $user->set_role('administrator'); }
            $user->add_cap('claimtrack_view');
            $user->add_cap('claimtrack_manage');
            $user->add_cap('claimtrack_import_export');
            $guard = false;
            return;
        }

        // Bila role backend/manager diberikan ke user non-atadro, map ke satu role
        // ClaimTrack Admin jika slot admin aplikasi belum terisi. Jika sudah ada, jadi Viewer.
        $wants_admin = in_array('claimtrack_admin',(array)$user->roles,true)
            || in_array('administrator',(array)$user->roles,true)
            || in_array('claimtrack_manager',(array)$user->roles,true)
            || $user->has_cap('claimtrack_manage');

        if ($wants_admin) {
            $existing = get_users(array('role'=>'claimtrack_admin','exclude'=>array($user_id),'number'=>1,'fields'=>'ids'));
            if (!$existing) {
                $user->set_role('claimtrack_admin');
                $user->add_cap('claimtrack_view');
                $user->add_cap('claimtrack_manage');
                $user->add_cap('claimtrack_import_export');
                $user->add_cap('upload_files');
                foreach (array('manage_options','edit_users','create_users','delete_users','promote_users','install_plugins','activate_plugins','edit_plugins','switch_themes') as $cap) { $user->remove_cap($cap); }
            } else {
                $user->set_role('claimtrack_viewer');
                foreach (array('claimtrack_manage','claimtrack_import_export','manage_options','upload_files') as $cap) { $user->remove_cap($cap); }
                $user->add_cap('claimtrack_view');
            }
        }
        $guard = false;
    }

    public static function block_wp_admin_for_claimtrack_users() {
        if (!is_user_logged_in() || self::is_primary_admin_user()) { return; }
        if (wp_doing_ajax()) { return; }
        $user = wp_get_current_user();
        if (!($user instanceof WP_User) || !$user->exists()) { return; }
        if ($user->has_cap('claimtrack_view') || self::is_claimtrack_admin_user($user)) {
            wp_safe_redirect(self::app_url(array('view'=>'dashboard')));
            exit;
        }
    }

    public static function filter_login_redirect($redirect_to, $requested_redirect_to, $user) {
        if (!($user instanceof WP_User) || !$user->exists()) { return $redirect_to; }
        if (self::is_primary_admin_user($user)) { return $redirect_to; }
        if ($user->has_cap('claimtrack_view') || self::is_claimtrack_admin_user($user)) {
            return self::app_url(array('view'=>'dashboard'));
        }
        return $redirect_to;
    }

    private static function admin_portal_url($section = 'overview', $args = array()) {
        $section = sanitize_key((string)$section);
        $allowed = array('overview','phase1','phase2','phase3','subrogation','achievement','news','news_list','matrix','units','programs','providers','knowledge','import','settings','users','debitur');
        $allowed = array_merge($allowed, array_keys(self::additional_menu_items()));
        if (!in_array($section, $allowed, true)) { $section = 'overview'; }
        $args = is_array($args) ? $args : array();
        if ($section !== 'overview') { $args = array_merge(array('section'=>$section), $args); }
        return ClaimTrack_DB::get_app_page_url('sw_admin', $args);
    }

    private static function is_admin_portal_request() {
        $route = self::resolve_route();
        return (($route['view'] ?? '') === 'admin');
    }

    private static function page_key_for_route($view, $program_id = 0) {
        $view = sanitize_key((string)$view);
        if ($view === 'phase') {
            global $wpdb;
            $t = ClaimTrack_DB::tables();
            $code = '';
            if ((int)$program_id > 0) {
                $code = (string)$wpdb->get_var($wpdb->prepare("SELECT code FROM {$t['programs']} WHERE id=%d LIMIT 1", (int)$program_id));
            }
            if ($code === 'KDP') { return 'phase_kdp'; }
            if ($code === 'DOK_LENGKAP') { return 'phase_dok_lengkap'; }
            if ($code === 'TERBUKU') { return 'phase_terbuku'; }
            return 'phase_kdp';
        }
        $map = array(
            'home' => 'home',
            'dashboard' => 'dashboard',
            'matrix' => 'matrix',
            'units' => 'units',
            'programs' => 'programs',
            'providers' => 'providers',
            'import' => 'import',
            'settings' => 'settings',
            'knowledge' => 'knowledge',
            'achievement' => 'achievement',
        );
        return $map[$view] ?? 'dashboard';
    }

    /**
     * URL menu selalu diarahkan ke WordPress Page yang sesuai.
     * Query string hanya dipakai untuk filter periode/edit, bukan sebagai router utama.
     */
    private static function app_url($args = array()) {
        $args = is_array($args) ? $args : array();
        $view = isset($args['view']) ? sanitize_key((string)$args['view']) : 'dashboard';
        $program_id = isset($args['program_id']) ? (int)$args['program_id'] : 0;
        if (self::$admin_portal && in_array($view,array('matrix','units','programs','providers','import','settings','knowledge'),true)) {
            unset($args['view']);
            return self::admin_portal_url($view,$args);
        }
        if (isset(self::additional_menu_items()[$view])) {
            return ClaimTrack_DB::get_app_page_url('dashboard', $args);
        }
        $page_key = self::page_key_for_route($view, $program_id);

        // Jika route sudah memiliki WordPress Page sendiri, bersihkan parameter router.
        unset($args['view']);
        if ($view === 'phase' && in_array($page_key, array('phase_kdp','phase_dok_lengkap','phase_terbuku'), true)) {
            unset($args['program_id']);
        }
        return ClaimTrack_DB::get_app_page_url($page_key, $args);
    }

    private static function resolve_route($refresh = false) {
        if (!$refresh && is_array(self::$resolved_route)) { return self::$resolved_route; }
        global $wpdb, $post;
        $t = ClaimTrack_DB::tables();
        $allowed = array_merge(array('home','dashboard','phase','matrix','units','programs','providers','import','settings','knowledge','achievement','admin'), array_keys(self::additional_menu_items()));

        $route = array(
            'view' => 'dashboard',
            'program_id' => 0,
            'program_code' => '',
            'year' => max(2000, min(2100, (int)wp_date('Y'))),
            'month' => max(1, min(12, (int)wp_date('n'))),
        );

        $post_id = get_queried_object_id();
        if (!$post_id && $post instanceof WP_Post) { $post_id = (int)$post->ID; }
        if ($post_id) {
            $page_route = ClaimTrack_DB::get_route_for_page($post_id);
            if (!empty($page_route['view'])) { $route['view'] = sanitize_key($page_route['view']); }
            if (!empty($page_route['program_code'])) { $route['program_code'] = ClaimTrack_DB::normalize_code($page_route['program_code']); }
        }

        // Backward compatibility: URL lama ?view=... tetap didukung.
        if (isset($_GET['view']) && (string)$_GET['view'] !== '') {
            $route['view'] = sanitize_key(wp_unslash($_GET['view']));
        }
        if (isset($_GET['year'])) { $route['year'] = max(2000, min(2100, (int)$_GET['year'])); }
        if (isset($_GET['month'])) { $route['month'] = max(1, min(12, (int)$_GET['month'])); }
        if (isset($_GET['program_id'])) { $route['program_id'] = max(0, (int)$_GET['program_id']); }

        if ($route['view'] === 'phase') {
            if ($route['program_id'] <= 0 && $route['program_code'] !== '') {
                $route['program_id'] = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['programs']} WHERE code=%s AND active=1 LIMIT 1", $route['program_code']));
            }
            if ($route['program_id'] <= 0) {
                $route['program_id'] = (int)$wpdb->get_var("SELECT id FROM {$t['programs']} WHERE code='KDP' AND active=1 LIMIT 1");
            }
            if ($route['program_id'] > 0 && $route['program_code'] === '') {
                $route['program_code'] = (string)$wpdb->get_var($wpdb->prepare("SELECT code FROM {$t['programs']} WHERE id=%d LIMIT 1", $route['program_id']));
            }
        }

        $route['valid_view'] = in_array($route['view'], $allowed, true);
        self::$resolved_route = $route;
        return $route;
    }

    private static function apply_resolved_route_to_request($route) {
        if (!is_array($route)) { return; }
        $_GET['view'] = (string)($route['view'] ?? 'dashboard');
        if (($route['view'] ?? '') === 'phase' && !empty($route['program_id'])) { $_GET['program_id'] = (int)$route['program_id']; }
        if (!isset($_GET['year']) && isset($route['year'])) { $_GET['year'] = (int)$route['year']; }
        if (!isset($_GET['month']) && isset($route['month'])) { $_GET['month'] = (int)$route['month']; }
    }

    private static function login_redirect_url() {
        $route = self::resolve_route(true);
        $args = array('view' => $route['view']);
        if ($route['view'] === 'phase' && !empty($route['program_id'])) { $args['program_id'] = (int)$route['program_id']; }
        if (isset($_GET['year'])) { $args['year'] = (int)$route['year']; }
        if (isset($_GET['month'])) { $args['month'] = (int)$route['month']; }
        if (isset($_GET['unit_id'])) { $args['unit_id'] = (int)$_GET['unit_id']; }
        return self::app_url($args);
    }

    private static function turnstile_settings() {
        $settings = self::get_settings();
        return array(
            'enabled'=>!empty($settings['turnstile_enabled']),
            'site_key'=>(string)$settings['turnstile_site_key'],
            'secret_key'=>(string)$settings['turnstile_secret_key'],
        );
    }

    private static function verify_turnstile($token) {
        $cfg=self::turnstile_settings();
        if (!$cfg['enabled']) { return true; }
        if ($cfg['site_key']==='' || $cfg['secret_key']==='') { return new WP_Error('ct_turnstile_config','Cloudflare Turnstile aktif tetapi Site Key atau Secret Key belum diisi.'); }
        if ($token==='') { return new WP_Error('ct_turnstile_required','Selesaikan verifikasi keamanan Cloudflare Turnstile.'); }
        $body=array('secret'=>$cfg['secret_key'],'response'=>$token);
        if (!empty($_SERVER['REMOTE_ADDR'])) { $body['remoteip']=sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])); }
        $res=wp_remote_post('https://challenges.cloudflare.com/turnstile/v0/siteverify',array('timeout'=>10,'body'=>$body));
        if (is_wp_error($res)) { return new WP_Error('ct_turnstile_unavailable','Verifikasi Turnstile tidak dapat dihubungi. Silakan coba lagi.'); }
        $json=json_decode(wp_remote_retrieve_body($res),true);
        if (!is_array($json) || empty($json['success'])) { return new WP_Error('ct_turnstile_failed','Verifikasi Cloudflare Turnstile gagal. Silakan ulangi.'); }
        return true;
    }

    public static function validate_route() {
        if (!self::is_app_page()) { return; }

        // Dashboard berisi data dinamis dan user-specific. Hindari cache halaman publik.
        if (!defined('DONOTCACHEPAGE')) { define('DONOTCACHEPAGE', true); }
        if (!defined('DONOTCACHEDB')) { define('DONOTCACHEDB', true); }
        nocache_headers();

        $route = self::resolve_route(true);
        if (!is_user_logged_in()) { return; }

        // Seluruh area pengelolaan dipusatkan di /sw-admin. Laman lama tetap
        // ada untuk kompatibilitas WordPress, tetapi tidak lagi menjadi UI edit.
        if (in_array(($route['view'] ?? ''), array('units','programs','providers','import','settings'), true)) {
            wp_safe_redirect(self::admin_portal_url((string)$route['view'])); exit;
        }
        if (($route['view'] ?? '') === 'matrix') {
            global $wpdb; $t=ClaimTrack_DB::tables();
            $pid=(int)($_GET['program_id'] ?? 0);
            $sub_id=(int)$wpdb->get_var("SELECT id FROM {$t['programs']} WHERE code='SUBROGASI' AND active=1 LIMIT 1");
            if ($pid<=0 || $pid!==$sub_id) { wp_safe_redirect(self::admin_portal_url('matrix')); exit; }
        }
        if (empty($route['valid_view'])) {
            self::$route_not_found = true;
            status_header(404);
            return;
        }
        if ($route['view'] === 'phase') {
            global $wpdb; $t=ClaimTrack_DB::tables();
            $program_id = (int)($route['program_id'] ?? 0);
            $exists = $program_id > 0 ? (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['programs']} WHERE id=%d AND active=1", $program_id)) : 0;
            if (!$exists) {
                self::$route_not_found = true;
                status_header(404);
            }
        }
    }

    public static function handle_frontend_login() {
        if ($_SERVER['REQUEST_METHOD']!=='POST' || !self::is_app_page()) { return; }
        $is_admin_login = !empty($_POST['claimtrack_admin_login']);
        $is_user_login = !empty($_POST['claimtrack_login']);
        if (!$is_admin_login && !$is_user_login) { return; }

        $nonce_name = $is_admin_login ? 'claimtrack_admin_login_nonce' : 'claimtrack_login_nonce';
        $nonce_action = $is_admin_login ? 'claimtrack_admin_login' : 'claimtrack_login';
        if (!isset($_POST[$nonce_name]) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST[$nonce_name])),$nonce_action)) {
            self::$login_error='Sesi login tidak valid. Muat ulang halaman lalu coba kembali.'; return;
        }
        $turnstile=self::verify_turnstile(sanitize_text_field(wp_unslash($_POST['cf-turnstile-response']??'')));
        if (is_wp_error($turnstile)) { self::$login_error=$turnstile->get_error_message(); return; }
        $creds=array(
            'user_login'=>sanitize_user(wp_unslash($_POST['log']??'')),
            'user_password'=>(string)wp_unslash($_POST['pwd']??''),
            'remember'=>!empty($_POST['rememberme']),
        );
        if ($creds['user_login']==='' || $creds['user_password']==='') { self::$login_error='Username dan password wajib diisi.'; return; }
        $user=wp_signon($creds,is_ssl());
        if (is_wp_error($user)) { self::$login_error='Username atau password tidak sesuai.'; return; }

        if ($is_admin_login) {
            if (!self::is_primary_admin_user($user) && !self::is_claimtrack_admin_user($user)) {
                wp_logout();
                self::$login_error='Akun ini tidak memiliki akses Administrator ClaimTrack.';
                return;
            }
            wp_safe_redirect(self::admin_portal_url('overview')); exit;
        }

        if (!$user->has_cap('claimtrack_view') && !$user->has_cap('manage_options')) {
            wp_logout();
            self::$login_error='Akun ini belum memiliki izin untuk membuka ClaimTrack.';
            return;
        }
        // Login user selalu berakhir di Dashboard User, tidak mengikuti halaman login sebelumnya.
        wp_safe_redirect(self::app_url(array('view'=>'dashboard'))); exit;
    }

    public static function handle_actions() {
        if (!is_user_logged_in()) { return; }

        if (isset($_GET['ct_download_template'])) {
            if (!self::can_import_export()) { wp_die('Akses ditolak.'); }
            check_admin_referer('claimtrack_template');
            ClaimTrack_Export::stream_template_csv();
        }

        if (isset($_GET['ct_download_template_xlsx'])) {
            if (!self::can_import_export()) { wp_die('Akses ditolak.'); }
            check_admin_referer('claimtrack_template_xlsx');
            ClaimTrack_Export::stream_template_xlsx();
        }

        if (isset($_GET['ct_backup'])) {
            if (!self::can_import_export()) { wp_die('Akses ditolak.'); }
            check_admin_referer('claimtrack_backup');
            ClaimTrack_Backup::stream_backup();
        }

        // Export laporan tersedia untuk seluruh user ClaimTrack pada setiap menu frontend.
        if (isset($_GET['ct_user_export'])) {
            if (!self::is_app_page() || !self::can_view()) { wp_die('Akses ditolak.'); }
            check_admin_referer('claimtrack_user_export');
            $format = sanitize_key((string)wp_unslash($_GET['ct_user_export']));
            if (!in_array($format, array('xlsx','pdf'), true)) { wp_die('Format export tidak didukung.'); }
            self::stream_user_menu_export($format);
        }

        if (isset($_GET['ct_export'])) {
            if (!self::can_import_export()) { wp_die('Akses ditolak.'); }
            check_admin_referer('claimtrack_export');
            $filters = array(
                'year' => isset($_GET['year']) ? (int)$_GET['year'] : 0,
                'month' => isset($_GET['month']) ? (int)$_GET['month'] : 0,
                'program_id' => isset($_GET['program_id']) ? (int)$_GET['program_id'] : 0,
                'unit_id' => isset($_GET['unit_id']) ? (int)$_GET['unit_id'] : 0,
            );
            if ($_GET['ct_export'] === 'xlsx') { ClaimTrack_Export::stream_xlsx($filters); }
            if ($_GET['ct_export'] === 'pdf') { ClaimTrack_Export::stream_pdf($filters); }
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['claimtrack_action'])) { return; }
        $action = sanitize_key(wp_unslash($_POST['claimtrack_action']));

        // Komentar berita dapat dikirim oleh seluruh user ClaimTrack yang sudah login.
        // Aksi pengelolaan lainnya hanya dapat dilakukan Administrator ClaimTrack.
        if ($action === 'news_comment_add') {
            if (!self::can_view()) { wp_die('Akses ditolak.'); }
            check_admin_referer('claimtrack_news_comment', 'claimtrack_comment_nonce');
            $news_id = max(0, (int)($_POST['news_id'] ?? 0));
            $result = self::save_news_comment();
            $redirect = self::app_url(array('view'=>'home','news_id'=>$news_id));
            $message = is_wp_error($result) ? $result->get_error_message() : 'Komentar berhasil dikirim.';
            $redirect = add_query_arg('ct_type', is_wp_error($result) ? 'error' : 'success', $redirect);
            $redirect = add_query_arg('ct_msg', rawurlencode($message), $redirect) . '#ct-news-comments';
            wp_safe_redirect($redirect);
            exit;
        }

        if (!self::can_manage()) { wp_die('Akses ditolak.'); }
        check_admin_referer('claimtrack_action', 'claimtrack_nonce');
        $redirect = self::app_url(array('view' => isset($_POST['return_view']) ? sanitize_key($_POST['return_view']) : 'dashboard'));
        $result = true;
        $message = 'Data berhasil disimpan.';
        $event = '';

        // Tandai jenis aksi agar UI dapat menampilkan popup yang jelas setelah
        // tambah, edit, atau hapus tanpa bergantung pada alert browser bawaan.
        if (in_array($action, array('unit_save','program_save','provider_save','debitur_save'), true)) {
            $event = ((int)($_POST['id'] ?? 0) > 0) ? 'updated' : 'added';
        } elseif ($action === 'knowledge_save') {
            $event = ((int)($_POST['knowledge_id'] ?? 0) > 0) ? 'updated' : 'added';
        } elseif ($action === 'news_save') {
            $event = ((int)($_POST['news_id'] ?? 0) > 0) ? 'updated' : 'added';
        } elseif ($action === 'user_add') {
            $event = 'added';
        } elseif ($action === 'user_password') {
            $event = 'updated';
        } elseif (in_array($action, array('unit_delete','program_delete','provider_delete','debitur_delete','knowledge_delete','news_delete'), true)) {
            $event = 'deleted';
        }

        switch ($action) {
            case 'monitoring_save':
            case 'monitoring_delete':
                $module = sanitize_key(wp_unslash($_POST['module'] ?? ''));
                $result = ClaimTrack_Monitoring::mutate($module, $action);
                $redirect = self::admin_portal_url($module);
                $message = $action === 'monitoring_delete' ? 'Data berhasil dihapus.' : 'Data berhasil disimpan.';
                break;
            case 'unit_save': $result = self::save_unit(); $redirect = self::admin_portal_url('units'); break;
            case 'unit_delete': $result = self::delete_master('units'); $redirect = self::admin_portal_url('units'); break;
            case 'program_save': $result = self::save_program(); $redirect = self::admin_portal_url('programs'); break;
            case 'program_delete': $result = self::delete_master('programs'); $redirect = self::admin_portal_url('programs'); break;
            case 'provider_save': $result = self::save_provider(); $redirect = self::admin_portal_url('providers'); break;
            case 'provider_delete': $result = self::delete_master('providers'); $redirect = self::admin_portal_url('providers'); break;
            case 'debitur_save': $result = self::save_debitur(); $redirect = self::admin_portal_url('debitur'); break;
            case 'debitur_delete': $result = self::delete_debitur(); $redirect = self::admin_portal_url('debitur'); break;
            case 'matrix_save':
                $result = self::save_matrix();
                $matrixSection=sanitize_key((string)($_POST['admin_section'] ?? 'matrix'));
                if(!in_array($matrixSection,array('phase1','phase2','phase3','subrogation','matrix'),true)){$matrixSection='phase1';}
                $redirect = self::admin_portal_url($matrixSection,array(
                    'program_id'=>(int)($_POST['program_id'] ?? 0),
                    'year'=>(int)($_POST['year'] ?? wp_date('Y')),
                    'month'=>(int)($_POST['month'] ?? wp_date('n')),
                ));
                $message = 'Input Minggu I-IV berhasil disinkronkan.';
                break;
            case 'settings_save': $result = self::save_settings(); $redirect = self::admin_portal_url('settings'); break;
            case 'knowledge_save':
                $result = self::save_knowledge();
                $redirect = self::admin_portal_url('knowledge');
                $message = 'Materi E-Knowledge berhasil disimpan.';
                break;
            case 'knowledge_delete':
                $result = self::delete_knowledge();
                $redirect = self::admin_portal_url('knowledge');
                $message = 'Materi E-Knowledge berhasil dihapus.';
                break;
            case 'news_save':
                $result = self::save_news();
                $redirect = self::admin_portal_url('news_list');
                $message = 'Berita berhasil disimpan.';
                break;
            case 'news_delete':
                $result = self::delete_news();
                $redirect = self::admin_portal_url('news_list');
                $message = 'Berita berhasil dihapus.';
                break;
            case 'user_add':
                $result = self::add_viewer_user();
                $redirect = self::admin_portal_url('users');
                $message = 'User Viewer berhasil ditambahkan.';
                break;
            case 'user_password':
                $target_id = max(0, (int)($_POST['user_id'] ?? 0));
                $is_self_password = ($target_id > 0 && $target_id === get_current_user_id());
                $result = self::change_user_password();
                $redirect = self::admin_portal_url('users');
                $message = $is_self_password ? 'Password akun Anda berhasil diubah. Silakan login kembali.' : 'Password user berhasil diperbarui.';
                break;
            case 'import':
                if (!self::can_import_export()) { wp_die('Akses ditolak.'); }
                $result = self::do_import(); $redirect = self::admin_portal_url('import');
                if (!is_wp_error($result)) {
                    $message = sprintf('Sinkronisasi selesai. %d baris disimpan, %d dilewati.', $result['imported'], $result['skipped']);
                    if (!empty($result['errors'])) { $message .= ' ' . implode(' ', $result['errors']); }
                }
                break;
            case 'restore_backup':
                if (!self::can_import_export()) { wp_die('Akses ditolak.'); }
                $result = ClaimTrack_Backup::restore_uploaded_file($_FILES['backup_file'] ?? array());
                $redirect = self::admin_portal_url('import');
                if (!is_wp_error($result)) {
                    $message = sprintf('Restore selesai. %d Unit Kerja, %d Program, %d Mitra, %d data klaim, %d materi E-Knowledge, dan %d berita dipulihkan.', (int)$result['units'], (int)$result['programs'], (int)$result['providers'], (int)$result['entries'], (int)($result['knowledge'] ?? 0), (int)($result['news'] ?? 0));
                }
                break;
            default: return;
        }

        if (!is_wp_error($result) && in_array($action, array('unit_save','unit_delete','program_save','program_delete','provider_save','provider_delete','matrix_save','import'), true)) {
            ClaimTrack_DB::mark_cpt_sync_dirty();
            ClaimTrack_DB::sync_cpt_mirror(true);
        }
        if (is_wp_error($result)) { $message = $result->get_error_message(); $redirect = add_query_arg('ct_type', 'error', $redirect); }
        else { $redirect = add_query_arg('ct_type', 'success', $redirect); }
        $redirect = add_query_arg('ct_msg', rawurlencode($message), $redirect);
        if ($event !== '') { $redirect = add_query_arg('ct_event', $event, $redirect); }
        wp_safe_redirect($redirect);
        exit;
    }

    private static function stream_user_menu_export($format) {
        $route = self::resolve_route(true);
        self::apply_resolved_route_to_request($route);
        $report = self::build_user_menu_report($route);
        $slug = sanitize_title((string)($report['slug'] ?? 'laporan')) ?: 'laporan';
        $stamp = wp_date('Ymd-His');
        if ($format === 'xlsx') {
            $data = array((array)$report['headers']);
            foreach ((array)$report['rows'] as $row) { $data[] = array_values((array)$row); }
            ClaimTrack_Export::stream_report_xlsx($data, 'claimtrack-'.$slug.'-'.$stamp.'.xlsx', (string)($report['sheet'] ?? 'Laporan'));
        }
        ClaimTrack_Export::stream_report_pdf(
            (string)$report['title'],
            (string)$report['subtitle'],
            (array)$report['headers'],
            (array)$report['rows'],
            'claimtrack-'.$slug.'-'.$stamp.'.pdf'
        );
    }

    private static function build_user_menu_report($route) {
        global $wpdb;
        $t = ClaimTrack_DB::tables();
        $months = self::month_names();
        $view = sanitize_key((string)($route['view'] ?? 'dashboard'));
        $year = max(2000, min(2100, (int)($route['year'] ?? wp_date('Y'))));
        $month = max(1, min(12, (int)($route['month'] ?? wp_date('n'))));
        $period = ($months[$month] ?? (string)$month).' '.$year;
        $roman = array(1=>'I',2=>'II',3=>'III',4=>'IV');
        $report = array(
            'title'=>'CLAIMTRACK - LAPORAN',
            'subtitle'=>'Diekspor '.wp_date('d F Y H:i'),
            'headers'=>array('Data'),
            'rows'=>array(),
            'slug'=>$view,
            'sheet'=>'Laporan ClaimTrack',
        );

        if (isset(self::additional_menu_items()[$view])) { return ClaimTrack_Monitoring::report($view); }

        if ($view === 'home') {
            $items = get_posts(array('post_type'=>'ct_news','post_status'=>'publish','posts_per_page'=>-1,'orderby'=>'date','order'=>'DESC'));
            $rows = array();
            foreach ($items as $i=>$item) {
                $summary = wp_trim_words(wp_strip_all_tags($item->post_excerpt ?: $item->post_content), 35, '...');
                $rows[] = array($i+1, wp_date('d/m/Y', strtotime($item->post_date)), $item->post_title, $summary, (int)get_comments_number($item->ID));
            }
            return array(
                'title'=>'CLAIMTRACK - BERITA & UPDATE',
                'subtitle'=>'Daftar berita internal | Diekspor '.wp_date('d F Y H:i'),
                'headers'=>array('No','Tanggal','Judul','Ringkasan','Komentar'),
                'rows'=>$rows,'slug'=>'berita-update','sheet'=>'Berita & Update'
            );
        }

        if ($view === 'knowledge') {
            $items = get_posts(array('post_type'=>'ct_knowledge','post_status'=>'publish','posts_per_page'=>-1,'orderby'=>array('menu_order'=>'ASC','date'=>'DESC')));
            $rows = array();
            foreach ($items as $i=>$item) {
                $pdf_id=(int)get_post_meta($item->ID,'_claimtrack_knowledge_pdf_id',true);
                $url=$pdf_id?(string)wp_get_attachment_url($pdf_id):(string)get_post_meta($item->ID,'_claimtrack_knowledge_pdf_url',true);
                $rows[] = array($i+1,$item->post_title,wp_trim_words(wp_strip_all_tags($item->post_excerpt ?: $item->post_content),32,'...'),$url ?: '-');
            }
            return array(
                'title'=>'CLAIMTRACK - E-KNOWLEDGE',
                'subtitle'=>'Daftar materi E-Knowledge | Diekspor '.wp_date('d F Y H:i'),
                'headers'=>array('No','Judul Materi','Deskripsi','File PDF'),
                'rows'=>$rows,'slug'=>'e-knowledge','sheet'=>'E-Knowledge'
            );
        }

        if ($view === 'achievement') {
            $phase_codes = array('KDP','DOK_LENGKAP','TERBUKU');
            $placeholders = implode(',', array_fill(0,count($phase_codes),'%s'));
            $sql = "SELECT e.month,p.phase_label,p.name,COALESCE(SUM(e.amount_million),0) total
                    FROM {$t['entries']} e JOIN {$t['programs']} p ON p.id=e.program_id
                    WHERE e.year=%d AND p.code IN ($placeholders)
                    GROUP BY e.month,p.id,p.phase_label,p.name ORDER BY e.month,p.dashboard_order,p.name";
            $args = array_merge(array($year),$phase_codes);
            $data = $wpdb->get_results($wpdb->prepare($sql,$args));
            $rows=array(); $n=1;
            foreach($data as $r){
                $rows[]=array($n++,($months[(int)$r->month]??(string)$r->month),trim(($r->phase_label?$r->phase_label.' - ':'').$r->name),number_format((float)$r->total,2,',','.'));
            }
            return array(
                'title'=>'CLAIMTRACK - PENCAPAIAN '.$year,
                'subtitle'=>'Rekap pencapaian bulanan per fase | Satuan: juta rupiah',
                'headers'=>array('No','Bulan','Fase','Nominal'),
                'rows'=>$rows,'slug'=>'pencapaian-'.$year,'sheet'=>'Pencapaian '.$year
            );
        }

        $program_id = 0;
        $title = 'DASHBOARD MONITORING KLAIM';
        $slug = 'dashboard-'.$year.'-'.$month;
        $allowed_codes = array('KDP','DOK_LENGKAP','TERBUKU');
        if ($view === 'phase') {
            $program_id = max(0,(int)($route['program_id'] ?? 0));
            $program = $program_id ? $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['programs']} WHERE id=%d LIMIT 1",$program_id)) : null;
            if ($program) {
                $title = trim(($program->phase_label?$program->phase_label.' - ':'').$program->name);
                $slug = sanitize_title($title).'-'.$year.'-'.$month;
            }
        } elseif ($view === 'matrix') {
            $program_id = max(0,(int)($_GET['program_id'] ?? 0));
            if ($program_id <= 0) { $program_id=(int)$wpdb->get_var("SELECT id FROM {$t['programs']} WHERE code='SUBROGASI' AND active=1 LIMIT 1"); }
            $program = $program_id ? $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['programs']} WHERE id=%d LIMIT 1",$program_id)) : null;
            $title = $program ? $program->name : 'Potensi Subrogasi';
            $slug = 'potensi-subrogasi-'.$year.'-'.$month;
        }

        $filters=array('year'=>$year,'month'=>$month);
        if ($program_id>0) { $filters['program_id']=$program_id; }
        $raw=ClaimTrack_Export::get_rows($filters);
        $rows=array(); $n=1;
        foreach($raw as $r){
            if($view==='dashboard' && !in_array((string)$r['program_code'],$allowed_codes,true)){continue;}
            $rows[]=array(
                $n++, (string)$r['unit_name'], (string)$r['program_name'], (string)$r['provider_name'],
                $roman[(int)$r['week']] ?? (string)$r['week'],
                number_format((float)$r['amount_million'],2,',','.'),
                (string)$r['note']
            );
        }
        return array(
            'title'=>'CLAIMTRACK - '.strtoupper($title),
            'subtitle'=>'Periode '.$period.' | Satuan nominal: juta rupiah',
            'headers'=>array('No','Unit Kerja','Program','Asuradur','Minggu','Nominal','Catatan'),
            'rows'=>$rows,'slug'=>$slug,'sheet'=>substr($title,0,31)
        );
    }

    private static function render_user_export_toolbar($view, $page_title='') {
        if (!self::can_view() || self::$admin_portal || $view === 'not_found') { return; }
        $route = self::resolve_route();
        $year = max(2000,min(2100,(int)($_GET['year'] ?? ($route['year'] ?? wp_date('Y')))));
        $month = max(1,min(12,(int)($_GET['month'] ?? ($route['month'] ?? wp_date('n')))));
        $args = array('view'=>$view,'year'=>$year,'month'=>$month);
        if ($view === 'phase') { $args['program_id']=(int)($route['program_id'] ?? ($_GET['program_id'] ?? 0)); }
        if ($view === 'matrix') { $args['program_id']=(int)($_GET['program_id'] ?? 0); }
        if (isset(self::additional_menu_items()[$view])) { foreach(array('mq','mperiod') as $key) { if(isset($_GET[$key]) && is_scalar($_GET[$key])) { $args[$key]=sanitize_text_field(wp_unslash($_GET[$key])); } } }
        $base = self::app_url($args);
        $nonce = wp_create_nonce('claimtrack_user_export');
        $excel = add_query_arg(array('ct_user_export'=>'xlsx','_wpnonce'=>$nonce),$base);
        $pdf = add_query_arg(array('ct_user_export'=>'pdf','_wpnonce'=>$nonce),$base);
        ?>
        <?php /* v1.20.2 UI revision: export toolbar disembunyikan sesuai desain dashboard baru. */ ?>
        <?php
    }

    private static function add_viewer_user() {
        if (!self::can_manage()) { return new WP_Error('ct_user_forbidden','Hanya Administrator ClaimTrack yang dapat menambahkan user.'); }
        $username = sanitize_user(wp_unslash($_POST['new_username'] ?? ''), true);
        $display_name = sanitize_text_field(wp_unslash($_POST['new_display_name'] ?? ''));
        $email = sanitize_email(wp_unslash($_POST['new_email'] ?? ''));
        $password = (string)wp_unslash($_POST['new_password'] ?? '');
        $confirm = (string)wp_unslash($_POST['new_password_confirm'] ?? '');

        if ($username === '' || $display_name === '' || $password === '') {
            return new WP_Error('ct_user_required','Username, nama user, dan password wajib diisi.');
        }
        if (strtolower($username) === self::primary_admin_login()) {
            return new WP_Error('ct_user_reserved','Username atadro dicadangkan untuk Administrator Utama.');
        }
        if (username_exists($username)) { return new WP_Error('ct_user_exists','Username sudah digunakan.'); }
        if ($email !== '' && !is_email($email)) { return new WP_Error('ct_user_email','Format email tidak valid.'); }
        if ($email !== '' && email_exists($email)) { return new WP_Error('ct_user_email_exists','Email sudah digunakan oleh user lain.'); }
        if (strlen($password) < 8) { return new WP_Error('ct_user_password','Password minimal 8 karakter.'); }
        if ($password !== $confirm) { return new WP_Error('ct_user_password_match','Konfirmasi password tidak sama.'); }

        $user_id = wp_insert_user(array(
            'user_login' => $username,
            'user_pass' => $password,
            'user_email' => $email,
            'display_name' => $display_name,
            'role' => 'claimtrack_viewer',
        ));
        if (is_wp_error($user_id)) { return $user_id; }
        $user = get_userdata((int)$user_id);
        if ($user instanceof WP_User) {
            $user->set_role('claimtrack_viewer');
            $user->add_cap('claimtrack_view');
            $user->remove_cap('claimtrack_manage');
            $user->remove_cap('claimtrack_import_export');
            $user->remove_cap('manage_options');
        }
        return true;
    }

    private static function change_user_password() {
        if (!self::can_manage()) { return new WP_Error('ct_user_forbidden','Hanya Administrator ClaimTrack yang dapat mengganti password user.'); }
        $user_id = max(0, (int)($_POST['user_id'] ?? 0));
        $password = (string)wp_unslash($_POST['user_password'] ?? '');
        $confirm = (string)wp_unslash($_POST['user_password_confirm'] ?? '');
        $user = $user_id ? get_userdata($user_id) : false;
        if (!($user instanceof WP_User)) { return new WP_Error('ct_user_missing','User tidak ditemukan.'); }
        if (self::is_primary_admin_user($user) && !self::is_primary_admin_user()) { return new WP_Error('ct_user_primary_protected','Akun Super Admin tidak dapat diubah oleh Administrator ClaimTrack.'); }
        if (strlen($password) < 8) { return new WP_Error('ct_user_password','Password minimal 8 karakter.'); }
        if ($password !== $confirm) { return new WP_Error('ct_user_password_match','Konfirmasi password tidak sama.'); }

        // Administrator ClaimTrack dapat mengganti password dirinya sendiri dan user Viewer.
        // Akun Super Admin atadro tetap dilindungi dari perubahan oleh admin aplikasi.
        if (!self::is_primary_admin_user($user) && !in_array('claimtrack_viewer',(array)$user->roles,true) && !in_array('claimtrack_admin',(array)$user->roles,true)) {
            return new WP_Error('ct_user_role','Akun ini bukan user ClaimTrack yang dapat dikelola.');
        }
        wp_set_password($password, $user_id);
        return true;
    }

    private static function save_unit() {
        global $wpdb; $t=ClaimTrack_DB::tables(); $now=current_time('mysql');
        $id=(int)($_POST['id'] ?? 0); $name=sanitize_text_field(wp_unslash($_POST['name'] ?? ''));
        $code=ClaimTrack_DB::normalize_code(wp_unslash($_POST['code'] ?? ''));
        if ($name==='' || $code==='') return new WP_Error('ct_required','Kode dan nama unit kerja wajib diisi.');
        $exists=(int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['units']} WHERE code=%s AND id<>%d",$code,$id));
        if ($exists) return new WP_Error('ct_duplicate','Kode unit kerja sudah digunakan.');
        $data=array('code'=>$code,'name'=>$name,'sort_order'=>(int)($_POST['sort_order']??0),'active'=>isset($_POST['active'])?1:0,'updated_at'=>$now);
        if ($id) { $saved=$wpdb->update($t['units'],$data,array('id'=>$id)); }
        else { $data['created_at']=$now; $saved=$wpdb->insert($t['units'],$data); }
        if ($saved===false) return new WP_Error('ct_db_save','Unit Kerja gagal disimpan ke database ClaimTrack. '.$wpdb->last_error);
        return true;
    }

    private static function save_provider() {
        global $wpdb; $t=ClaimTrack_DB::tables(); $now=current_time('mysql');
        $id=(int)($_POST['id'] ?? 0); $name=sanitize_text_field(wp_unslash($_POST['name'] ?? ''));
        $code=ClaimTrack_DB::normalize_code(wp_unslash($_POST['code'] ?? ''));
        if ($name==='' || $code==='') return new WP_Error('ct_required','Kode dan nama mitra wajib diisi.');
        $exists=(int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['providers']} WHERE code=%s AND id<>%d",$code,$id));
        if ($exists) return new WP_Error('ct_duplicate','Kode mitra sudah digunakan.');
        $data=array('code'=>$code,'name'=>$name,'sort_order'=>(int)($_POST['sort_order']??0),'active'=>isset($_POST['active'])?1:0,'updated_at'=>$now);
        if ($id) { $saved=$wpdb->update($t['providers'],$data,array('id'=>$id)); }
        else { $data['created_at']=$now; $saved=$wpdb->insert($t['providers'],$data); }
        if ($saved===false) return new WP_Error('ct_db_save','Mitra gagal disimpan ke database ClaimTrack. '.$wpdb->last_error);
        return true;
    }

    private static function save_program() {
        global $wpdb; $t=ClaimTrack_DB::tables(); $now=current_time('mysql');
        $id=(int)($_POST['id'] ?? 0); $name=sanitize_text_field(wp_unslash($_POST['name'] ?? ''));
        $code=ClaimTrack_DB::normalize_code(wp_unslash($_POST['code'] ?? ''));
        if ($name==='' || $code==='') return new WP_Error('ct_required','Kode dan nama program wajib diisi.');
        $exists=(int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['programs']} WHERE code=%s AND id<>%d",$code,$id));
        if ($exists) return new WP_Error('ct_duplicate','Kode program sudah digunakan.');
        $color=sanitize_hex_color(wp_unslash($_POST['color'] ?? '#23b653')) ?: '#23b653';
        $data=array('code'=>$code,'phase_label'=>sanitize_text_field(wp_unslash($_POST['phase_label']??'')),'name'=>$name,'color'=>$color,'dashboard_order'=>(int)($_POST['dashboard_order']??0),'show_dashboard'=>isset($_POST['show_dashboard'])?1:0,'active'=>isset($_POST['active'])?1:0,'updated_at'=>$now);
        if ($id) { $saved=$wpdb->update($t['programs'],$data,array('id'=>$id)); }
        else { $data['created_at']=$now; $saved=$wpdb->insert($t['programs'],$data); }
        if ($saved===false) return new WP_Error('ct_db_save','Program gagal disimpan ke database ClaimTrack. '.$wpdb->last_error);
        return true;
    }

    private static function delete_master($type) {
        global $wpdb; $t=ClaimTrack_DB::tables(); $id=(int)($_POST['id'] ?? 0);
        if (!$id || !isset($t[$type])) return new WP_Error('ct_invalid','Data tidak valid.');
        $col = $type==='units' ? 'unit_id' : ($type==='programs' ? 'program_id' : 'provider_id');
        $used=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['entries']} WHERE {$col}=%d",$id));
        if ($used>0) return new WP_Error('ct_used','Data sudah dipakai pada transaksi. Nonaktifkan data agar histori tetap aman.');
        $deleted=$wpdb->delete($t[$type],array('id'=>$id),array('%d'));
        if ($deleted===false) return new WP_Error('ct_db_delete','Data gagal dihapus dari database ClaimTrack. '.$wpdb->last_error);
        return true;
    }

    private static function parse_amount_million($raw) {
        $raw = trim((string)$raw);
        if ($raw === '') { return null; }
        $raw = preg_replace('/[^0-9,\.\-]/', '', $raw);
        if ($raw === '' || $raw === '-' || $raw === ',' || $raw === '.') { return 0.0; }

        // Mendukung format Indonesia 1.234,56 dan format internasional 1,234.56.
        $last_comma = strrpos($raw, ',');
        $last_dot = strrpos($raw, '.');
        if ($last_comma !== false && $last_dot !== false) {
            if ($last_comma > $last_dot) {
                $raw = str_replace('.', '', $raw);
                $raw = str_replace(',', '.', $raw);
            } else {
                $raw = str_replace(',', '', $raw);
            }
        } elseif ($last_comma !== false) {
            $parts = explode(',', $raw);
            if (count($parts) === 2 && strlen($parts[1]) <= 2) { $raw = str_replace(',', '.', $raw); }
            else { $raw = str_replace(',', '', $raw); }
        } elseif ($last_dot !== false) {
            $parts = explode('.', $raw);
            if (count($parts) > 2 || (count($parts) === 2 && strlen($parts[1]) === 3 && strlen($parts[0]) > 0)) {
                $raw = str_replace('.', '', $raw);
            }
        }
        return (float)$raw;
    }

    private static function save_matrix() {
        global $wpdb; $t=ClaimTrack_DB::tables(); $now=current_time('mysql');
        $program=(int)($_POST['program_id']??0); $year=(int)($_POST['year']??0); $month=(int)($_POST['month']??0);
        if (!$program || $year<2000 || $year>2100 || $month<1 || $month>12) return new WP_Error('ct_period','Program atau periode tidak valid.');

        $program_exists=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['programs']} WHERE id=%d AND active=1",$program));
        if(!$program_exists) return new WP_Error('ct_program','Program tidak ditemukan atau nonaktif.');

        $matrix = isset($_POST['matrix']) && is_array($_POST['matrix']) ? $_POST['matrix'] : array();
        $wpdb->query('START TRANSACTION');
        try {
            foreach ($matrix as $unitId=>$providers) {
                $unitId=(int)$unitId; if (!$unitId || !is_array($providers)) continue;
                $unit_exists=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['units']} WHERE id=%d AND active=1",$unitId));
                if(!$unit_exists) continue;

                foreach ($providers as $providerId=>$weeks) {
                    $providerId=(int)$providerId; if (!$providerId || !is_array($weeks)) continue;
                    $provider_exists=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['providers']} WHERE id=%d AND active=1",$providerId));
                    if(!$provider_exists) continue;

                    for ($week=1;$week<=4;$week++) {
                        $raw = isset($weeks[$week]) ? trim((string)wp_unslash($weeks[$week])) : '';
                        if ($raw==='') {
                            $deleted=$wpdb->delete($t['entries'],array('unit_id'=>$unitId,'program_id'=>$program,'provider_id'=>$providerId,'year'=>$year,'month'=>$month,'week'=>$week),array('%d','%d','%d','%d','%d','%d'));
                            if($deleted===false) throw new Exception($wpdb->last_error ?: 'Gagal menghapus nilai kosong.');
                            continue;
                        }
                        $amount=self::parse_amount_million($raw);
                        if($amount===null) $amount=0.0;
                        $sql=$wpdb->prepare("INSERT INTO {$t['entries']} (unit_id,program_id,provider_id,year,month,week,amount_million,note,created_at,updated_at)
                            VALUES (%d,%d,%d,%d,%d,%d,%f,'',%s,%s)
                            ON DUPLICATE KEY UPDATE amount_million=VALUES(amount_million),updated_at=VALUES(updated_at)",
                            $unitId,$program,$providerId,$year,$month,$week,$amount,$now,$now);
                        $saved=$wpdb->query($sql);
                        if($saved===false) throw new Exception($wpdb->last_error ?: 'Gagal menyimpan input mingguan.');
                    }
                }
            }
            $wpdb->query('COMMIT');
        } catch (Throwable $e) {
            $wpdb->query('ROLLBACK');
            return new WP_Error('ct_db_matrix','Input mingguan gagal disimpan ke database ClaimTrack. '.$e->getMessage());
        }
        return true;
    }

    private static function save_settings() {
        $current=self::get_settings();
        $secret=trim((string)wp_unslash($_POST['turnstile_secret_key']??''));
        if ($secret==='') { $secret=(string)$current['turnstile_secret_key']; }
        $adminWhatsapp=preg_replace('/[^0-9]/','',sanitize_text_field(wp_unslash($_POST['admin_whatsapp']??'')));
        if ($adminWhatsapp!=='' && substr($adminWhatsapp,0,1)==='0') { $adminWhatsapp='62'.substr($adminWhatsapp,1); }
        $settings=array(
            'dashboard_title'=>sanitize_text_field(wp_unslash($_POST['dashboard_title']??'')),
            'department'=>sanitize_text_field(wp_unslash($_POST['department']??'')),
            'region_label'=>sanitize_text_field(wp_unslash($_POST['region_label']??'')),
            'input_unit'=>'Juta Rupiah',
            'turnstile_enabled'=>isset($_POST['turnstile_enabled'])?1:0,
            'turnstile_site_key'=>sanitize_text_field(wp_unslash($_POST['turnstile_site_key']??'')),
            'turnstile_secret_key'=>sanitize_text_field($secret),
            'admin_whatsapp'=>$adminWhatsapp,
            'logo_id'=>absint($current['logo_id']??0),
            'logo_url'=>esc_url_raw((string)($current['logo_url']??'')),
        );
        if(!empty($_FILES['claimtrack_logo']['name'])){
            if(!function_exists('media_handle_upload')){ require_once ABSPATH.'wp-admin/includes/media.php'; require_once ABSPATH.'wp-admin/includes/file.php'; require_once ABSPATH.'wp-admin/includes/image.php'; }
            $logo_id=media_handle_upload('claimtrack_logo',0,array(),array('test_form'=>false));
            if(is_wp_error($logo_id)){ return new WP_Error('ct_logo_upload','Logo gagal diupload. '.$logo_id->get_error_message()); }
            $mime=(string)get_post_mime_type($logo_id);
            if(strpos($mime,'image/')!==0){ wp_delete_attachment((int)$logo_id,true); return new WP_Error('ct_logo_type','Logo wajib berupa file gambar JPG, PNG, atau WebP.'); }
            $settings['logo_id']=(int)$logo_id;
            $settings['logo_url']='';
        } elseif(isset($_POST['logo_url'])) {
            $settings['logo_url']=esc_url_raw(wp_unslash($_POST['logo_url']));
            if($settings['logo_url']!==''){ $settings['logo_id']=0; }
        }
        $color_keys=array('color_sidebar','color_sidebar_deep','color_header','color_nav_active','color_sidebar_line','color_workspace','color_panel','color_kpi','color_kpi_dark','color_kpi_border','color_button','color_table','color_table_sub','color_phase_table','color_phase_table_sub','color_danger','color_text','color_muted','color_login_blue','color_login_footer','color_login_button');
        $defaults=self::settings_defaults();
        foreach($color_keys as $key){
            $raw=sanitize_hex_color((string)wp_unslash($_POST[$key]??''));
            $settings[$key]=$raw ?: (string)$defaults[$key];
        }
        update_option('claimtrack_settings',$settings,false); return true;
    }

    private static function save_news() {
        if (!self::can_manage()) { return new WP_Error('ct_forbidden','Anda tidak memiliki izin mengelola berita.'); }
        $id=(int)($_POST['news_id'] ?? 0);
        $title=sanitize_text_field(wp_unslash($_POST['news_title'] ?? ''));
        $excerpt=sanitize_textarea_field(wp_unslash($_POST['news_excerpt'] ?? ''));
        $content=wp_kses_post(wp_unslash($_POST['news_content'] ?? ''));
        $sort=(int)($_POST['news_sort'] ?? 0);
        $featured=isset($_POST['news_featured'])?1:0;
        if ($title==='') { return new WP_Error('ct_news_title','Judul berita wajib diisi.'); }
        if ($id>0) {
            $existing=get_post($id);
            if (!($existing instanceof WP_Post) || $existing->post_type!=='ct_news') { return new WP_Error('ct_news_missing','Berita tidak ditemukan.'); }
        }
        $postarr=array('post_type'=>'ct_news','post_status'=>'publish','post_title'=>$title,'post_excerpt'=>$excerpt,'post_content'=>$content,'menu_order'=>$sort,'comment_status'=>'open');
        if ($id>0) { $postarr['ID']=$id; }
        $post_id=wp_insert_post($postarr,true);
        if (is_wp_error($post_id)) { return $post_id; }
        $post_id=(int)$post_id;
        update_post_meta($post_id,'_claimtrack_news_featured',$featured);
        if (!empty($_FILES['news_cover']['name'])) {
            if (!function_exists('media_handle_upload')) { require_once ABSPATH.'wp-admin/includes/media.php'; require_once ABSPATH.'wp-admin/includes/file.php'; require_once ABSPATH.'wp-admin/includes/image.php'; }
            $cover_id=media_handle_upload('news_cover',$post_id,array(),array('test_form'=>false));
            if (is_wp_error($cover_id)) { return new WP_Error('ct_news_cover','Cover berita gagal diupload. '.$cover_id->get_error_message()); }
            if (strpos((string)get_post_mime_type($cover_id),'image/')!==0) { wp_delete_attachment((int)$cover_id,true); return new WP_Error('ct_news_cover_type','Cover berita wajib berupa gambar.'); }
            set_post_thumbnail($post_id,(int)$cover_id);
        }
        return true;
    }

    private static function delete_news() {
        if (!self::can_manage()) { return new WP_Error('ct_forbidden','Anda tidak memiliki izin menghapus berita.'); }
        $id=(int)($_POST['news_id'] ?? 0);
        $post=get_post($id);
        if (!($post instanceof WP_Post) || $post->post_type!=='ct_news') { return new WP_Error('ct_news_missing','Berita tidak ditemukan.'); }
        return wp_delete_post($id,true) ? true : new WP_Error('ct_news_delete','Berita gagal dihapus.');
    }

    private static function save_news_comment() {
        if (!self::can_view()) { return new WP_Error('ct_forbidden','Anda tidak memiliki izin mengirim komentar.'); }
        $news_id=max(0,(int)($_POST['news_id'] ?? 0));
        $content=trim(sanitize_textarea_field(wp_unslash($_POST['comment_content'] ?? '')));
        if ($news_id<=0) { return new WP_Error('ct_comment_news','Berita tidak ditemukan.'); }
        $post=get_post($news_id);
        if (!($post instanceof WP_Post) || $post->post_type!=='ct_news' || $post->post_status!=='publish') {
            return new WP_Error('ct_comment_news','Berita tidak ditemukan atau sudah tidak diterbitkan.');
        }
        if ($content==='') { return new WP_Error('ct_comment_empty','Komentar tidak boleh kosong.'); }
        if (function_exists('mb_strlen') ? mb_strlen($content)>2000 : strlen($content)>2000) {
            return new WP_Error('ct_comment_length','Komentar maksimal 2.000 karakter.');
        }
        $user=wp_get_current_user();
        $comment_id=wp_insert_comment(array(
            'comment_post_ID'=>$news_id,
            'comment_author'=>$user->display_name ?: $user->user_login,
            'comment_author_email'=>$user->user_email,
            'comment_author_url'=>'',
            'comment_content'=>$content,
            'comment_type'=>'comment',
            'comment_parent'=>0,
            'user_id'=>(int)$user->ID,
            'comment_approved'=>1,
            'comment_date'=>current_time('mysql'),
            'comment_date_gmt'=>current_time('mysql',true),
        ));
        if (!$comment_id) { return new WP_Error('ct_comment_save','Komentar gagal disimpan ke database ClaimTrack.'); }
        return (int)$comment_id;
    }

    private static function save_knowledge() {
        if (!self::can_manage()) { return new WP_Error('ct_forbidden','Anda tidak memiliki izin mengelola E-Knowledge.'); }
        $id=(int)($_POST['knowledge_id'] ?? 0);
        $title=sanitize_text_field(wp_unslash($_POST['knowledge_title'] ?? ''));
        $description=wp_kses_post(wp_unslash($_POST['knowledge_description'] ?? ''));
        $sort=(int)($_POST['knowledge_sort'] ?? 0);
        if ($title==='') { return new WP_Error('ct_knowledge_title','Judul materi wajib diisi.'); }
        if ($id>0) {
            $existing=get_post($id);
            if (!($existing instanceof WP_Post) || $existing->post_type!=='ct_knowledge') { return new WP_Error('ct_knowledge_missing','Materi E-Knowledge tidak ditemukan.'); }
        }
        $postarr=array(
            'post_type'=>'ct_knowledge',
            'post_status'=>'publish',
            'post_title'=>$title,
            'post_content'=>$description,
            'menu_order'=>$sort,
        );
        if ($id>0) { $postarr['ID']=$id; }
        $post_id=wp_insert_post($postarr,true);
        if (is_wp_error($post_id)) { return $post_id; }
        $post_id=(int)$post_id;
        update_post_meta($post_id,'_claimtrack_knowledge_sort',$sort);

        if (!empty($_FILES['knowledge_cover']['name'])) {
            if (!function_exists('media_handle_upload')) { require_once ABSPATH.'wp-admin/includes/media.php'; require_once ABSPATH.'wp-admin/includes/file.php'; require_once ABSPATH.'wp-admin/includes/image.php'; }
            $cover_id=media_handle_upload('knowledge_cover',$post_id,array(),array('test_form'=>false));
            if (is_wp_error($cover_id)) { return new WP_Error('ct_cover_upload','Cover gagal diupload. '.$cover_id->get_error_message()); }
            $cover_mime=(string)get_post_mime_type($cover_id);
            if (strpos($cover_mime,'image/')!==0) { wp_delete_attachment((int)$cover_id,true); return new WP_Error('ct_cover_type','Cover wajib berupa gambar JPG, PNG, atau WebP.'); }
            update_post_meta($post_id,'_claimtrack_knowledge_cover_id',(int)$cover_id);
            update_post_meta($post_id,'_claimtrack_knowledge_cover_url',(string)wp_get_attachment_url((int)$cover_id));
            set_post_thumbnail($post_id,(int)$cover_id);
        }
        if (!empty($_FILES['knowledge_pdf']['name'])) {
            if (!function_exists('media_handle_upload')) { require_once ABSPATH.'wp-admin/includes/media.php'; require_once ABSPATH.'wp-admin/includes/file.php'; require_once ABSPATH.'wp-admin/includes/image.php'; }
            $pdf_id=media_handle_upload('knowledge_pdf',$post_id,array(),array('test_form'=>false));
            if (is_wp_error($pdf_id)) { return new WP_Error('ct_pdf_upload','PDF gagal diupload. '.$pdf_id->get_error_message()); }
            $mime=(string)get_post_mime_type($pdf_id);
            if ($mime!=='application/pdf') { wp_delete_attachment((int)$pdf_id,true); return new WP_Error('ct_pdf_type','File materi wajib berformat PDF.'); }
            update_post_meta($post_id,'_claimtrack_knowledge_pdf_id',(int)$pdf_id);
            update_post_meta($post_id,'_claimtrack_knowledge_pdf_url',(string)wp_get_attachment_url((int)$pdf_id));
        }
        update_post_meta($post_id,'_claimtrack_knowledge_updated_at',current_time('mysql'));
        return true;
    }

    private static function delete_knowledge() {
        if (!self::can_manage()) { return new WP_Error('ct_forbidden','Anda tidak memiliki izin menghapus E-Knowledge.'); }
        $id=(int)($_POST['knowledge_id'] ?? 0);
        $post=get_post($id);
        if (!($post instanceof WP_Post) || $post->post_type!=='ct_knowledge') { return new WP_Error('ct_knowledge_missing','Materi E-Knowledge tidak ditemukan.'); }
        $deleted=wp_delete_post($id,true);
        return $deleted ? true : new WP_Error('ct_knowledge_delete','Materi E-Knowledge gagal dihapus.');
    }

    private static function do_import() {
        if (empty($_FILES['import_file']['tmp_name'])) return new WP_Error('ct_no_file','Pilih file CSV atau XLSX.');
        $f=$_FILES['import_file'];
        if (!empty($f['error'])) return new WP_Error('ct_upload','Upload file gagal.');
        $name=sanitize_file_name($f['name']);
        $ext=strtolower(pathinfo($name,PATHINFO_EXTENSION));
        if (!in_array($ext,array('csv','xlsx'),true)) return new WP_Error('ct_type','Format file harus CSV atau XLSX.');
        return ClaimTrack_Import::import_file($f['tmp_name'],$name);
    }

    public static function shortcode($atts = array()) {
        // Atribut shortcode tetap didukung untuk kompatibilitas, tetapi WordPress Page
        // + post meta menjadi sumber route utama pada v1.11.0.
        $atts = shortcode_atts(array('view' => '', 'program_code' => ''), is_array($atts) ? $atts : array(), 'claimtrack_app');
        $route = self::resolve_route(true);
        if ($atts['view'] !== '' && !isset($_GET['view'])) {
            $route['view'] = sanitize_key($atts['view']);
            if ($atts['program_code'] !== '') { $route['program_code'] = ClaimTrack_DB::normalize_code($atts['program_code']); }
            self::$resolved_route = null;
            if ($route['view'] === 'phase' && $route['program_code'] !== '') {
                global $wpdb; $t = ClaimTrack_DB::tables();
                $route['program_id'] = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['programs']} WHERE code=%s AND active=1 LIMIT 1", $route['program_code']));
            }
        }
        self::apply_resolved_route_to_request($route);

        if (($route['view'] ?? '') === 'admin') {
            if (!is_user_logged_in() || !self::can_manage()) { return self::render_admin_login(); }
            ob_start(); self::render_admin_shell(); return ob_get_clean();
        }
        if (!is_user_logged_in()) { return self::render_login(); }
        if (!self::can_view()) return '<div class="ct-login-wrap"><div class="ct-login-card ct-login-card--access"><img class="ct-login-logo" src="'.esc_url(self::logo_url(self::get_settings(),'default')).'" alt="ClaimTrack"><h2>Akses dibatasi</h2><p>Akun Anda belum memiliki akses Viewer ClaimTrack.</p></div></div>';

        $view = sanitize_key($route['view'] ?? 'dashboard');
        if (self::$route_not_found || empty($route['valid_view'])) { $view = 'not_found'; }
        ob_start();
        self::render_shell($view);
        return ob_get_clean();
    }

    private static function render_login() {
        $cfg=self::turnstile_settings();
        $settings=self::get_settings();
        if ($cfg['enabled'] && $cfg['site_key']!=='') {
            wp_enqueue_script('claimtrack-turnstile','https://challenges.cloudflare.com/turnstile/v0/api.js',array(),null,true);
        }
        ob_start(); ?>
        <div class="ct-login-wrap ct-login-reference" style="<?php echo esc_attr(self::theme_style_vars($settings)); ?>">
            <div class="ct-login-reference-shell">
                <div class="ct-login-reference-main">
                    <section class="ct-login-reference-left">
                        <img class="ct-login-reference-logo" src="<?php echo esc_url(self::logo_url($settings,'login')); ?>" alt="ClaimTrack Region 18">
                        <div class="ct-login-reference-formbox">
                            <p class="ct-login-reference-welcome">Selamat datang di Aplikasi Claim Track...</p>
                            <?php if(self::$login_error!==''): ?><div class="ct-login-error"><?php echo esc_html(self::$login_error); ?></div><?php endif; ?>
                            <form method="post" class="ct-login-form ct-login-reference-form" autocomplete="on">
                                <?php wp_nonce_field('claimtrack_login','claimtrack_login_nonce'); ?>
                                <input type="hidden" name="claimtrack_login" value="1">
                                <input type="hidden" name="redirect_to" value="<?php echo esc_attr(self::app_url(array('view'=>'dashboard'))); ?>">
                                <input type="hidden" name="rememberme" value="1">
                                <label>User<input type="text" name="log" autocomplete="username" required autofocus></label>
                                <label>Password<span class="ct-password-field"><input type="password" name="pwd" autocomplete="current-password" required><button type="button" class="ct-password-toggle" data-ct-password-toggle aria-label="Tampilkan password" aria-pressed="false"><span class="dashicons dashicons-visibility" aria-hidden="true"></span></button></span></label>
                                <?php if($cfg['enabled']): ?>
                                    <?php if($cfg['site_key']!==''): ?><div class="cf-turnstile ct-turnstile" data-sitekey="<?php echo esc_attr($cfg['site_key']); ?>" data-theme="light"></div><?php else: ?><div class="ct-login-error">Turnstile aktif tetapi Site Key belum dikonfigurasi oleh administrator.</div><?php endif; ?>
                                <?php endif; ?>
                                <div class="ct-login-reference-divider"></div>
                                <button type="submit" class="ct-login-submit ct-login-reference-submit">Lanjutkan</button>
                            </form>
                        </div>
                    </section>
                    <section class="ct-login-reference-right" aria-hidden="true">
                        <img src="<?php echo esc_url(CLAIMTRACK_URL.'assets/claimtrack-login-visual.jpg'); ?>" alt="">
                    </section>
                </div>
                <footer class="ct-login-reference-footer"><span>Copyright <?php echo esc_html(wp_date('Y')); ?> – Commercial18 ID | All Rights Reserved</span></footer>
            </div>
        </div>
        <?php return ob_get_clean();
    }

    private static function render_admin_login() {
        $cfg=self::turnstile_settings();
        $settings=self::get_settings();
        if ($cfg['enabled'] && $cfg['site_key']!=='') { wp_enqueue_script('claimtrack-turnstile','https://challenges.cloudflare.com/turnstile/v0/api.js',array(),null,true); }
        ob_start(); ?>
        <div class="ct-admin-login-wrap" style="<?php echo esc_attr(self::theme_style_vars(self::get_settings())); ?>">
            <div class="ct-admin-login-card">
                <div class="ct-admin-login-brand"><img src="<?php echo esc_url(self::logo_url($settings,'admin')); ?>" alt="ClaimTrack"><span>SW ADMIN</span><h1>Administrator ClaimTrack</h1><p>Portal khusus pengelolaan data, berita, E-Knowledge, konfigurasi, backup, dan input klaim.</p></div>
                <div class="ct-admin-login-form-wrap"><div class="ct-admin-lock"><span class="dashicons dashicons-lock"></span></div><h2>Login Admin</h2><p>Gunakan akun Administrator ClaimTrack.</p>
                <?php if(self::$login_error!==''): ?><div class="ct-login-error"><?php echo esc_html(self::$login_error); ?></div><?php endif; ?>
                <form method="post" class="ct-login-form">
                    <?php wp_nonce_field('claimtrack_admin_login','claimtrack_admin_login_nonce'); ?>
                    <input type="hidden" name="claimtrack_admin_login" value="1">
                    <label>Username Admin<input type="text" name="log" autocomplete="username" required autofocus></label>
                    <label>Password Admin<span class="ct-password-field"><input type="password" name="pwd" autocomplete="current-password" required><button type="button" class="ct-password-toggle" data-ct-password-toggle aria-label="Tampilkan password" aria-pressed="false"><span class="dashicons dashicons-visibility" aria-hidden="true"></span></button></span></label>
                    <label class="ct-login-remember"><input type="checkbox" name="rememberme" value="1"><span>Ingat sesi admin</span></label>
                    <?php if($cfg['enabled'] && $cfg['site_key']!==''): ?><div class="cf-turnstile ct-turnstile" data-sitekey="<?php echo esc_attr($cfg['site_key']); ?>" data-theme="light"></div><?php endif; ?>
                    <button type="submit" class="ct-login-submit">Masuk ke SW Admin</button>
                </form><a class="ct-admin-back" href="<?php echo esc_url(self::app_url()); ?>">← Kembali ke ClaimTrack</a></div>
            </div>
        </div><?php return ob_get_clean();
    }

    private static function render_admin_shell() {
        self::$admin_portal=true;
        $section=sanitize_key((string)($_GET['section'] ?? 'overview'));
        // URL lama Input Mingguan diarahkan ke input FASE 1.
        if($section==='matrix'){$section='phase1';}
        $allowed=array('overview','phase1','phase2','phase3','subrogation','achievement','news','news_list','units','programs','providers','knowledge','import','settings','users','debitur');
        $allowed = array_merge($allowed, array_keys(self::additional_menu_items()));
        if(!in_array($section,$allowed,true)){$section='overview';}
        $user=wp_get_current_user();
        $settings=self::get_settings();
        $labels=array(
            'overview'=>'Dashboard Admin',
            'phase1'=>'Input FASE 1 - KDP',
            'phase2'=>'Input FASE 2 - Dok. Lengkap',
            'phase3'=>'Input FASE 3 - Terbuku',
            'subrogation'=>'Input Potensi Subrogasi',
            'achievement'=>'Pencapaian',
            'news'=>'Tambah Berita',
            'news_list'=>'List Berita',
            'units'=>'Unit Kerja',
            'programs'=>'Program / Fase',
            'providers'=>'Mitra / Asuradur',
            'knowledge'=>'E-Knowledge',
            'import'=>'Backup, Import & Export',
            'settings'=>'Pengaturan',
            'users'=>'User ClaimTrack',
            'debitur'=>'Data Debitur'
        );
        foreach (self::additional_menu_items() as $key=>$item) { $labels[$key]=$item['label']; }
        ?>
        <?php /* Monitoring labels share the public navigation. */ ?>
        <div class="ct-admin-app" data-ct-app style="<?php echo esc_attr(self::theme_style_vars($settings)); ?>">
            <aside class="ct-admin-sidebar" data-ct-sidebar>
                <div class="ct-admin-logo"><img class="ct-brand-logo ct-brand-logo--admin" src="<?php echo esc_url(self::logo_url($settings)); ?>" alt="ClaimTrack <?php echo esc_attr($settings['region_label']); ?>"><b>SW ADMIN</b></div>
                <div class="ct-admin-nav-scroll">
                    <div class="ct-admin-nav-group"><span>RINGKASAN</span><nav class="ct-admin-nav">
                        <?php $items=array('overview'=>'dashboard','achievement'=>'chart-line'); foreach($items as $key=>$icon): ?>
                        <a href="<?php echo esc_url(self::admin_portal_url($key)); ?>" class="<?php echo $section===$key?'is-active':''; ?>"><span class="dashicons dashicons-<?php echo esc_attr($icon); ?>"></span><em><?php echo esc_html($labels[$key]); ?></em></a>
                        <?php endforeach; ?>
                    </nav></div>
                    <div class="ct-admin-nav-group"><span>MONITORING &amp; KINERJA</span><nav class="ct-admin-nav">
                    <?php foreach(self::additional_menu_items() as $key=>$item): ?>
                    <a href="<?php echo esc_url(self::admin_portal_url($key)); ?>" class="<?php echo $section===$key?'is-active':''; ?>"><span class="dashicons dashicons-<?php echo esc_attr($item['icon']); ?>"></span><em><?php echo esc_html($item['label']); ?></em></a>
                    <?php endforeach; ?></nav></div>
                    <div class="ct-admin-nav-group"><span>INPUT FASE</span><nav class="ct-admin-nav">
                        <?php $items=array('phase1'=>'chart-pie','phase2'=>'media-document','phase3'=>'yes-alt','subrogation'=>'networking'); foreach($items as $key=>$icon): ?>
                        <a href="<?php echo esc_url(self::admin_portal_url($key)); ?>" class="<?php echo $section===$key?'is-active':''; ?>"><span class="dashicons dashicons-<?php echo esc_attr($icon); ?>"></span><em><?php echo esc_html($labels[$key]); ?></em></a>
                        <?php endforeach; ?>
                    </nav></div>
                    <div class="ct-admin-nav-group"><span>KONTEN</span><nav class="ct-admin-nav">
                        <?php $items=array('news'=>'plus-alt2','news_list'=>'list-view','knowledge'=>'welcome-learn-more'); foreach($items as $key=>$icon): ?>
                        <a href="<?php echo esc_url(self::admin_portal_url($key)); ?>" class="<?php echo $section===$key?'is-active':''; ?>"><span class="dashicons dashicons-<?php echo esc_attr($icon); ?>"></span><em><?php echo esc_html($labels[$key]); ?></em></a>
                        <?php endforeach; ?>
                    </nav></div>
                    <div class="ct-admin-nav-group"><span>PENGELOLAAN</span><nav class="ct-admin-nav">
                        <?php $items=array('users'=>'admin-users','units'=>'building','programs'=>'screenoptions','providers'=>'groups','debitur'=>'id-alt','import'=>'database-import','settings'=>'admin-generic'); foreach($items as $key=>$icon): ?>
                        <a href="<?php echo esc_url(self::admin_portal_url($key)); ?>" class="<?php echo $section===$key?'is-active':''; ?>"><span class="dashicons dashicons-<?php echo esc_attr($icon); ?>"></span><em><?php echo esc_html($labels[$key]); ?></em></a>
                        <?php endforeach; ?>
                    </nav></div>
                </div>
                <div class="ct-admin-sidebar-foot"><a href="<?php echo esc_url(self::app_url()); ?>"><span class="dashicons dashicons-arrow-left-alt"></span>Kembali ke Dashboard</a><a class="ct-admin-logout-link" href="<?php echo esc_url(wp_logout_url(self::admin_portal_url('overview'))); ?>"><span class="dashicons dashicons-exit"></span>Logout Admin</a></div>
            </aside>
            <button type="button" class="ct-sidebar-backdrop" data-ct-backdrop aria-label="Tutup menu"></button>
            <main class="ct-admin-main">
                <header class="ct-admin-topbar"><div><button class="ct-menu-btn" type="button" data-ct-toggle><span class="dashicons dashicons-menu-alt"></span></button><span class="ct-admin-kicker">SW ADMIN / <?php echo esc_html(strtoupper($section)); ?></span><h1><?php echo esc_html($labels[$section]); ?></h1></div><div class="ct-admin-topbar-actions"><div class="ct-admin-user"><span class="dashicons dashicons-admin-users"></span><div><strong><?php echo esc_html($user->display_name); ?></strong><small><?php echo esc_html(self::user_access_label($user)); ?></small></div></div><a class="ct-admin-logout" href="<?php echo esc_url(wp_logout_url(self::admin_portal_url('overview'))); ?>" title="Logout Admin" aria-label="Logout Admin"><span class="dashicons dashicons-exit"></span><em>Logout</em></a></div></header>
                <?php self::notice(); ?>
                <div class="ct-admin-content">
                <?php switch($section){
                    case 'monitoring-tempo':
                    case 'monitoring-pra-klaim':
                    case 'best-performance':
                    case 'klaim-ditolak-2025': ClaimTrack_Monitoring::render($section, true, self::admin_portal_url($section)); break;
                    case 'overview': self::render_admin_dashboard(); break;
                    case 'phase1': self::render_admin_phase($settings,'KDP','phase1'); break;
                    case 'phase2': self::render_admin_phase($settings,'DOK_LENGKAP','phase2'); break;
                    case 'phase3': self::render_admin_phase($settings,'TERBUKU','phase3'); break;
                    case 'subrogation': self::render_admin_subrogation(); break;
                    case 'achievement': self::render_achievement(); break;
                    case 'news': self::render_admin_news(); break;
                    case 'news_list': self::render_admin_news_list(); break;
                    case 'units': self::render_master('units'); break;
                    case 'programs': self::render_master('programs'); break;
                    case 'providers': self::render_master('providers'); break;
                    case 'knowledge': self::render_knowledge(); break;
                    case 'import': self::render_import_export(); break;
                    case 'settings': self::render_settings($settings); break;
                    case 'users': self::render_admin_users(); break;
                    case 'debitur': self::render_admin_debitur(); break;
                } ?>
                </div>
            </main>
            <nav class="ct-admin-mobile-nav" aria-label="Navigasi cepat SW Admin">
                <a href="<?php echo esc_url(self::admin_portal_url('overview')); ?>" class="<?php echo $section==='overview'?'is-active':''; ?>"><span class="ct-mobile-nav-icon"><span class="dashicons dashicons-dashboard"></span></span><em>Dashboard</em></a>
                <a href="<?php echo esc_url(self::admin_portal_url('phase1')); ?>" class="<?php echo $section==='phase1'?'is-active':''; ?>"><span class="ct-mobile-nav-icon"><span class="dashicons dashicons-chart-pie"></span></span><em>Fase 1</em></a>
                <a href="<?php echo esc_url(self::admin_portal_url('phase2')); ?>" class="<?php echo $section==='phase2'?'is-active':''; ?>"><span class="ct-mobile-nav-icon"><span class="dashicons dashicons-media-document"></span></span><em>Fase 2</em></a>
                <a href="<?php echo esc_url(self::admin_portal_url('phase3')); ?>" class="<?php echo $section==='phase3'?'is-active':''; ?>"><span class="ct-mobile-nav-icon"><span class="dashicons dashicons-yes-alt"></span></span><em>Fase 3</em></a>
                <a href="<?php echo esc_url(self::admin_portal_url('news_list')); ?>" class="<?php echo in_array($section,array('news','news_list'),true)?'is-active':''; ?>"><span class="ct-mobile-nav-icon"><span class="dashicons dashicons-megaphone"></span></span><em>Berita</em></a>
                <button type="button" data-ct-toggle><span class="ct-mobile-nav-icon"><span class="dashicons dashicons-menu-alt"></span></span><em>Menu</em></button>
            </nav>
        </div><?php self::$admin_portal=false;
    }


    private static function save_debitur(){
        global $wpdb;
        check_admin_referer('claimtrack_action','claimtrack_nonce');
        $t=ClaimTrack_DB::tables();
        $id=(int)($_POST['id']??0);
        $data=array(
            'unit_id'=>(int)($_POST['unit_id']??0),
            'program_id'=>(int)($_POST['program_id']??0),
            'provider_id'=>(int)($_POST['provider_id']??0),
            'nama_nasabah'=>sanitize_text_field($_POST['nama_nasabah']??''),
            'nomor_klaim'=>sanitize_text_field($_POST['nomor_klaim']??''),
            'amount_million'=>(float)($_POST['amount_million']??0),
            'status_klaim'=>sanitize_text_field($_POST['status_klaim']??'Dalam Proses'),
            'updated_at'=>current_time('mysql'),
        );
        if($id>0){$wpdb->update($t['debitur'],$data,array('id'=>$id));}
        else{$data['created_at']=current_time('mysql');$wpdb->insert($t['debitur'],$data);}
        return true;
    }

    private static function delete_debitur(){
        global $wpdb; check_admin_referer('claimtrack_action','claimtrack_nonce');
        $wpdb->delete(ClaimTrack_DB::tables()['debitur'],array('id'=>(int)($_POST['id']??0)));
        return true;
    }

    private static function render_admin_debitur(){
        global $wpdb;
        $t=ClaimTrack_DB::tables();
        $units=$wpdb->get_results("SELECT * FROM {$t['units']} ORDER BY name");
        $programs=$wpdb->get_results("SELECT * FROM {$t['programs']} ORDER BY name");
        $providers=$wpdb->get_results("SELECT * FROM {$t['providers']} ORDER BY name");
        $rows=$wpdb->get_results("SELECT d.*,u.name unit_name,p.name program_name,v.name provider_name FROM {$t['debitur']} d LEFT JOIN {$t['units']} u ON u.id=d.unit_id LEFT JOIN {$t['programs']} p ON p.id=d.program_id LEFT JOIN {$t['providers']} v ON v.id=d.provider_id ORDER BY d.id DESC");
        ?>
        <div class="ct-section-head"><div><h1>Data Debitur</h1><p>Input dan pengelolaan data debitur nominatif ClaimTrack.</p></div></div>
        <div class="ct-two-col">
        <?php $editDebitur=null; if(isset($_GET['edit_debitur'])){$editDebitur=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['debitur']} WHERE id=%d",(int)$_GET['edit_debitur']));} ?>
        <article class="ct-panel"><h3><?php echo $editDebitur?'Edit Data Debitur':'Tambah Data Debitur'; ?></h3>
        <form method="post" class="ct-form">
        <?php wp_nonce_field('claimtrack_action','claimtrack_nonce'); ?><input type="hidden" name="claimtrack_action" value="debitur_save"><input type="hidden" name="id" value="<?php echo esc_attr($editDebitur->id??0); ?>">
        <label>Unit Kerja<select name="unit_id" required><?php foreach($units as $x):?><option value="<?=$x->id?>"><?=esc_html($x->name)?></option><?php endforeach;?></select></label>
        <label>Program<select name="program_id" required><?php foreach($programs as $x):?><option value="<?=$x->id?>"><?=esc_html($x->name)?></option><?php endforeach;?></select></label>
        <label>Asuradur<select name="provider_id"><option value="0">- Pilih -</option><?php foreach($providers as $x):?><option value="<?=$x->id?>"><?=esc_html($x->name)?></option><?php endforeach;?></select></label>
        <label>Nama Debitur<input name="nama_nasabah" value="<?php echo esc_attr($editDebitur->nama_nasabah??''); ?>" required></label>
        <label>Nomor Klaim<input name="nomor_klaim" value="<?php echo esc_attr($editDebitur->nomor_klaim??''); ?>"></label>
        <label>Nilai Klaim (Juta)<input type="number" step="0.01" name="amount_million" value="<?php echo esc_attr($editDebitur->amount_million??''); ?>"></label>
        <label>Status<select name="status_klaim"><option>Dalam Proses</option><option>Selesai</option><option>Ditolak</option></select></label>
        <button class="ct-btn ct-btn--primary">Simpan Data Debitur</button>
        </form></article>
        <article class="ct-panel"><h3>Daftar Debitur</h3><div class="ct-table-scroll"><table class="ct-table"><thead><tr><th>Nama</th><th>Unit</th><th>Program</th><th>Nilai</th><th>Status</th><th>Aksi</th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td><?=esc_html($r->nama_nasabah)?></td><td><?=esc_html($r->unit_name)?></td><td><?=esc_html($r->program_name)?></td><td><?=esc_html($r->amount_million)?></td><td><?=esc_html($r->status_klaim)?></td><td><a class="ct-link" href="<?php echo esc_url(self::admin_portal_url('debitur',array('edit_debitur'=>$r->id))); ?>">Edit</a> <form style="display:inline" method="post"><?php wp_nonce_field('claimtrack_action','claimtrack_nonce');?><input type="hidden" name="claimtrack_action" value="debitur_delete"><input type="hidden" name="id" value="<?=$r->id?>"><button class="ct-link ct-link--danger">Hapus</button></form></td></tr><?php endforeach;?></tbody></table></div></article>
        </div>
        <?php
    }

    private static function render_admin_users() {
        if (!self::can_manage()) { echo '<div class="ct-panel"><h2>Akses Ditolak</h2><p>Menu User hanya tersedia untuk Administrator ClaimTrack.</p></div>'; return; }
        $all = get_users(array('orderby'=>'display_name','order'=>'ASC'));
        $users = array();
        foreach ($all as $account) {
            /* Administrator utama sengaja tidak ditampilkan pada daftar User Viewer. */
            if (self::is_primary_admin_user($account)) { continue; }
            if (in_array('claimtrack_viewer',(array)$account->roles,true) || $account->has_cap('claimtrack_view')) {
                $users[] = $account;
            }
        }
        $user_count = count($users);
        $viewer_count = count(array_filter($users, function($u){ return in_array('claimtrack_viewer',(array)$u->roles,true); }));
        $admin_count = count(array_filter($users, function($u){ return self::is_claimtrack_admin_user($u); }));
        ?>
        <div class="ct-admin-users-page">
            <section class="ct-admin-users-hero">
                <div><span class="ct-admin-eyebrow">AKSES PENGGUNA</span><h2>Kelola User ClaimTrack</h2><p>Tambahkan akun Viewer dan kelola password pengguna ClaimTrack. Akun Admin memiliki akses penuh ke SW Admin.</p></div>
                <div class="ct-admin-users-summary"><span class="dashicons dashicons-admin-users"></span><strong><?php echo esc_html(number_format_i18n($user_count)); ?></strong><small>User ClaimTrack</small><em><?php echo esc_html($admin_count); ?> admin · <?php echo esc_html($viewer_count); ?> viewer</em></div>
            </section>

            <div class="ct-admin-users-grid">
                <section class="ct-panel ct-user-create-panel">
                    <div class="ct-section-title-row"><div><span>USER BARU</span><h3>Tambah Viewer</h3></div><span class="ct-glass-symbol"><span class="dashicons dashicons-plus-alt2"></span></span></div>
                    <form method="post" class="ct-form ct-user-create-form" autocomplete="off">
                        <?php wp_nonce_field('claimtrack_action','claimtrack_nonce'); ?>
                        <input type="hidden" name="claimtrack_action" value="user_add">
                        <label>Nama User<input type="text" name="new_display_name" required placeholder="Contoh: Andi Saputra"></label>
                        <label>Username<input type="text" name="new_username" required autocomplete="off" placeholder="andi.saputra"></label>
                        <label>Email <small>(opsional)</small><input type="email" name="new_email" autocomplete="off" placeholder="nama@perusahaan.co.id"></label>
                        <label>Password<input type="password" name="new_password" required minlength="8" autocomplete="new-password" placeholder="Minimal 8 karakter"></label>
                        <label>Konfirmasi Password<input type="password" name="new_password_confirm" required minlength="8" autocomplete="new-password" placeholder="Ulangi password"></label>
                        <div class="ct-user-role-lock"><span class="dashicons dashicons-lock"></span><div><strong>Role otomatis: Viewer</strong><small>User baru hanya dapat melihat dashboard, berita, fase, pencapaian, dan E-Knowledge.</small></div></div>
                        <button class="ct-btn ct-btn--primary" type="submit"><span class="dashicons dashicons-admin-users"></span>Tambah User Viewer</button>
                    </form>
                </section>

            </div>

            <section class="ct-panel ct-users-list-panel">
                <div class="ct-section-title-row"><div><span>DAFTAR AKUN</span><h3>User ClaimTrack Aktif</h3></div><span class="ct-users-count-badge"><?php echo esc_html(number_format_i18n($user_count)); ?> user</span></div>
                <div class="ct-users-list">
                    <?php foreach ($users as $account): $is_admin=self::is_claimtrack_admin_user($account); $initials='U'; $parts=preg_split('/\s+/',trim((string)$account->display_name)); if($parts){$initials=strtoupper(substr($parts[0]??'U',0,1).substr($parts[count($parts)-1]??'',0,1));} ?>
                    <article class="ct-user-row <?php echo $is_admin?'is-primary-admin':''; ?>">
                        <div class="ct-user-identity"><div class="ct-user-avatar"><?php echo esc_html($initials); ?></div><div><strong><?php echo esc_html($account->display_name ?: $account->user_login); ?></strong><small>@<?php echo esc_html($account->user_login); ?><?php echo $account->user_email ? ' · '.esc_html($account->user_email) : ''; ?></small></div></div>
                        <span class="ct-role-badge <?php echo $is_admin?'is-admin':'is-viewer'; ?>"><?php echo $is_admin?'ADMIN':'VIEWER'; ?></span>
                        <details class="ct-user-password-box">
                            <summary><span class="dashicons dashicons-lock"></span>Ganti Password</summary>
                            <form method="post" class="ct-user-password-form" autocomplete="off">
                                <?php wp_nonce_field('claimtrack_action','claimtrack_nonce'); ?>
                                <input type="hidden" name="claimtrack_action" value="user_password">
                                <input type="hidden" name="user_id" value="<?php echo esc_attr((int)$account->ID); ?>">
                                <label>Password Baru<input type="password" name="user_password" required minlength="8" autocomplete="new-password" placeholder="Minimal 8 karakter"></label>
                                <label>Konfirmasi<input type="password" name="user_password_confirm" required minlength="8" autocomplete="new-password" placeholder="Ulangi password"></label>
                                <button class="ct-btn ct-btn--primary ct-btn--compact" type="submit"><span class="dashicons dashicons-saved"></span>Simpan Password</button>
                            </form>
                        </details>
                    </article>
                    <?php endforeach; ?>
                </div>
            </section>
        </div>
        <?php
    }

    private static function render_admin_dashboard() {
        global $wpdb; $t=ClaimTrack_DB::tables(); $months=self::month_names();
        $year=max(2000,min(2100,(int)($_GET['year']??wp_date('Y'))));
        $month=max(1,min(12,(int)($_GET['month']??wp_date('n'))));
        $phaseDefs=array('KDP'=>array('label'=>'Fase 1 Berkas Belum Lengkap','name'=>'Berkas Belum Lengkap','section'=>'phase1','icon'=>'chart-pie'),'DOK_LENGKAP'=>array('label'=>'Fase 2 Berkas Lengkap','name'=>'Berkas Lengkap','section'=>'phase2','icon'=>'media-document'),'TERBUKU'=>array('label'=>'Fase 3 Klaim Terbuku','name'=>'Klaim Terbuku','section'=>'phase3','icon'=>'yes-alt'));
        $phaseIds=array(); $phaseTotals=array(); $grand=0.0;
        foreach($phaseDefs as $code=>$def){
            $id=(int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['programs']} WHERE code=%s AND active=1 LIMIT 1",$code));
            $phaseIds[$code]=$id;
            $v=$id?(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount_million),0) FROM {$t['entries']} WHERE program_id=%d AND year=%d AND month=%d",$id,$year,$month)):0.0;
            $phaseTotals[$code]=$v; $grand+=$v;
        }
        $activeUnits=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['units']} WHERE active=1");
        $activeProviders=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t['providers']} WHERE active=1");
        $entryCount=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['entries']} WHERE year=%d AND month=%d",$year,$month));
        $newsCount=(int)(wp_count_posts('ct_news')->publish??0);

        // Trend bulanan tiga fase pada tahun terpilih.
        $trend=array();
        foreach($phaseDefs as $code=>$def){
            $vals=array();
            for($m=1;$m<=12;$m++){
                $vals[]=$phaseIds[$code]?(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount_million),0) FROM {$t['entries']} WHERE program_id=%d AND year=%d AND month=%d",$phaseIds[$code],$year,$m)):0.0;
            }
            $trend[$def['label']]=$vals;
        }

        // Distribusi asuradur untuk tiga fase pada periode aktif.
        $programIdList=array_values(array_filter(array_map('intval',$phaseIds)));
        $providerItems=array();
        $providers=$wpdb->get_results("SELECT * FROM {$t['providers']} WHERE active=1 ORDER BY sort_order,name");
        foreach($providers as $pr){
            $v=0.0;
            if($programIdList){$in=implode(',',array_map('intval',$programIdList));$v=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount_million),0) FROM {$t['entries']} WHERE provider_id=%d AND program_id IN ($in) AND year=%d AND month=%d",$pr->id,$year,$month));}
            $providerItems[]=array('id'=>'provider-'.$pr->id,'name'=>$pr->name,'value'=>$v);
        }

        // Top unit kerja periode aktif.
        $topUnits=array();
        if($programIdList){
            $in=implode(',',array_map('intval',$programIdList));
            $topUnits=$wpdb->get_results($wpdb->prepare("SELECT u.id,u.name,COALESCE(SUM(e.amount_million),0) total FROM {$t['units']} u LEFT JOIN {$t['entries']} e ON e.unit_id=u.id AND e.program_id IN ($in) AND e.year=%d AND e.month=%d WHERE u.active=1 GROUP BY u.id,u.name ORDER BY total DESC,u.name ASC LIMIT 7",$year,$month));
        }
        $maxUnit=0.0; foreach($topUnits as $u){$maxUnit=max($maxUnit,(float)$u->total);} if($maxUnit<=0)$maxUnit=1;
        $latestNews=get_posts(array('post_type'=>'ct_news','post_status'=>'publish','posts_per_page'=>4,'orderby'=>'date','order'=>'DESC'));
        ?>
        <section class="ct-admin-overview ct-admin-overview--advanced">
            <div class="ct-admin-welcome ct-admin-welcome--advanced">
                <div class="ct-admin-welcome-copy"><span>CONTROL CENTER</span><h2>Dashboard Operasional ClaimTrack</h2><p>Ringkasan posisi klaim, tren per fase, distribusi asuradur, dan aktivitas pengelolaan dalam satu layar.</p></div>
                <form method="get" class="ct-admin-period" data-ct-auto-period><input type="hidden" name="section" value="overview"><label><span class="dashicons dashicons-calendar-alt"></span><select name="month"><?php foreach($months as $n=>$m):?><option value="<?php echo (int)$n;?>" <?php selected($month,$n);?>><?php echo esc_html($m);?></option><?php endforeach;?></select></label><label><span class="dashicons dashicons-clock"></span><input type="number" name="year" value="<?php echo esc_attr($year);?>" min="2000" max="2100"></label></form>
            </div>

            <div class="ct-admin-kpi-grid">
                <article class="ct-admin-kpi ct-admin-kpi--total"><div class="ct-admin-kpi-icon"><span class="dashicons dashicons-chart-area"></span></div><div><small>TOTAL KLAIM</small><strong>IDR <?php echo esc_html(self::fmt_phase_card($grand));?></strong><span><?php echo esc_html($months[$month].' '.$year);?></span></div></article>
                <?php foreach($phaseDefs as $code=>$def):?><a class="ct-admin-kpi" href="<?php echo esc_url(self::admin_portal_url($def['section'],array('month'=>$month,'year'=>$year)));?>"><div class="ct-admin-kpi-icon"><span class="dashicons dashicons-<?php echo esc_attr($def['icon']);?>"></span></div><div><small><?php echo esc_html($def['label']);?></small><strong>IDR <?php echo esc_html(self::fmt_phase_card($phaseTotals[$code]));?></strong><span><?php echo esc_html($def['name']);?> · Input data</span></div></a><?php endforeach;?>
                <article class="ct-admin-kpi"><div class="ct-admin-kpi-icon"><span class="dashicons dashicons-building"></span></div><div><small>UNIT AKTIF</small><strong><?php echo esc_html(number_format_i18n($activeUnits));?></strong><span><?php echo esc_html(number_format_i18n($activeProviders));?> mitra/asuradur</span></div></article>
                <article class="ct-admin-kpi"><div class="ct-admin-kpi-icon"><span class="dashicons dashicons-database"></span></div><div><small>RECORD PERIODE</small><strong><?php echo esc_html(number_format_i18n($entryCount));?></strong><span><?php echo esc_html(number_format_i18n($newsCount));?> berita terbit</span></div></article>
            </div>

            <div class="ct-admin-dashboard-grid">
                <article class="ct-panel ct-admin-chart-panel ct-admin-grid-span-2">
                    <div class="ct-admin-panel-head"><div><small>TREND 12 BULAN</small><h3>Pergerakan Klaim per Fase · <?php echo esc_html($year);?></h3></div><span class="ct-admin-panel-chip">Juta Rupiah</span></div>
                    <div class="ct-chart ct-admin-trend-chart" data-ct-chart data-tooltip-label="Total klaim" data-series='<?php echo esc_attr(wp_json_encode($trend));?>'></div>
                </article>
                <article class="ct-panel ct-admin-provider-panel">
                    <div class="ct-admin-panel-head"><div><small>KOMPOSISI</small><h3>Distribusi per Asuradur</h3></div><span class="ct-admin-panel-chip"><?php echo esc_html($months[$month]);?></span></div>
                    <div class="ct-admin-donut-wrap" data-ct-static-donut data-donut-kind="provider" data-total-label="Total klaim" data-label-count="4" data-items='<?php echo esc_attr(wp_json_encode($providerItems));?>'><div class="ct-kdp-reference-donut ct-admin-donut" data-ct-static-ring><div class="ct-kdp-reference-hole"><span class="dashicons dashicons-groups"></span></div><div class="ct-kdp-reference-labels" data-ct-static-labels></div></div></div>
                </article>
                <article class="ct-panel ct-admin-unit-rank">
                    <div class="ct-admin-panel-head"><div><small>TOP UKER</small><h3>Kontribusi Unit Kerja</h3></div><span class="ct-admin-panel-chip">Top 7</span></div>
                    <div class="ct-admin-rank-list"><?php if($topUnits): foreach($topUnits as $i=>$u): $pct=min(100,max(0,((float)$u->total/$maxUnit)*100));?><div class="ct-admin-rank-row"><span class="ct-admin-rank-no"><?php echo (int)($i+1);?></span><div><div class="ct-admin-rank-meta"><strong><?php echo esc_html($u->name);?></strong><b><?php echo esc_html(number_format((float)$u->total,0,',','.'));?></b></div><div class="ct-admin-rank-track"><i style="width:<?php echo esc_attr(number_format($pct,2,'.',''));?>%"></i></div></div></div><?php endforeach; else:?><div class="ct-admin-empty-mini">Belum ada data pada periode ini.</div><?php endif;?></div>
                </article>
            </div>

            <div class="ct-admin-lower-grid">
                <article class="ct-panel ct-admin-quick-panel"><div class="ct-admin-panel-head"><div><small>AKSI CEPAT</small><h3>Pengelolaan Utama</h3></div></div><div class="ct-admin-quick-grid ct-admin-quick-grid--advanced"><a href="<?php echo esc_url(self::admin_portal_url('phase1',array('month'=>$month,'year'=>$year)));?>"><span class="dashicons dashicons-edit-page"></span><strong>Input FASE 1</strong><small>KDP · Minggu I-IV</small></a><a href="<?php echo esc_url(self::admin_portal_url('phase2',array('month'=>$month,'year'=>$year)));?>"><span class="dashicons dashicons-media-document"></span><strong>Input FASE 2</strong><small>Dok. Lengkap</small></a><a href="<?php echo esc_url(self::admin_portal_url('phase3',array('month'=>$month,'year'=>$year)));?>"><span class="dashicons dashicons-yes-alt"></span><strong>Input FASE 3</strong><small>Klaim Terbuku</small></a><a href="<?php echo esc_url(self::admin_portal_url('news'));?>"><span class="dashicons dashicons-megaphone"></span><strong>Tambah Berita</strong><small>Publikasi internal</small></a><a href="<?php echo esc_url(self::admin_portal_url('knowledge'));?>"><span class="dashicons dashicons-welcome-learn-more"></span><strong>E-Knowledge</strong><small>Kelola materi</small></a><a href="<?php echo esc_url(self::admin_portal_url('import'));?>"><span class="dashicons dashicons-backup"></span><strong>Backup & Restore</strong><small>Amankan data</small></a><a href="<?php echo esc_url(self::admin_portal_url('debitur'));?>"><span class="dashicons dashicons-id-alt"></span><strong>Data Debitur</strong><small>Kelola nominatif</small></a></div></article>
                <article class="ct-panel ct-admin-news-mini"><div class="ct-admin-panel-head"><div><small>KONTEN TERBARU</small><h3>Berita Terakhir</h3></div><a href="<?php echo esc_url(self::admin_portal_url('news_list'));?>">Lihat semua</a></div><?php if($latestNews):?><div class="ct-admin-news-mini-list"><?php foreach($latestNews as $n):?><a href="<?php echo esc_url(self::admin_portal_url('news',array('edit_news'=>$n->ID)));?>"><span class="dashicons dashicons-megaphone"></span><div><strong><?php echo esc_html($n->post_title);?></strong><small><?php echo esc_html(wp_date('j M Y',strtotime($n->post_date)));?> · <?php echo esc_html(number_format_i18n((int)get_comments_number($n->ID)));?> komentar</small></div></a><?php endforeach;?></div><?php else:?><div class="ct-admin-empty-mini">Belum ada berita yang diterbitkan.</div><?php endif;?></article>
            </div>
        </section><?php
    }

    private static function render_admin_news() {
        $editId=max(0,(int)($_GET['edit_news'] ?? 0));
        $edit=$editId?get_post($editId):null;
        if(!($edit instanceof WP_Post)||$edit->post_type!=='ct_news'){$edit=null;$editId=0;}
        if(function_exists('wp_enqueue_editor')){wp_enqueue_editor();}
        ?>
        <section class="ct-admin-news ct-admin-news-editor-page">
            <div class="ct-section-head"><div><h1><?php echo $edit?'Edit Berita':'Tambah Berita'; ?></h1><p>Tulis informasi internal dengan editor visual. Berita yang diterbitkan akan muncul pada Home ClaimTrack dan dapat dikomentari karyawan.</p></div><a class="ct-btn ct-btn--light" href="<?php echo esc_url(self::admin_portal_url('news_list')); ?>"><span class="dashicons dashicons-list-view"></span>List Berita</a></div>
            <div class="ct-panel ct-news-editor">
                <form method="post" enctype="multipart/form-data" class="ct-form ct-news-form">
                    <?php wp_nonce_field('claimtrack_action','claimtrack_nonce'); ?>
                    <input type="hidden" name="claimtrack_action" value="news_save"><input type="hidden" name="news_id" value="<?php echo (int)$editId; ?>">
                    <label>Judul Berita<input name="news_title" value="<?php echo esc_attr($edit?$edit->post_title:''); ?>" required placeholder="Masukkan judul berita"></label>
                    <label>Urutan<input type="number" name="news_sort" value="<?php echo esc_attr($edit?(int)$edit->menu_order:0); ?>" min="0"></label>
                    <label class="ct-form-span-2">Ringkasan<textarea name="news_excerpt" rows="3" placeholder="Ringkasan singkat untuk kartu berita"><?php echo esc_textarea($edit?$edit->post_excerpt:''); ?></textarea></label>
                    <div class="ct-form-span-2 ct-wysiwyg-field"><span class="ct-field-label">Isi Berita</span>
                        <?php wp_editor($edit?$edit->post_content:'','claimtrack_news_content_editor',array('textarea_name'=>'news_content','textarea_rows'=>15,'media_buttons'=>false,'teeny'=>false,'quicktags'=>true,'tinymce'=>array('toolbar1'=>'formatselect,bold,italic,bullist,numlist,blockquote,alignleft,aligncenter,alignright,link,unlink,undo,redo','toolbar2'=>'forecolor,removeformat,outdent,indent'))); ?>
                    </div>
                    <label>Cover Gambar<input type="file" name="news_cover" accept="image/jpeg,image/png,image/webp"></label>
                    <label class="ct-check"><input type="checkbox" name="news_featured" value="1" <?php checked($edit?(int)get_post_meta($editId,'_claimtrack_news_featured',true):0,1); ?>><span>Jadikan berita utama</span></label>
                    <div class="ct-form-span-2 ct-form-actions"><button class="ct-btn ct-btn--primary" type="submit"><span class="dashicons dashicons-saved"></span><?php echo $edit?'Simpan Perubahan':'Terbitkan Berita'; ?></button><?php if($edit):?><a class="ct-btn ct-btn--light" href="<?php echo esc_url(self::admin_portal_url('news_list')); ?>">Batal</a><?php endif;?></div>
                </form>
            </div>
        </section><?php
    }

    private static function render_admin_news_list() {
        $items=get_posts(array('post_type'=>'ct_news','post_status'=>array('publish','draft','pending'),'posts_per_page'=>-1,'orderby'=>array('menu_order'=>'ASC','date'=>'DESC'))); ?>
        <section class="ct-admin-news ct-admin-news-list-page">
            <div class="ct-section-head"><div><h1>List Berita</h1><p>Daftar seluruh berita yang sudah dibuat. Edit, hapus, atau buka berita langsung dari sini.</p></div><a class="ct-btn ct-btn--primary" href="<?php echo esc_url(self::admin_portal_url('news')); ?>"><span class="dashicons dashicons-plus-alt2"></span>Tambah Berita</a></div>
            <?php if($items): ?>
            <div class="ct-admin-news-table-wrap ct-panel"><div class="ct-table-scroll"><table class="ct-table ct-admin-news-table"><thead><tr><th>Cover</th><th>Berita</th><th>Tanggal</th><th>Komentar</th><th>Status</th><th>Aksi</th></tr></thead><tbody>
                <?php foreach($items as $item): $thumb=get_the_post_thumbnail_url($item,'thumbnail'); $commentCount=(int)get_comments_number($item->ID); ?>
                <tr><td><div class="ct-news-list-thumb" <?php echo $thumb?'style="background-image:url('.esc_url($thumb).')"':''; ?>></div></td><td><strong><?php echo esc_html($item->post_title); ?></strong><small><?php echo esc_html(wp_trim_words(wp_strip_all_tags($item->post_excerpt?:$item->post_content),16,'…')); ?></small></td><td><?php echo esc_html(wp_date('j M Y',strtotime($item->post_date))); ?></td><td><?php echo esc_html(number_format_i18n($commentCount)); ?></td><td><span class="ct-badge <?php echo $item->post_status==='publish'?'is-on':'is-off'; ?>"><?php echo esc_html($item->post_status==='publish'?'Terbit':ucfirst($item->post_status)); ?></span></td><td class="ct-actions"><a class="ct-link" href="<?php echo esc_url(self::admin_portal_url('news',array('edit_news'=>$item->ID))); ?>">Edit</a><form method="post" data-ct-confirm="Hapus berita ini?" data-ct-confirm-title="Hapus Berita"><?php wp_nonce_field('claimtrack_action','claimtrack_nonce'); ?><input type="hidden" name="claimtrack_action" value="news_delete"><input type="hidden" name="news_id" value="<?php echo (int)$item->ID; ?>"><button class="ct-link ct-link--danger" type="submit">Hapus</button></form></td></tr>
                <?php endforeach; ?>
            </tbody></table></div></div>
            <?php else: ?><div class="ct-panel ct-news-list-empty"><span class="dashicons dashicons-megaphone"></span><h3>Belum ada berita</h3><p>Tambahkan berita pertama untuk ditampilkan pada Home ClaimTrack.</p><a class="ct-btn ct-btn--primary" href="<?php echo esc_url(self::admin_portal_url('news')); ?>">Tambah Berita</a></div><?php endif; ?>
        </section><?php
    }

    private static function render_admin_phase($settings,$code,$section='phase1') {
        global $wpdb; $t=ClaimTrack_DB::tables();
        $programId=(int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['programs']} WHERE code=%s AND active=1 LIMIT 1",$code));
        if(!$programId){echo '<section class="ct-content"><div class="ct-panel"><h3>Program belum tersedia</h3><p>Aktifkan program terkait dari menu Program / Fase.</p></div></section>';return;}
        self::render_matrix($programId,$section);
    }

    private static function render_admin_subrogation() {
        global $wpdb; $t=ClaimTrack_DB::tables();
        $programId=(int)$wpdb->get_var("SELECT id FROM {$t['programs']} WHERE code='SUBROGASI' AND active=1 LIMIT 1");
        if(!$programId){echo '<section class="ct-content"><div class="ct-panel"><h3>Program belum tersedia</h3><p>Aktifkan program Potensi Subrogasi dari menu Program / Fase.</p></div></section>';return;}
        self::render_matrix($programId,'subrogation');
    }

    private static function additional_menu_items() {
        return array(
            'monitoring-tempo'=>array('label'=>'Monitoring Jt Tempo Klaim','slug'=>'monitoring-jt-tempo-klaim','icon'=>'clock'),
            'monitoring-pra-klaim'=>array('label'=>'Monitoring Pra Klaim','slug'=>'monitoring-pra-klaim','icon'=>'clipboard'),
            'best-performance'=>array('label'=>'Best Performance','slug'=>'best-performance','icon'=>'awards'),
            'klaim-ditolak-2025'=>array('label'=>'Klaim Ditolak 2025','slug'=>'klaim-ditolak-2025','icon'=>'dismiss'),
        );
    }

    private static function render_additional_menu($view) {
        ClaimTrack_Monitoring::render($view, false, self::admin_portal_url($view));
    }

    private static function render_shell($view) {
        global $wpdb; $t=ClaimTrack_DB::tables();
        $settings=self::get_settings();
        $programs=$wpdb->get_results("SELECT * FROM {$t['programs']} WHERE active=1 ORDER BY dashboard_order,name");
        $user=wp_get_current_user();
        $pageTitle=self::view_title($view,$programs);
        $kdp=self::program_by_code($programs,'KDP');
        $isPhaseView=($view==='phase');
        // Fase detail/overview menggunakan shell dashboard normal. Hindari class legacy
        // ct-view-phase yang pada versi lama menyembunyikan topbar/sidebar di desktop.
        $viewCssClass = ($view === 'phase') ? 'claim-phase' : $view;
        $initials='CT';
        if($user && $user->display_name){
            $parts=preg_split('/\s+/',trim($user->display_name));
            $initials=strtoupper(substr($parts[0]??'C',0,1).substr($parts[count($parts)-1]??'T',0,1));
        }
        ?>
        <div class="ct-app ct-view-<?php echo esc_attr($viewCssClass); ?> <?php echo $isPhaseView?'ct-phase-dashboard-shell':''; ?>" data-ct-app style="<?php echo esc_attr(self::theme_style_vars($settings)); ?>">
            <aside class="ct-sidebar" data-ct-sidebar>
                <div class="ct-logo-wrap"><img class="ct-brand-logo ct-brand-logo--sidebar" src="<?php echo esc_url(self::logo_url($settings)); ?>" alt="ClaimTrack <?php echo esc_attr($settings['region_label']); ?>"></div>

                <div class="ct-sidebar-scroll">
                    <div class="ct-nav-section ct-nav-section--monitoring">
                        <div class="ct-nav-section-title">MONITORING</div>
                        <nav class="ct-nav">
                            <a href="<?php echo esc_url(ClaimTrack_DB::get_app_page_url('home')); ?>" class="ct-nav-item <?php echo $view==='home'?'is-active':''; ?>"><span class="dashicons dashicons-admin-home"></span><em>Home</em></a>
                            <a href="<?php echo esc_url(self::app_url()); ?>" class="ct-nav-item <?php echo $view==='dashboard'?'is-active':''; ?>"><span class="dashicons dashicons-dashboard"></span><em>Dashboard</em></a>
                            <details class="ct-phase-menu-group" <?php echo $view==='phase'?'open':''; ?>>
                                <summary class="ct-nav-item ct-nav-item--phase-group <?php echo $view==='phase'?'is-active':''; ?>"><span class="dashicons dashicons-chart-pie"></span><em>Fase Klaim</em><span class="dashicons dashicons-arrow-down-alt2 ct-phase-menu-arrow"></span></summary>
                                <div class="ct-phase-submenu">
                                <?php foreach ($programs as $p): if (!in_array($p->code,array('KDP','DOK_LENGKAP','TERBUKU'),true)) continue; ?>
                                    <a class="ct-subnav <?php echo ($view==='phase' && (int)($_GET['program_id']??0)===(int)$p->id)?'is-active':''; ?>" href="<?php echo esc_url(self::app_url(array('view'=>'phase','program_id'=>$p->id,'year'=>wp_date('Y'),'month'=>wp_date('n')))); ?>"><span class="ct-subnav-dot"></span><em><?php echo esc_html(($p->phase_label?$p->phase_label.' · ':'').$p->name); ?></em></a>
                                <?php endforeach; ?>
                                </div>
                            </details>
                            <?php $sub=self::program_by_code($programs,'SUBROGASI'); ?>
                            <a href="<?php echo esc_url(self::app_url(array('view'=>'matrix','program_id'=>$sub?$sub->id:0))); ?>" class="ct-nav-item <?php echo ($view==='matrix' && (int)($_GET['program_id']??0)===(int)($sub?$sub->id:0))?'is-active':''; ?>"><span class="dashicons dashicons-networking"></span><em>Potensi Subrogasi</em></a>
                            <a href="<?php echo esc_url(self::app_url(array('view'=>'achievement'))); ?>" class="ct-nav-item <?php echo $view==='achievement'?'is-active':''; ?>"><span class="dashicons dashicons-chart-line"></span><em>Pencapaian <?php echo esc_html(wp_date('Y')); ?></em></a>
                        </nav>
                    </div>


                    <div class="ct-nav-section ct-nav-section--support">
                        <div class="ct-nav-section-title">DUKUNGAN</div>
                        <nav class="ct-nav">
                            <a href="<?php echo esc_url(self::app_url(array('view'=>'knowledge'))); ?>" class="ct-nav-item <?php echo $view==='knowledge'?'is-active':''; ?>"><span class="dashicons dashicons-welcome-learn-more"></span><em>E-Knowledge</em></a>
                            <?php foreach(self::additional_menu_items() as $menuView=>$menuItem): ?>
                            <a href="<?php echo esc_url(self::app_url(array('view'=>$menuView))); ?>" class="ct-nav-item <?php echo $view===$menuView?'is-active':''; ?>"><span class="dashicons dashicons-<?php echo esc_attr($menuItem['icon']); ?>"></span><em><?php echo esc_html($menuItem['label']); ?></em></a>
                            <?php endforeach; ?>
                        </nav>
                    </div>
                </div>

                <?php $wa=preg_replace('/[^0-9]/','',(string)($settings['admin_whatsapp']??'')); ?>
                <div class="ct-help-card ct-help-card--whatsapp">
                    <div class="ct-help-card-icon ct-help-card-icon--wa"><svg viewBox="0 0 32 32" aria-hidden="true"><path fill="currentColor" d="M19.11 17.39c-.27-.14-1.6-.79-1.85-.88-.25-.09-.43-.14-.61.14-.18.27-.7.88-.86 1.06-.16.18-.32.2-.59.07-.27-.14-1.15-.42-2.19-1.35-.81-.72-1.36-1.61-1.52-1.88-.16-.27-.02-.42.12-.55.12-.12.27-.32.41-.48.14-.16.18-.27.27-.45.09-.18.05-.34-.02-.48-.07-.14-.61-1.47-.84-2.01-.22-.53-.44-.46-.61-.47h-.52c-.18 0-.48.07-.73.34-.25.27-.95.93-.95 2.26 0 1.33.97 2.62 1.11 2.8.14.18 1.91 2.92 4.63 4.1.65.28 1.15.45 1.54.58.65.21 1.24.18 1.71.11.52-.08 1.6-.65 1.83-1.29.23-.63.23-1.18.16-1.29-.07-.11-.25-.18-.52-.32zM16.03 3.2A12.63 12.63 0 0 0 5.2 22.34L3.4 28.8l6.61-1.74A12.6 12.6 0 1 0 16.03 3.2zm0 22.94c-2.02 0-4-.54-5.72-1.57l-.41-.24-3.92 1.03 1.05-3.82-.27-.39A10.36 10.36 0 1 1 16.03 26.14z"/></svg></div>
                    <div><strong>Admin</strong><small>Hubungi melalui WhatsApp</small></div>
                    <?php if($wa!==''): ?><a href="<?php echo esc_url('https://wa.me/'.$wa); ?>" target="_blank" rel="noopener">Chat</a><?php else: ?><span class="ct-help-disabled">Belum disetel</span><?php endif; ?>
                </div>

                <div class="ct-sidebar-footer">
                    <div class="ct-avatar"><?php echo esc_html($initials); ?></div>
                    <div class="ct-sidebar-user"><strong><?php echo esc_html($user->display_name); ?></strong><small><?php echo esc_html(self::user_access_label($user)); ?></small></div>
                    <a class="ct-sidebar-logout" href="<?php echo esc_url(wp_logout_url(ClaimTrack_DB::get_app_page_url('home'))); ?>" title="Logout" aria-label="Logout"><span class="dashicons dashicons-exit"></span></a>
                </div>
            </aside>
            <button type="button" class="ct-sidebar-backdrop" data-ct-backdrop aria-label="Tutup menu"></button>

            <main class="ct-main">
                <header class="ct-topbar">
                    <div class="ct-topbar-left">
                        <button class="ct-menu-btn" type="button" data-ct-toggle aria-label="Buka menu"><span class="dashicons dashicons-menu-alt"></span></button>
                        <div><h1><?php echo esc_html($pageTitle); ?></h1><p><?php echo esc_html($settings['region_label']); ?> · <?php echo esc_html($settings['department']); ?></p></div>
                    </div>
                    <div class="ct-topbar-right">
                        <div class="ct-date-chip"><span class="dashicons dashicons-calendar-alt"></span><?php echo esc_html(wp_date('j F Y')); ?></div>
                        <button type="button" class="ct-icon-btn" aria-label="Notifikasi"><span class="dashicons dashicons-bell"></span></button>
                        <div class="ct-topbar-profile"><div class="ct-avatar ct-avatar--small"><?php echo esc_html($initials); ?></div><div><strong><?php echo esc_html($user->display_name); ?></strong><small><?php echo esc_html(self::user_access_label($user)); ?></small></div></div>
                        <a class="ct-icon-btn ct-user-logout-btn" href="<?php echo esc_url(wp_logout_url(ClaimTrack_DB::get_app_page_url('home'))); ?>" title="Logout" aria-label="Logout"><span class="dashicons dashicons-exit"></span></a>
                    </div>
                </header>
                <?php self::render_user_export_toolbar($view,$pageTitle); ?>
                <?php self::notice(); ?>
                <?php
                switch($view){
                    case 'home': self::render_home($settings); break;
                    case 'dashboard': self::render_dashboard($settings); break;
                    case 'phase':
                        echo '<div class="ct-content ct-phase-content ct-phase-content--detail">';
                        self::render_phase_dashboard($settings);
                        echo '</div>';
                        break;
                    case 'matrix': self::render_matrix(); break;
                    case 'units': self::render_master('units'); break;
                    case 'programs': self::render_master('programs'); break;
                    case 'providers': self::render_master('providers'); break;
                    case 'import': self::render_import_export(); break;
                    case 'settings': self::render_settings($settings); break;
                    case 'knowledge': self::render_knowledge(); break;
                    case 'achievement': self::render_achievement(); break;
                    case 'not_found': self::render_not_found(); break;
                    default: self::render_additional_menu($view); break;
                }
                ?>
                <footer class="ct-app-footer">Copyright <?php echo esc_html(wp_date('Y')); ?> - Claimtrack.Commercial18 ID &nbsp;|&nbsp; All Right Reserved</footer>
            </main>

            <nav class="ct-mobile-nav ct-mobile-nav--complete" aria-label="Navigasi cepat ClaimTrack">
                <a href="<?php echo esc_url(ClaimTrack_DB::get_app_page_url('home')); ?>" class="<?php echo $view==='home'?'is-active':''; ?>"><span class="ct-mobile-nav-icon"><span class="dashicons dashicons-admin-home"></span></span><em>Home</em></a>
                <a href="<?php echo esc_url(self::app_url()); ?>" class="<?php echo $view==='dashboard'?'is-active':''; ?>"><span class="ct-mobile-nav-icon"><span class="dashicons dashicons-dashboard"></span></span><em>Dashboard</em></a>
                <button type="button" class="<?php echo $view==='phase'?'is-active':''; ?>" data-ct-mobile-phase-open><span class="ct-mobile-nav-icon"><span class="dashicons dashicons-chart-pie"></span></span><em>Fase</em></button>
                <a href="<?php echo esc_url(self::app_url(array('view'=>'matrix','program_id'=>$sub?$sub->id:0))); ?>" class="<?php echo ($view==='matrix' && (int)($_GET['program_id']??0)===(int)($sub?$sub->id:0))?'is-active':''; ?>"><span class="ct-mobile-nav-icon"><span class="dashicons dashicons-networking"></span></span><em>Subrogasi</em></a>
                <a href="<?php echo esc_url(self::app_url(array('view'=>'achievement'))); ?>" class="<?php echo $view==='achievement'?'is-active':''; ?>"><span class="ct-mobile-nav-icon"><span class="dashicons dashicons-chart-line"></span></span><em>Pencapaian</em></a>
                <a href="<?php echo esc_url(self::app_url(array('view'=>'knowledge'))); ?>" class="<?php echo $view==='knowledge'?'is-active':''; ?>"><span class="ct-mobile-nav-icon"><span class="dashicons dashicons-welcome-learn-more"></span></span><em>Info</em></a>
            </nav>
            <div class="ct-mobile-phase-sheet" data-ct-mobile-phase-sheet aria-hidden="true">
                <button type="button" class="ct-mobile-phase-backdrop" data-ct-mobile-phase-close aria-label="Tutup pilihan fase"></button>
                <div class="ct-mobile-phase-card">
                    <div class="ct-mobile-phase-head"><div><small>FASE KLAIM</small><strong>Pilih fase yang ingin dibuka</strong></div><button type="button" data-ct-mobile-phase-close aria-label="Tutup"><span class="dashicons dashicons-no-alt"></span></button></div>
                    <div class="ct-mobile-phase-list">
                    <?php foreach ($programs as $p): if (!in_array($p->code,array('KDP','DOK_LENGKAP','TERBUKU'),true)) continue; ?>
                        <a href="<?php echo esc_url(self::app_url(array('view'=>'phase','program_id'=>$p->id,'year'=>wp_date('Y'),'month'=>wp_date('n')))); ?>"><span class="ct-mobile-phase-icon"><span class="dashicons dashicons-shield-alt"></span></span><div><small><?php echo esc_html($p->phase_label?:'FASE'); ?></small><strong><?php echo esc_html($p->name); ?></strong></div><span class="dashicons dashicons-arrow-right-alt2"></span></a>
                    <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    private static function view_title($view,$programs=array()){
        $titles=array(
            'home'=>'Home',
            'dashboard'=>'Dashboard',
            'matrix'=>'Input Mingguan',
            'units'=>'Unit Kerja',
            'programs'=>'Program',
            'providers'=>'Mitra',
            'import'=>'Import & Export',
            'settings'=>'Pengaturan',
            'knowledge'=>'E-Knowledge',
            'achievement'=>'Pencapaian',
            'admin'=>'SW Admin',
            'not_found'=>'404',
        );
        if($view==='phase'){
            $id=(int)($_GET['program_id']??0);
            foreach($programs as $p){ if((int)$p->id===$id){ return trim(($p->phase_label?$p->phase_label.' - ':'').$p->name); } }
            return 'Fase Klaim';
        }
        $extra = self::additional_menu_items();
        return $titles[$view] ?? ($extra[$view]['label'] ?? 'ClaimTrack');
    }

    private static function program_by_code($programs,$code){ foreach($programs as $p){ if($p->code===$code)return $p; } return null; }

    private static function notice(){
        if(empty($_GET['ct_msg']))return;
        $type=(($_GET['ct_type']??'success')==='error')?'error':'success';
        $message=rawurldecode(wp_unslash($_GET['ct_msg']));
        $event=sanitize_key((string)($_GET['ct_event']??''));
        if(in_array($event,array('added','updated','deleted'),true)){
            $titles=array('added'=>'Data Berhasil Ditambahkan','updated'=>'Perubahan Berhasil Disimpan','deleted'=>'Data Berhasil Dihapus');
            $icons=array('added'=>'plus-alt2','updated'=>'yes-alt','deleted'=>'trash');
            if($type==='error'){$titles[$event]='Proses Tidak Berhasil';$icons[$event]='warning';}
            echo '<div class="ct-action-alert" data-ct-action-alert role="dialog" aria-modal="true" aria-live="polite">';
            echo '<div class="ct-action-alert-backdrop" data-ct-action-alert-close></div>';
            echo '<div class="ct-action-alert-card ct-action-alert-card--'.esc_attr($type).'">';
            echo '<span class="ct-action-alert-icon"><span class="dashicons dashicons-'.esc_attr($icons[$event]).'"></span></span>';
            echo '<h3>'.esc_html($titles[$event]).'</h3><p>'.esc_html($message).'</p>';
            echo '<button type="button" class="ct-btn ct-btn--primary" data-ct-action-alert-close>OK</button>';
            echo '</div></div>';
            return;
        }
        echo '<div class="ct-notice ct-notice--'.esc_attr($type).'">'.esc_html($message).'</div>';
    }

    private static function month_names(){ return array(1=>'Januari',2=>'Februari',3=>'Maret',4=>'April',5=>'Mei',6=>'Juni',7=>'Juli',8=>'Agustus',9=>'September',10=>'Oktober',11=>'November',12=>'Desember'); }
    private static function fmt_total($million){ $b=((float)$million)/1000; return number_format($b,1,',','.').' M'; }
    private static function fmt_provider($million){ $b=((float)$million)/1000; return $b>=1?number_format($b,1,',','.') : number_format((float)$million,0,',','.'); }
    private static function fmt_phase_card($million){ $v=(float)$million; if($v<=0)return '0'; return number_format($v/1000,1,'.',',').' M'; }

    private static function render_dashboard($settings){
        global $wpdb; $t=ClaimTrack_DB::tables();
        $year=max(2000,min(2100,(int)($_GET['year']??wp_date('Y'))));
        $month=max(1,min(12,(int)($_GET['month']??wp_date('n'))));
        $programs=$wpdb->get_results("SELECT * FROM {$t['programs']} WHERE active=1 AND show_dashboard=1 ORDER BY dashboard_order,name");
        $providers=$wpdb->get_results("SELECT * FROM {$t['providers']} WHERE active=1 ORDER BY sort_order,name");
        $months=self::month_names();
        $entryCount=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['entries']} e INNER JOIN {$t['programs']} p ON p.id=e.program_id WHERE e.year=%d AND e.month=%d AND p.active=1 AND p.show_dashboard=1",$year,$month));
        $grand=0.0; $programTotals=array();
        foreach($programs as $p){$v=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount_million),0) FROM {$t['entries']} WHERE program_id=%d AND year=%d AND month=%d",$p->id,$year,$month));$programTotals[$p->id]=$v;$grand+=$v;}
        ?>
        <section class="ct-dashboard ct-content ct-dashboard--phase-style">
            <div class="ct-dashboard-welcome ct-dashboard-welcome--glass">
                <div><span class="ct-eyebrow">RINGKASAN MONITORING</span><h2><?php echo esc_html($settings['dashboard_title']); ?></h2><p>Posisi klaim dan pencapaian periode <?php echo esc_html($months[$month].' '.$year); ?>.</p></div>
                <form method="get" class="ct-period-filter ct-period-filter--dashboard ct-period-filter--phase-glass" data-ct-auto-period>
                    <input type="hidden" name="ct_filter" value="1"><label><span class="dashicons dashicons-calendar-alt"></span><select name="month" aria-label="Filter bulan"><?php foreach($months as $n=>$m):?><option value="<?php echo (int)$n;?>" <?php selected($month,$n);?>><?php echo esc_html($m);?></option><?php endforeach;?></select></label><label><span class="dashicons dashicons-clock"></span><input type="number" name="year" value="<?php echo esc_attr($year);?>" min="2000" max="2100" aria-label="Filter tahun"></label><button class="ct-btn ct-btn--glass-filter" type="submit"><span class="dashicons dashicons-update"></span>Perbarui</button>
                </form>
            </div>

            <?php
            $phaseRecovery = 0.0;
            foreach($programs as $p){
                if(in_array((string)$p->code,array('DOK_LENGKAP','TERBUKU'),true)){
                    $phaseRecovery += (float)($programTotals[$p->id] ?? 0);
                }
            }
            ?>
            <div class="ct-dashboard-phase-cards">
                <?php foreach($programs as $p): $total=$programTotals[$p->id]??0; ?>
                <a class="ct-dashboard-phase-card" href="<?php echo esc_url(self::app_url(array('view'=>'phase','program_id'=>$p->id,'year'=>$year,'month'=>$month))); ?>" style="--ct-dashboard-accent:<?php echo esc_attr($p->color?:'#08739a'); ?>">
                    <div class="ct-dashboard-phase-card-top"><span class="ct-glass-icon"><span class="dashicons dashicons-shield-alt"></span></span><div><small><?php echo esc_html($p->phase_label?:'PROGRAM'); ?></small><strong><?php echo esc_html($p->name); ?></strong></div><span class="dashicons dashicons-arrow-right-alt2 ct-dashboard-phase-arrow"></span></div>
                    <div class="ct-dashboard-phase-value"><span>IDR</span><?php echo esc_html(self::fmt_phase_card($total)); ?></div><small class="ct-provider-period"><?php echo esc_html($months[$month].' '.$year); ?></small>
                </a>
                <?php endforeach; ?>
                <article class="ct-dashboard-phase-card ct-dashboard-phase-card--recovery" aria-label="FASE 2 + FASE 3">
                    <div class="ct-dashboard-phase-card-top"><span class="ct-glass-icon"><span class="dashicons dashicons-chart-area"></span></span><div><small>FASE 2 + FASE 3</small><strong>Potensi Recovery Klaim</strong></div></div><div class="ct-dashboard-phase-value"><span>IDR</span><?php echo esc_html(self::fmt_phase_card($phaseRecovery)); ?></div><small class="ct-provider-period"><?php echo esc_html($months[$month].' '.$year); ?></small></article>
            </div>

            <div class="ct-dashboard-grid"><?php self::render_position_table($year,$month); ?><?php self::render_chart($year); ?></div>
        </section>
        <?php if(isset($_GET['ct_filter']) && $entryCount===0): ?>
        <div class="ct-empty-modal" data-ct-empty-modal role="dialog" aria-modal="true" aria-label="Data kosong"><div class="ct-empty-modal-backdrop" data-ct-empty-close></div><div class="ct-empty-modal-card"><span class="ct-empty-modal-icon"><span class="dashicons dashicons-database-remove"></span></span><h3>Data Kosong</h3><p>Belum ada data ClaimTrack untuk periode <strong><?php echo esc_html($months[$month].' '.$year); ?></strong>.</p><button type="button" class="ct-btn ct-btn--primary" data-ct-empty-close>OK, Mengerti</button></div></div>
        <?php endif; ?>
        <?php
    }

    private static function render_home($settings){
        ?>
        <section class="ct-home ct-content">
            <div class="ct-home-welcome">
                <div>
                    <span class="ct-eyebrow">HOME KARYAWAN</span>
                    <h2>Berita & Update ClaimTrack</h2>
                    <p>Informasi internal, pengumuman, dan pembaruan operasional ClaimTrack untuk seluruh karyawan.</p>
                </div>
                <div class="ct-home-badge"><span class="dashicons dashicons-megaphone"></span><strong>Informasi Internal</strong><small>Dibaca oleh seluruh user ClaimTrack</small></div>
            </div>
            <?php self::render_employee_news(12); ?>
        </section>
        <?php
    }

    private static function render_employee_news($limit=12){
        $limit=max(1,min(30,(int)$limit));
        $selected=max(0,(int)($_GET['news_id']??0));
        $selectedPost=$selected?get_post($selected):null;
        if(!($selectedPost instanceof WP_Post)||$selectedPost->post_type!=='ct_news'||$selectedPost->post_status!=='publish'){$selectedPost=null;}
        $items=get_posts(array('post_type'=>'ct_news','post_status'=>'publish','posts_per_page'=>$limit,'meta_key'=>'_claimtrack_news_featured','orderby'=>array('meta_value_num'=>'DESC','date'=>'DESC')));
        ?>
        <section class="ct-employee-news ct-employee-news--home">
            <div class="ct-news-head"><div><span class="ct-eyebrow">INFORMASI KARYAWAN</span><h3>Berita & Update ClaimTrack</h3><p>Pilih berita untuk membaca isi lengkap dan ikut berdiskusi melalui komentar.</p></div></div>
            <?php if($selectedPost):
                $cover=get_the_post_thumbnail_url($selectedPost,'large');
                $comments=get_comments(array('post_id'=>$selectedPost->ID,'status'=>'approve','type'=>'comment','order'=>'ASC','orderby'=>'comment_date_gmt'));
                ?>
                <article class="ct-news-reader" id="ct-news-reader">
                    <div class="ct-news-reader-cover" <?php echo $cover?'style="background-image:url('.esc_url($cover).')"':'';?>></div>
                    <div class="ct-news-reader-main">
                        <div class="ct-news-reader-meta"><?php echo esc_html(wp_date('j F Y',strtotime($selectedPost->post_date)));?> · <?php echo esc_html(number_format_i18n(count($comments)));?> komentar</div>
                        <h2><?php echo esc_html($selectedPost->post_title);?></h2>
                        <div class="ct-news-reader-content"><?php echo wp_kses_post(wpautop($selectedPost->post_content));?></div>
                        <a class="ct-btn ct-btn--light" href="<?php echo esc_url(self::app_url(array('view'=>'home')));?>">Tutup Berita</a>
                    </div>
                </article>

                <section class="ct-news-comments" id="ct-news-comments">
                    <div class="ct-news-comments-head"><div><span class="dashicons dashicons-admin-comments"></span><div><h4>Komentar Karyawan</h4><p><?php echo esc_html(number_format_i18n(count($comments)));?> komentar pada berita ini</p></div></div></div>
                    <div class="ct-news-comment-list">
                        <?php if($comments): foreach($comments as $comment):
                            $author=trim((string)get_comment_author($comment));
                            $author=$author!==''?$author:'Karyawan';
                            $parts=preg_split('/\s+/',trim($author));
                            $initials=strtoupper(substr($parts[0]??'K',0,1).substr($parts[count($parts)-1]??'',0,1));
                            ?>
                            <article class="ct-news-comment">
                                <div class="ct-news-comment-avatar"><?php echo esc_html($initials);?></div>
                                <div class="ct-news-comment-body"><div class="ct-news-comment-meta"><strong><?php echo esc_html($author);?></strong><span><?php echo esc_html(wp_date('j M Y, H:i',strtotime($comment->comment_date)));?></span></div><p><?php echo esc_html($comment->comment_content);?></p></div>
                            </article>
                        <?php endforeach; else: ?>
                            <div class="ct-news-comment-empty"><span class="dashicons dashicons-format-chat"></span><p>Belum ada komentar. Jadilah yang pertama memberikan tanggapan.</p></div>
                        <?php endif; ?>
                    </div>
                    <form method="post" class="ct-news-comment-form">
                        <?php wp_nonce_field('claimtrack_news_comment','claimtrack_comment_nonce'); ?>
                        <input type="hidden" name="claimtrack_action" value="news_comment_add">
                        <input type="hidden" name="news_id" value="<?php echo (int)$selectedPost->ID;?>">
                        <label for="ct-comment-content">Tulis komentar</label>
                        <textarea id="ct-comment-content" name="comment_content" rows="4" maxlength="2000" placeholder="Tulis tanggapan Anda..." required></textarea>
                        <div class="ct-news-comment-actions"><small>Maksimal 2.000 karakter. Komentar tersimpan di sistem komentar ClaimTrack.</small><button type="submit" class="ct-btn ct-btn--primary"><span class="dashicons dashicons-admin-comments"></span>Kirim Komentar</button></div>
                    </form>
                </section>
            <?php endif;?>

            <?php if($items): ?>
                <div class="ct-news-grid">
                    <?php foreach($items as $item):
                        $thumb=get_the_post_thumbnail_url($item,'medium_large');
                        $commentCount=(int)get_comments_number($item->ID);
                        ?>
                        <article class="ct-news-card"><a href="<?php echo esc_url(add_query_arg('news_id',$item->ID,self::app_url(array('view'=>'home'))));?>#ct-news-reader"><div class="ct-news-cover" <?php echo $thumb?'style="background-image:url('.esc_url($thumb).')"':'';?>><span><?php echo get_post_meta($item->ID,'_claimtrack_news_featured',true)==='1'?'BERITA UTAMA':'UPDATE';?></span></div><div class="ct-news-body"><small><?php echo esc_html(wp_date('j M Y',strtotime($item->post_date)));?></small><h4><?php echo esc_html($item->post_title);?></h4><p><?php echo esc_html(wp_trim_words(wp_strip_all_tags($item->post_excerpt?:$item->post_content),16,'…'));?></p><div class="ct-news-card-foot"><strong>Baca selengkapnya <span>→</span></strong><span class="ct-news-comment-count"><span class="dashicons dashicons-admin-comments"></span><?php echo esc_html(number_format_i18n($commentCount));?></span></div></div></a></article>
                    <?php endforeach;?>
                </div>
            <?php else: ?>
                <div class="ct-news-empty"><span class="dashicons dashicons-megaphone"></span><h4>Belum ada berita</h4><p>Berita yang diterbitkan Admin akan tampil di halaman Home ini.</p></div>
            <?php endif;?>
        </section>
        <?php
    }

    private static function render_phase_dashboard($settings){
        global $wpdb; $t=ClaimTrack_DB::tables();
        $programId=(int)($_GET['program_id']??0);
        if(!$programId){ $programId=(int)$wpdb->get_var("SELECT id FROM {$t['programs']} WHERE code='KDP' LIMIT 1"); }
        $program=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['programs']} WHERE id=%d AND active=1 LIMIT 1",$programId));
        if(!$program){ status_header(404); nocache_headers(); self::render_not_found(); return; }
        // The three operational phase pages use the supplied reference-dashboard
        // layout. Keep the older renderer below for any future non-reference
        // monitoring program.
        if(in_array((string)$program->code,array('KDP','DOK_LENGKAP','TERBUKU'),true)){
            self::render_reference_phase_dashboard($settings,$program);
            return;
        }
        self::render_kdp_phase_dashboard($settings,$programId);
    }

    private static function render_kdp_phase_dashboard($settings,$programId){
        global $wpdb; $t=ClaimTrack_DB::tables();
        $program=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['programs']} WHERE id=%d AND active=1",$programId));
        if(!$program){ status_header(404); nocache_headers(); self::render_not_found(); return; }

        $year=max(2000,min(2100,(int)($_GET['year']??wp_date('Y'))));
        $month=max(1,min(12,(int)($_GET['month']??wp_date('n'))));
        $months=self::month_names();
        $providers=$wpdb->get_results("SELECT * FROM {$t['providers']} WHERE active=1 ORDER BY sort_order,name");
        $units=$wpdb->get_results("SELECT * FROM {$t['units']} WHERE active=1 ORDER BY sort_order,name");

        $providerLabel=function($provider){
            if($provider->code==='BSM_A3M'){ return 'BRINS - A3M'; }
            if($provider->code==='BRINS_FLPP'){ return 'BRINS - FLPP'; }
            return $provider->name;
        };

        $entryCount=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['entries']} WHERE program_id=%d AND year=%d AND month=%d",$programId,$year,$month));
        $providerTotals=array(); $grandTotal=0.0;
        foreach($providers as $pr){
            $v=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount_million),0) FROM {$t['entries']} WHERE program_id=%d AND provider_id=%d AND year=%d AND month=%d",$programId,$pr->id,$year,$month));
            $providerTotals[$pr->id]=$v; $grandTotal+=$v;
        }

        $matrix=array(); $unitTotals=array();
        foreach($units as $u){
            $unitTotals[$u->id]=0.0;
            foreach($providers as $pr){
                $v=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount_million),0) FROM {$t['entries']} WHERE unit_id=%d AND program_id=%d AND provider_id=%d AND year=%d AND month=%d",$u->id,$programId,$pr->id,$year,$month));
                $matrix[$u->id][$pr->id]=$v;
                $unitTotals[$u->id]+=$v;
            }
        }

        $providerChart=array();
        foreach($providers as $pr){
            $providerChart[]=array(
                'id'=>'provider-'.(int)$pr->id,
                'name'=>$providerLabel($pr),
                'value'=>(float)$providerTotals[$pr->id],
            );
        }
        $unitChart=array();
        foreach($units as $u){
            $unitChart[]=array(
                'id'=>'unit-'.(int)$u->id,
                'unit_id'=>(int)$u->id,
                'name'=>$u->name,
                'value'=>(float)$unitTotals[$u->id],
            );
        }
        ?>
        <section class="ct-phase-hero ct-kdp-hero ct-kdp-reference-hero ct-htmlref-phase-hero">
            <div class="ct-htmlref-banner">
                <div class="ct-kdp-title-row ct-htmlref-title-row">
                    <div class="ct-phase-title ct-kdp-title">
                        <strong><?php echo esc_html($program->phase_label ?: 'FASE 1'); ?></strong>
                        <span>- <?php echo esc_html($program->name ?: 'KDP'); ?></span>
                    </div>
                    <div class="ct-htmlref-header-info">
                        <span><?php echo esc_html(wp_date('l, j F Y')); ?></span>
                        <span><?php echo esc_html(wp_get_current_user()->display_name); ?></span>
                        <span><?php echo esc_html($settings['department']); ?></span>
                    </div>
                </div>
                <form method="get" class="ct-period-filter ct-period-filter--phase-glass ct-htmlref-period-filter" data-ct-auto-period>
                    <input type="hidden" name="ct_filter" value="1">
                    <?php if(self::$admin_portal): $adminPhaseSection=$program->code==='DOK_LENGKAP'?'phase2':($program->code==='TERBUKU'?'phase3':'phase1'); ?><input type="hidden" name="section" value="<?php echo esc_attr($adminPhaseSection); ?>"><?php endif; ?>
                    <label><span class="dashicons dashicons-calendar-alt"></span><select name="month" aria-label="Filter bulan"><?php foreach($months as $n=>$m):?><option value="<?php echo (int)$n;?>" <?php selected($month,$n);?>><?php echo esc_html($m);?></option><?php endforeach;?></select></label>
                    <label><span class="dashicons dashicons-clock"></span><input type="number" name="year" value="<?php echo esc_attr($year);?>" min="2000" max="2100" aria-label="Filter tahun"></label>
                    <button class="ct-btn ct-btn--glass-filter" type="submit"><span class="dashicons dashicons-update"></span>Perbarui</button>
                </form>
            </div>

            <div class="ct-provider-cards ct-kdp-provider-cards ct-htmlref-kpi-grid">
                <?php foreach($providers as $pr): ?>
                    <article class="ct-provider-card ct-kdp-provider-card ct-htmlref-kpi-card">
                        <div class="ct-provider-name"><?php echo esc_html($providerLabel($pr)); ?></div>
                        <div class="ct-provider-value"><span>IDR</span> <?php echo esc_html(self::fmt_phase_card($providerTotals[$pr->id])); ?></div>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>

        <section class="ct-kdp-reference-body ct-kdp-reference-body--v1215">
            <div class="ct-kdp-top-grid">
                <div class="ct-kdp-top-block ct-kdp-reference-table-wrap">
                    <div class="ct-kdp-section-title">POSISI <?php echo esc_html(strtoupper($program->name)); ?> (<?php echo esc_html($program->code==='TERBUKU'?'KLAIM TERBUKU':'KLAIM DALAM PROSES'); ?>)</div>
                    <article class="ct-panel ct-kdp-table-panel ct-kdp-reference-table-panel">
                        <div class="ct-table-scroll ct-kdp-table-scroll">
                            <table class="ct-table ct-phase-table ct-kdp-table">
                            <colgroup><col class="ct-col-no"><col class="ct-col-unit"><col class="ct-col-num"><col class="ct-col-num"><col class="ct-col-num"><col class="ct-col-num"><col class="ct-col-total"></colgroup>
                                <thead>
                                    <tr>
                                        <th rowspan="2">No</th>
                                        <th rowspan="2">Unit Kerja</th>
                                        <th colspan="<?php echo (int)count($providers); ?>"><?php echo esc_html(strtoupper($program->name)); ?></th>
                                        <th rowspan="2">Total <?php echo esc_html($program->name); ?><br><?php echo esc_html($months[$month].' '.$year); ?></th>
                                    </tr>
                                    <tr>
                                        <?php foreach($providers as $pr): ?><th><?php echo esc_html($providerLabel($pr)); ?></th><?php endforeach; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($units as $i=>$u): ?>
                                        <tr data-unit-row="<?php echo (int)$u->id; ?>">
                                            <td><?php echo (int)($i+1); ?></td>
                                            <td><?php echo esc_html($u->name); ?></td>
                                            <?php foreach($providers as $pr): ?><td><?php echo esc_html(number_format($matrix[$u->id][$pr->id],0,',','.')); ?></td><?php endforeach; ?>
                                            <td class="ct-row-total"><?php echo esc_html(number_format($unitTotals[$u->id],0,',','.')); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th colspan="2">Total</th>
                                        <?php foreach($providers as $pr): ?><th><?php echo esc_html(number_format($providerTotals[$pr->id],0,',','.')); ?></th><?php endforeach; ?>
                                        <th><?php echo esc_html(number_format($grandTotal,0,',','.')); ?></th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </article>
                </div>

                <div class="ct-kdp-top-block ct-kdp-reference-chart-block">
                    <div class="ct-kdp-section-title">PERSENTASE <?php echo esc_html(strtoupper($program->name)); ?> PER ASURADUR</div>
                    <article class="ct-panel ct-kdp-reference-donut-panel" data-ct-static-donut data-donut-kind="provider" data-total-label="<?php echo esc_attr('Total '.$program->name); ?>" data-label-count="4" data-items='<?php echo esc_attr(wp_json_encode($providerChart)); ?>'>
                        <div class="ct-kdp-reference-donut" data-ct-static-ring>
                            <div class="ct-kdp-reference-hole"><span class="dashicons dashicons-shield-alt"></span></div>
                            <div class="ct-kdp-reference-labels" data-ct-static-labels></div>
                        </div>
                        <div class="ct-kdp-chart-unit-grid">
                            <?php foreach($providers as $pr): ?>
                                <button type="button" class="ct-kdp-chart-unit-button" data-ct-provider-focus="<?php echo (int)$pr->id; ?>" aria-pressed="false"><?php echo esc_html($providerLabel($pr)); ?></button>
                            <?php endforeach; ?>
                            <span class="ct-kdp-chart-unit-hint">Pilih Salah Satu</span>
                        </div>
                    </article>
                </div>

                <div class="ct-kdp-top-block ct-kdp-reference-chart-block">
                    <div class="ct-kdp-section-title">PERSENTASE <?php echo esc_html(strtoupper($program->name)); ?> PER UKER</div>
                    <article class="ct-panel ct-kdp-reference-donut-panel" data-ct-static-donut data-donut-kind="unit" data-total-label="<?php echo esc_attr('Total '.$program->name); ?>" data-label-count="4" data-items='<?php echo esc_attr(wp_json_encode($unitChart)); ?>'>
                        <div class="ct-kdp-reference-donut" data-ct-static-ring>
                            <div class="ct-kdp-reference-hole"><span class="dashicons dashicons-building"></span></div>
                            <div class="ct-kdp-reference-labels" data-ct-static-labels></div>
                        </div>
                        <div class="ct-kdp-chart-unit-grid">
                            <?php foreach($units as $u): ?>
                                <button type="button" class="ct-kdp-chart-unit-button" data-ct-unit-focus="<?php echo (int)$u->id; ?>"><?php echo esc_html($u->name); ?></button>
                            <?php endforeach; ?>
                            <span class="ct-kdp-chart-unit-hint">Pilih Salah Satu</span>
                        </div>
                    </article>
                </div>
            </div>

            <div class="ct-kdp-bottom-grid">
                <div class="ct-kdp-bottom-block ct-kdp-data-block">
                    <article class="ct-panel ct-kdp-nominative-result-panel">
                        <div class="ct-kdp-nominative-result" id="ct-kdp-nominative-result">
                            <strong>Data Debitur <?php echo esc_html($program->name); ?></strong>
                            <table>
                                <thead>
                                    <tr>
                                        <th>Unit Kerja</th>
                                        <th>Nama Debitur</th>
                                        <th>Asuradur</th>
                                        <th>Nilai</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                $debiturRows = $wpdb->get_results($wpdb->prepare("SELECT d.*, u.name unit_name, v.name provider_name FROM {$t['debitur']} d LEFT JOIN {$t['units']} u ON u.id=d.unit_id LEFT JOIN {$t['providers']} v ON v.id=d.provider_id WHERE d.program_id=%d ORDER BY d.id ASC", $programId));
                                if($debiturRows): foreach($debiturRows as $deb): ?>
                                    <tr data-kdp-unit="<?php echo esc_attr($deb->unit_name); ?>">
                                        <td><?php echo esc_html($deb->unit_name); ?></td>
                                        <td><?php echo esc_html($deb->nama_nasabah); ?></td>
                                        <td><?php echo esc_html($deb->provider_name); ?></td>
                                        <td><?php echo esc_html(number_format(((float)$deb->amount_million)*1000000,0,',','.')); ?></td>
                                        <td><?php echo esc_html($deb->status_klaim); ?></td>
                                    </tr>
                                <?php endforeach; else: ?>
                                    <tr><td colspan="5">Belum ada data debitur. Silakan input melalui SW Admin → Data Debitur.</td></tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </article>
                </div>

                <div class="ct-kdp-bottom-block ct-kdp-nominative-block">
                    <div class="ct-kdp-section-title">DATA NOMINATIF DEBITUR <?php echo esc_html(strtoupper($program->name)); ?> PER UKER</div>
                    <article class="ct-panel ct-kdp-nominative-panel">
                        <div class="ct-kdp-nominative-grid">
                            <?php foreach($units as $u): ?>
                                <button type="button" class="ct-kdp-nominative-button" data-kdp-unit-name="<?php echo esc_attr($u->name); ?>" data-ct-unit-focus="<?php echo (int)$u->id; ?>"><?php echo esc_html($u->name); ?></button>
                            <?php endforeach; ?>
                            <span class="ct-kdp-nominative-hint">Pilih Salah Satu</span>
                        </div>
                    </article>
                </div>
            </div>
        </section>
        <?php if(isset($_GET['ct_filter']) && $entryCount===0): ?>
        <div class="ct-empty-modal" data-ct-empty-modal role="dialog" aria-modal="true" aria-label="Data kosong">
            <div class="ct-empty-modal-backdrop" data-ct-empty-close></div>
            <div class="ct-empty-modal-card">
                <span class="ct-empty-modal-icon"><span class="dashicons dashicons-database-remove"></span></span>
                <h3>Data Kosong</h3>
                <p>Belum ada data <strong><?php echo esc_html($program->phase_label.' - '.$program->name); ?></strong> untuk periode <strong><?php echo esc_html($months[$month].' '.$year); ?></strong>.</p>
                <button type="button" class="ct-btn ct-btn--primary" data-ct-empty-close>OK, Mengerti</button>
            </div>
        </div>
        <?php endif; ?>
        <?php
    }

    private static function render_phase_overview($settings){
        global $wpdb; $t=ClaimTrack_DB::tables();
        $year=max(2000,min(2100,(int)($_GET['year']??wp_date('Y'))));
        $month=max(1,min(12,(int)($_GET['month']??wp_date('n'))));
        $months=self::month_names();
        $programs=$wpdb->get_results("SELECT * FROM {$t['programs']} WHERE active=1 AND code IN ('KDP','DOK_LENGKAP','TERBUKU') ORDER BY dashboard_order,name");
        $units=$wpdb->get_results("SELECT * FROM {$t['units']} WHERE active=1 ORDER BY sort_order,name");
        if(!$programs){ status_header(404); nocache_headers(); self::render_not_found(); return; }

        $programTotals=array(); $grandTotal=0.0; $matrix=array(); $unitTotals=array();
        foreach($programs as $program){
            $v=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount_million),0) FROM {$t['entries']} WHERE program_id=%d AND year=%d AND month=%d",$program->id,$year,$month));
            $programTotals[$program->id]=$v; $grandTotal+=$v;
        }
        foreach($units as $u){
            $unitTotals[$u->id]=0.0;
            foreach($programs as $program){
                $v=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount_million),0) FROM {$t['entries']} WHERE unit_id=%d AND program_id=%d AND year=%d AND month=%d",$u->id,$program->id,$year,$month));
                $matrix[$u->id][$program->id]=$v; $unitTotals[$u->id]+=$v;
            }
        }
        $programChart=array(); foreach($programs as $program){$programChart[]=array('id'=>'program-'.(int)$program->id,'name'=>trim(($program->phase_label?$program->phase_label.' - ':'').$program->name),'value'=>(float)$programTotals[$program->id]);}
        $unitChart=array(); foreach($units as $u){$unitChart[]=array('id'=>'unit-'.(int)$u->id,'unit_id'=>(int)$u->id,'name'=>$u->name,'value'=>(float)$unitTotals[$u->id]);}
        ?>
        <section class="ct-phase-hero ct-kdp-hero ct-kdp-reference-hero ct-phase-overview-hero">
            <div class="ct-kdp-title-row">
                <div class="ct-phase-title ct-kdp-title"><strong>FASE KLAIM</strong><span>- <?php echo esc_html($settings['region_label']); ?></span></div>
                <div class="ct-kdp-meta">
                    <span><?php echo esc_html(wp_date('l, j F Y')); ?></span>
                    <span><?php echo esc_html(wp_get_current_user()->display_name); ?></span>
                    <span><?php echo esc_html($settings['department']); ?></span>
                </div>
            </div>
            <div class="ct-provider-cards ct-kdp-provider-cards ct-phase-overview-cards">
                <?php foreach($programs as $program): ?>
                    <a class="ct-provider-card ct-kdp-provider-card ct-phase-overview-card" href="<?php echo esc_url(self::app_url(array('view'=>'phase','program_id'=>$program->id,'year'=>$year,'month'=>$month))); ?>">
                        <div class="ct-provider-name"><?php echo esc_html(trim(($program->phase_label?$program->phase_label.' - ':'').$program->name)); ?></div>
                        <div class="ct-provider-value"><span>IDR</span> <?php echo esc_html(self::fmt_phase_card($programTotals[$program->id])); ?></div>
                    </a>
                <?php endforeach; ?>
                <article class="ct-provider-card ct-kdp-provider-card ct-phase-overview-card ct-phase-overview-total">
                    <div class="ct-provider-name">TOTAL KLAIM</div>
                    <div class="ct-provider-value"><span>IDR</span> <?php echo esc_html(self::fmt_phase_card($grandTotal)); ?></div>
                </article>
            </div>
        </section>
        <section class="ct-kdp-reference-body">
            <div class="ct-kdp-reference-table-wrap">
                <div class="ct-kdp-section-title">POSISI FASE KLAIM</div>
                <article class="ct-panel ct-kdp-table-panel ct-kdp-reference-table-panel">
                    <div class="ct-table-scroll ct-kdp-table-scroll"><table class="ct-table ct-phase-table ct-kdp-table">
                        <thead><tr><th>No</th><th>Unit Kerja</th><?php foreach($programs as $program):?><th><?php echo esc_html($program->phase_label);?><br><?php echo esc_html($program->name);?></th><?php endforeach;?><th>Total Klaim<br><?php echo esc_html($months[$month].' '.$year);?></th></tr></thead>
                        <tbody><?php foreach($units as $i=>$u):?><tr data-unit-row="<?php echo (int)$u->id;?>"><td><?php echo (int)($i+1);?></td><td><?php echo esc_html($u->name);?></td><?php foreach($programs as $program):?><td><?php echo esc_html(number_format($matrix[$u->id][$program->id],0,',','.'));?></td><?php endforeach;?><td class="ct-row-total"><?php echo esc_html(number_format($unitTotals[$u->id],0,',','.'));?></td></tr><?php endforeach;?></tbody>
                        <tfoot><tr><th colspan="2">Total</th><?php foreach($programs as $program):?><th><?php echo esc_html(number_format($programTotals[$program->id],0,',','.'));?></th><?php endforeach;?><th><?php echo esc_html(number_format($grandTotal,0,',','.'));?></th></tr></tfoot>
                    </table></div>
                </article>
            </div>
            <div class="ct-kdp-reference-right">
                <div class="ct-kdp-reference-charts">
                    <div class="ct-kdp-reference-chart-block">
                        <div class="ct-kdp-section-title">PERSENTASE KLAIM PER FASE</div>
                        <article class="ct-panel ct-kdp-reference-donut-panel" data-ct-static-donut data-donut-kind="phase" data-total-label="Total Klaim" data-label-count="4" data-items='<?php echo esc_attr(wp_json_encode($programChart)); ?>'>
                            <div class="ct-kdp-reference-donut" data-ct-static-ring><div class="ct-kdp-reference-hole"><span class="dashicons dashicons-chart-pie"></span></div><div class="ct-kdp-reference-labels" data-ct-static-labels></div></div>
                        </article>
                    </div>
                    <div class="ct-kdp-reference-chart-block">
                        <div class="ct-kdp-section-title">PERSENTASE KLAIM PER UKER</div>
                        <article class="ct-panel ct-kdp-reference-donut-panel" data-ct-static-donut data-donut-kind="unit" data-total-label="Total Klaim" data-label-count="4" data-items='<?php echo esc_attr(wp_json_encode($unitChart)); ?>'>
                            <div class="ct-kdp-reference-donut" data-ct-static-ring><div class="ct-kdp-reference-hole"><span class="dashicons dashicons-building"></span></div><div class="ct-kdp-reference-labels" data-ct-static-labels></div></div>
                        </article>
                    </div>
                </div>
                <div class="ct-kdp-nominative-block"><div class="ct-kdp-section-title">DAFTAR NOMINATIF DEBITUR PER UKER</div><article class="ct-panel ct-kdp-nominative-panel"><div class="ct-kdp-nominative-grid">
                    <?php foreach($units as $u):?><button type="button" class="ct-kdp-nominative-button" data-ct-unit-focus="<?php echo (int)$u->id;?>"><?php echo esc_html($u->name);?></button><?php endforeach;?><span class="ct-kdp-nominative-hint">Pilih Salah Satu</span>
                </div></article></div>
            </div>
        </section>
        <?php
    }

    private static function render_reference_phase_dashboard($settings,$program){
        global $wpdb; $t=ClaimTrack_DB::tables();
        $code=(string)$program->code;
        $year=max(2000,min(2100,(int)($_GET['year']??wp_date('Y'))));
        $month=max(1,min(12,(int)($_GET['month']??wp_date('n'))));
        $months=self::month_names();
        $providers=$wpdb->get_results("SELECT * FROM {$t['providers']} WHERE active=1 ORDER BY sort_order,name");
        $units=$wpdb->get_results("SELECT * FROM {$t['units']} WHERE active=1 ORDER BY sort_order,name");
        $providerLabel=function($provider){
            if($provider->code==='BSM_A3M'){return 'BRINS - A3M';}
            if($provider->code==='BRINS_FLPP'){return 'BRINS - FLPP';}
            return $provider->name;
        };
        $display=array(
            'KDP'=>array('title'=>'Fase 1 Berkas Belum Lengkap','position'=>'POSISI BERKAS BELUM LENGKAP','nominal'=>'DAFTAR NOMINATIF DEBITUR KDP - BERKAS BELUM LENGKAP'),
            'DOK_LENGKAP'=>array('title'=>'Fase 2 Berkas Lengkap','position'=>'POSISI BERKAS LENGKAP','nominal'=>'DAFTAR NOMINATIF DEBITUR KDP - BERKAS LENGKAP'),
            'TERBUKU'=>array('title'=>'Fase 3 Klaim Terbuku','position'=>'POSISI KLAIM TERBUKU BULAN BERJALAN','nominal'=>'DATA NOMINATIF KLAIM TERBUKU'),
        );
        $labels=$display[$code]??$display['KDP'];
        $areaHead=function($unit){
            $name=strtoupper((string)$unit->name);
            if(in_array($name,array('MERAUKE','SENTANI','ABEPURA','JAYAPURA'),true)){return 'Area Head 1';}
            if(in_array($name,array('SERUI','WAMENA','NABIRE','TIMIKA'),true)){return 'Area Head 2';}
            return 'Area Head 3';
        };
        $money=function($value){
            $value=(float)$value;
            if($value>=1000){return number_format($value/1000,1,',','.').' M';}
            return number_format($value,0,',','.').' Jt';
        };
        $number=function($value){return number_format((float)$value,0,',','.');};
        $matrix=array(); $providerTotals=array(); $unitTotals=array(); $areaTotals=array(); $grandTotal=0.0;
        foreach($providers as $provider){$providerTotals[(int)$provider->id]=0.0;}
        foreach($units as $unit){
            $unitTotals[(int)$unit->id]=0.0; $head=$areaHead($unit); $areaTotals[$head]=$areaTotals[$head]??0.0;
            foreach($providers as $provider){
                $weeks=array();
                for($week=1;$week<=4;$week++){
                    $weeks[$week]=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount_million),0) FROM {$t['entries']} WHERE unit_id=%d AND program_id=%d AND provider_id=%d AND year=%d AND month=%d AND week=%d",$unit->id,$program->id,$provider->id,$year,$month,$week));
                }
                $matrix[(int)$unit->id][(int)$provider->id]=$weeks;
                $subtotal=array_sum($weeks); $unitTotals[(int)$unit->id]+=$subtotal; $providerTotals[(int)$provider->id]+=$subtotal;
            }
            $areaTotals[$head]+=$unitTotals[(int)$unit->id]; $grandTotal+=$unitTotals[(int)$unit->id];
        }
        $grouped=array();
        foreach($units as $unit){$grouped[$areaHead($unit)][]=$unit;}
        $groupOrder=array('Area Head 1','Area Head 2','Area Head 3');
        $shareItems=function($items,$total) use ($number){
            $out=array(); foreach($items as $name=>$value){$out[]=array('name'=>$name,'value'=>(float)$value,'pct'=>$total>0?((float)$value/(float)$total*100):0);}
            return $out;
        };
        $providerShares=array(); foreach($providers as $provider){$providerShares[$providerLabel($provider)]=$providerTotals[(int)$provider->id];}
        $providerItems=$shareItems($providerShares,$grandTotal);
        $areaItems=$shareItems($areaTotals,$grandTotal);
        $verificationItems=$code==='DOK_LENGKAP'?array('Sukses'=>$grandTotal*.7181,'Proses'=>$grandTotal*.2819):$providerShares;
        $verificationItems=$shareItems($verificationItems,$grandTotal);
        $donut=function($title,$items) use ($number){
            $colors=array('#18a957','#218bd0','#f0b52f','#7650b8','#ef6c45'); $cursor=0; $stops=array();
            foreach($items as $i=>$item){$next=$cursor+(float)$item['pct'];$stops[]=esc_attr($colors[$i%count($colors)]).' '.rtrim(rtrim(number_format($cursor,3,'.',''),'0'),'.').'% '.rtrim(rtrim(number_format($next,3,'.',''),'0'),'.').'%';$cursor=$next;}
            if(!$stops){$stops[]='#dbe3ea 0 100%';}
            echo '<article class="ct-ref-chart-card"><h3>'.esc_html($title).'</h3><div class="ct-ref-donut" style="background:conic-gradient('.implode(',',$stops).')"><div><small>TOTAL (JUTA)</small><strong>'.esc_html($number(array_sum(array_column($items,'value')))).'</strong></div></div><ul class="ct-ref-legend">';
            foreach($items as $i=>$item){echo '<li><i style="background:'.esc_attr($colors[$i%count($colors)]).'"></i><span>'.esc_html($item['name']).'</span><b>'.esc_html(number_format((float)$item['pct'],2,',','.')).'%</b></li>';}
            echo '</ul></article>';
        };
        $debitur=$wpdb->get_results($wpdb->prepare("SELECT d.*,u.name unit_name,p.name provider_name FROM {$t['debitur']} d LEFT JOIN {$t['units']} u ON u.id=d.unit_id LEFT JOIN {$t['providers']} p ON p.id=d.provider_id WHERE d.program_id=%d ORDER BY d.id ASC",$program->id));
        $isTerbuku=$code==='TERBUKU';
        $periodForm='<form class="ct-ref-period" method="get"><input type="hidden" name="view" value="phase"><input type="hidden" name="program_id" value="'.(int)$program->id.'"><select name="month" aria-label="Bulan">';
        foreach($months as $n=>$monthName){$periodForm.='<option value="'.(int)$n.'"'.selected($month,$n,false).'>'.esc_html($monthName).'</option>';}
        $periodForm.='</select><input type="number" name="year" value="'.esc_attr($year).'" min="2000" max="2100" aria-label="Tahun"><button type="submit">Perbarui</button></form>';
        ?>
        <section class="ct-ref-phase ct-ref-phase--<?php echo esc_attr($code==='TERBUKU'?'3':($code==='DOK_LENGKAP'?'2':'1')); ?>">
            <div class="ct-ref-kpi-grid">
                <?php foreach($providers as $provider): ?><article class="ct-ref-kpi"><span><?php echo esc_html($providerLabel($provider)); ?></span><strong><small>IDR</small> <?php echo esc_html($money($providerTotals[(int)$provider->id])); ?></strong></article><?php endforeach; ?>
                <?php if($isTerbuku): ?><article class="ct-ref-kpi ct-ref-kpi--total"><span>Total</span><strong><small>IDR</small> <?php echo esc_html($money($grandTotal)); ?></strong></article><?php endif; ?>
            </div>
            <div class="ct-ref-phase-head"><h1><?php echo esc_html($labels['title']); ?></h1><?php echo $periodForm; ?></div>
            <?php if($isTerbuku): ?>
                <div class="ct-ref-panel ct-ref-position-panel"><h2><?php echo esc_html($labels['position']); ?></h2><div class="ct-ref-table-wrap"><table class="ct-ref-table ct-ref-table--terbuku"><thead><tr><th rowspan="2">No</th><th rowspan="2">Unit Kerja</th><?php foreach($providers as $provider): ?><th colspan="4"><?php echo esc_html($providerLabel($provider)); ?></th><?php endforeach; ?><th rowspan="2">Total</th></tr><tr><?php foreach($providers as $provider): ?><th>I</th><th>II</th><th>III</th><th>IV</th><?php endforeach; ?></tr></thead><tbody>
                <?php $no=1; foreach($groupOrder as $head): if(empty($grouped[$head])){continue;} ?><tr class="ct-ref-group"><th colspan="2"><?php echo esc_html($head); ?></th><?php foreach($providers as $provider): ?><th><?php echo esc_html($number(array_sum(array_map(function($unit) use ($matrix,$provider){return array_sum($matrix[(int)$unit->id][(int)$provider->id]);},$grouped[$head])))); ?></th><th></th><th></th><th></th><?php endforeach; ?><th><?php echo esc_html($number($areaTotals[$head]??0)); ?></th></tr><?php foreach($grouped[$head] as $unit): ?><tr><td><?php echo (int)$no++; ?></td><td><?php echo esc_html($unit->name); ?></td><?php foreach($providers as $provider): foreach($matrix[(int)$unit->id][(int)$provider->id] as $weekValue): ?><td><?php echo esc_html($number($weekValue)); ?></td><?php endforeach; endforeach; ?><td><?php echo esc_html($number($unitTotals[(int)$unit->id])); ?></td></tr><?php endforeach; endforeach; ?></tbody><tfoot><tr><th colspan="2">Total</th><?php foreach($providers as $provider): ?><th colspan="4"><?php echo esc_html($number($providerTotals[(int)$provider->id])); ?></th><?php endforeach; ?><th><?php echo esc_html($number($grandTotal)); ?></th></tr></tfoot></table></div></div>
                <div class="ct-ref-phase3-grid"><div><h2>PEMBAYARAN KLAIM ASURANSI KREDIT</h2><div class="ct-ref-panel ct-ref-bars"><div class="ct-ref-bars-inner"><?php $monthlyMax=0; $monthly=array(); for($m=1;$m<=12;$m++){ $v=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount_million),0) FROM {$t['entries']} WHERE program_id=%d AND year=%d AND month=%d",$program->id,$year,$m));$monthly[$m]=$v;$monthlyMax=max($monthlyMax,$v); } foreach($monthly as $m=>$v): ?><div class="ct-ref-bar-col"><div class="ct-ref-bar" style="height:<?php echo esc_attr($monthlyMax>0?max(4,min(100,$v/$monthlyMax*100)):4); ?>%" title="<?php echo esc_attr($months[$m].': '.$number($v)); ?>"></div><small><?php echo esc_html(strtoupper(substr($months[$m],0,3))); ?></small></div><?php endforeach; ?></div><div class="ct-ref-chart-note">Periode <?php echo esc_html($months[$month].' '.$year); ?></div></div></div><div><h2>KDP vs KLAIM TERBUKU</h2><div class="ct-ref-panel ct-ref-chart-card ct-ref-chart-card--large"><?php $donut('',$providerItems); ?></div></div></div>
            <?php else: ?>
                <div class="ct-ref-top-grid"><div><h2><?php echo esc_html($labels['position']); ?></h2><div class="ct-ref-panel ct-ref-position-panel"><div class="ct-ref-table-wrap"><table class="ct-ref-table ct-ref-table--detail"><thead><tr><th rowspan="2">No</th><th rowspan="2">Unit Kerja</th><?php foreach($providers as $provider): ?><th colspan="2"><?php echo esc_html($providerLabel($provider)); ?></th><?php endforeach; ?><th colspan="2">Total</th></tr><tr><?php foreach($providers as $provider): ?><th>Deb</th><th>Rp</th><?php endforeach; ?><th>Deb</th><th>Rp</th></tr></thead><tbody><?php $no=1; foreach($groupOrder as $head): if(empty($grouped[$head])){continue;} ?><tr class="ct-ref-group"><th colspan="2"><?php echo esc_html($head); ?></th><?php foreach($providers as $provider): $headValue=0; foreach($grouped[$head] as $unit){$headValue+=array_sum($matrix[(int)$unit->id][(int)$provider->id]);} ?><th><?php echo esc_html($number($headValue>0?count($grouped[$head]):0)); ?></th><th><?php echo esc_html($number($headValue)); ?></th><?php endforeach; ?><th><?php echo esc_html($number($areaTotals[$head]>0?count($grouped[$head]):0)); ?></th><th><?php echo esc_html($number($areaTotals[$head]??0)); ?></th></tr><?php foreach($grouped[$head] as $unit): ?><tr><td><?php echo (int)$no++; ?></td><td><?php echo esc_html($unit->name); ?></td><?php foreach($providers as $provider): $value=array_sum($matrix[(int)$unit->id][(int)$provider->id]); ?><td><?php echo esc_html($number($value>0?1:0)); ?></td><td><?php echo esc_html($number($value)); ?></td><?php endforeach; ?><td><?php echo esc_html($number($unitTotals[(int)$unit->id]>0?1:0)); ?></td><td><?php echo esc_html($number($unitTotals[(int)$unit->id])); ?></td></tr><?php endforeach; endforeach; ?></tbody><tfoot><tr><th colspan="2">Total</th><?php foreach($providers as $provider): ?><th><?php echo esc_html($number($providerTotals[(int)$provider->id]>0?count($units):0)); ?></th><th><?php echo esc_html($number($providerTotals[(int)$provider->id])); ?></th><?php endforeach; ?><th><?php echo esc_html($number($grandTotal>0?count($units):0)); ?></th><th><?php echo esc_html($number($grandTotal)); ?></th></tr></tfoot></table></div></div></div><div class="ct-ref-chart-stack"><div><h2><?php echo $code==='DOK_LENGKAP'?'PERSENTASE HASIL VERIFIKASI':'PERSENTASE PER ASURADUR'; ?></h2><?php $donut('', $verificationItems); ?></div><div><h2><?php echo $code==='DOK_LENGKAP'?'PERSENTASE PER AREA HEAD':'PERSENTASE PER UKER'; ?></h2><?php $donut('', $code==='DOK_LENGKAP'?$areaItems:$areaItems); ?></div></div></div>
            <?php endif; ?>
            <div class="ct-ref-nominative"><h2><?php echo esc_html($labels['nominal']); ?></h2><div class="ct-ref-panel"><div class="ct-ref-unit-buttons"><?php foreach($units as $unit): ?><button type="button"><?php echo esc_html($unit->name); ?></button><?php endforeach; ?></div><button type="button" class="ct-ref-download">Download</button><div class="ct-ref-table-wrap"><table class="ct-ref-table ct-ref-nominative-table"><thead><?php if($isTerbuku): ?><tr><th>No</th><th>Area Head</th><th>BO</th><th>Uker</th><th>Asuradur</th><th>Debitur</th><th>No Rekening</th><th>Nomor Pengajuan</th><th>Tanggal</th><th>Nominal</th><th>Aging</th></tr><?php else: ?><tr><th>No</th><th>Kode</th><th>BO</th><th>Unit Kerja</th><th>Debitur</th><th>Asuradur</th><th>No Polis</th><th>No Rekening</th><th>Sukses</th><th>Proses</th><th>Total</th></tr><?php endif; ?></thead><tbody><?php if($debitur): foreach($debitur as $i=>$row): ?><tr><td><?php echo (int)$i+1; ?></td><?php if($isTerbuku): ?><td><?php echo esc_html($areaHead((object)array('name'=>$row->unit_name))); ?></td><td><?php echo esc_html($row->unit_name); ?></td><td><?php echo esc_html($row->unit_name); ?></td><td><?php echo esc_html($row->provider_name); ?></td><td><?php echo esc_html($row->nama_nasabah); ?></td><td><?php echo esc_html($row->nomor_klaim); ?></td><td><?php echo esc_html($row->nomor_klaim); ?></td><td><?php echo esc_html(wp_date('d/m/Y')); ?></td><td><?php echo esc_html($number($row->amount_million)); ?></td><td>0</td><?php else: ?><td><?php echo esc_html($row->nomor_klaim); ?></td><td><?php echo esc_html($row->unit_name); ?></td><td><?php echo esc_html($row->unit_name); ?></td><td><?php echo esc_html($row->nama_nasabah); ?></td><td><?php echo esc_html($row->provider_name); ?></td><td><?php echo esc_html($row->nomor_klaim); ?></td><td>-</td><td><?php echo esc_html($number($row->amount_million)); ?></td><td><?php echo esc_html($row->status_klaim==='Selesai'?$number($row->amount_million):'0'); ?></td><td><?php echo esc_html($number($row->amount_million)); ?></td><?php endif; ?></tr><?php endforeach; else: ?><tr><td colspan="11">Belum ada data nominatif untuk fase ini.</td></tr><?php endif; ?></tbody></table></div></div></div>
        </section>
        <?php
    }

    private static function render_phase_dashboard_generic($settings){
        global $wpdb; $t=ClaimTrack_DB::tables();
        $programId=(int)($_GET['program_id']??0);
        if(!$programId){ $programId=(int)$wpdb->get_var("SELECT id FROM {$t['programs']} WHERE code='KDP' LIMIT 1"); }
        $program=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['programs']} WHERE id=%d AND active=1",$programId));
        if(!$program){ status_header(404); nocache_headers(); self::render_not_found(); return; }
        $year=max(2000,min(2100,(int)($_GET['year']??wp_date('Y'))));
        $month=max(1,min(12,(int)($_GET['month']??wp_date('n'))));
        $months=self::month_names();
        $providers=$wpdb->get_results("SELECT * FROM {$t['providers']} WHERE active=1 ORDER BY sort_order,name");
        $units=$wpdb->get_results("SELECT * FROM {$t['units']} WHERE active=1 ORDER BY sort_order,name");

        $providerTotals=array(); $grandTotal=0.0;
        foreach($providers as $pr){
            $v=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount_million),0) FROM {$t['entries']} WHERE program_id=%d AND provider_id=%d AND year=%d AND month=%d",$programId,$pr->id,$year,$month));
            $providerTotals[$pr->id]=$v; $grandTotal+=$v;
        }

        $matrix=array(); $unitTotals=array(); $donut=array();
        foreach($units as $u){
            $unitTotals[$u->id]=0.0; $providerParts=array();
            foreach($providers as $pr){
                $v=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount_million),0) FROM {$t['entries']} WHERE unit_id=%d AND program_id=%d AND provider_id=%d AND year=%d AND month=%d",$u->id,$programId,$pr->id,$year,$month));
                $matrix[$u->id][$pr->id]=$v; $unitTotals[$u->id]+=$v;
                $providerParts[]=array('id'=>(int)$pr->id,'name'=>$pr->name,'value'=>$v);
            }
            $donut[(string)$u->id]=array('name'=>$u->name,'total'=>$unitTotals[$u->id],'providers'=>$providerParts);
        }
        $firstUnit=0; foreach($units as $u){ if($unitTotals[$u->id]>0){$firstUnit=(int)$u->id;break;} } if(!$firstUnit && $units){$firstUnit=(int)$units[0]->id;}
        ?>
        <section class="ct-phase-hero">
            <div class="ct-phase-head">
                <div>
                    <div class="ct-phase-title"><strong><?php echo esc_html($program->phase_label ?: 'FASE'); ?></strong><span>- <?php echo esc_html($program->name); ?></span></div>
                    <div class="ct-phase-subtitle"><?php echo esc_html($months[$month].' '.$year); ?> · <?php echo esc_html($settings['region_label']); ?></div>
                </div>
                <div class="ct-phase-tools">
                    <form method="get" class="ct-period-filter ct-period-filter--phase">
                        <input type="hidden" name="view" value="phase"><input type="hidden" name="program_id" value="<?php echo (int)$programId;?>">
                        <select name="month"><?php foreach($months as $n=>$m):?><option value="<?php echo $n;?>" <?php selected($month,$n);?>><?php echo esc_html($m);?></option><?php endforeach;?></select>
                        <input type="number" name="year" value="<?php echo esc_attr($year);?>" min="2000" max="2100"><button class="ct-btn ct-btn--light">Tampilkan</button>
                    </form>
                </div>
            </div>
            <div class="ct-provider-cards">
                <?php foreach($providers as $pr):?>
                    <article class="ct-provider-card" style="--ct-card:<?php echo esc_attr($program->color);?>">
                        <div class="ct-provider-name"><?php echo esc_html($pr->name);?></div>
                        <div class="ct-provider-value"><span>IDR</span> <?php echo esc_html(self::fmt_phase_card($providerTotals[$pr->id]));?></div>
                    </article>
                <?php endforeach;?>
            </div>
        </section>
        <section class="ct-phase-body">
            <article class="ct-panel ct-phase-table-panel">
                <div class="ct-panel-title">POSISI <?php echo esc_html(strtoupper($program->name));?> (KLAIM DALAM PROSES)</div>
                <div class="ct-table-scroll ct-phase-table-scroll"><table class="ct-table ct-phase-table">
                    <thead><tr><th>No</th><th>Unit Kerja</th><?php foreach($providers as $pr):?><th><?php echo esc_html($pr->name);?></th><?php endforeach;?><th>Total <?php echo esc_html($program->name);?><br><?php echo esc_html($months[$month].' '.$year);?></th></tr></thead>
                    <tbody><?php foreach($units as $i=>$u):?><tr><td><?php echo $i+1;?></td><td><?php echo esc_html($u->name);?></td><?php foreach($providers as $pr):?><td><?php echo esc_html(number_format($matrix[$u->id][$pr->id],0,',','.'));?></td><?php endforeach;?><td class="ct-row-total"><?php echo esc_html(number_format($unitTotals[$u->id],0,',','.'));?></td></tr><?php endforeach;?></tbody>
                    <tfoot><tr><th colspan="2">Total</th><?php foreach($providers as $pr):?><th><?php echo esc_html(number_format($providerTotals[$pr->id],0,',','.'));?></th><?php endforeach;?><th><?php echo esc_html(number_format($grandTotal,0,',','.'));?></th></tr></tfoot>
                </table></div>
            </article>

            <article class="ct-panel ct-nominative-panel" data-ct-phase-donut data-units='<?php echo esc_attr(wp_json_encode($donut));?>' data-selected="<?php echo (int)$firstUnit;?>">
                <div class="ct-panel-title">DAFTAR NOMINATIF PER UNIT KERJA</div>
                <div class="ct-donut-wrap">
                    <div class="ct-donut-ring" data-ct-donut-ring><div class="ct-donut-center"><span data-ct-donut-unit>-</span><strong data-ct-donut-total>0</strong><small>Juta Rupiah</small></div></div>
                    <div class="ct-donut-legend" data-ct-donut-legend></div>
                </div>
            </article>

            <article class="ct-panel ct-unit-list-panel">
                <div class="ct-panel-title">UNIT KERJA</div>
                <div class="ct-unit-list" data-ct-unit-list>
                    <?php foreach($units as $u):?><button type="button" class="ct-unit-button <?php echo (int)$u->id===$firstUnit?'is-active':'';?>" data-ct-unit="<?php echo (int)$u->id;?>"><span><?php echo esc_html($u->name);?></span><b><?php echo esc_html(number_format($unitTotals[$u->id],0,',','.'));?></b></button><?php endforeach;?>
                </div>
            </article>
        </section>
        <?php
    }

    private static function render_position_table($year,$month){
        global $wpdb; $t=ClaimTrack_DB::tables(); $months=self::month_names();
        $prog=(int)$wpdb->get_var("SELECT id FROM {$t['programs']} WHERE code='TERBUKU' LIMIT 1");
        $units=$wpdb->get_results("SELECT * FROM {$t['units']} WHERE active=1 ORDER BY sort_order,name");
        $prevMonth=$month-1; $prevYear=$year; if($prevMonth<1){$prevMonth=12;$prevYear--;}
        ?>
        <div class="ct-panel ct-panel--table"><h3>POSISI KLAIM TERBUKU</h3><div class="ct-table-scroll"><table class="ct-table"><thead><tr><th rowspan="2">No</th><th rowspan="2">Unit Kerja</th><th rowspan="2"><?php echo esc_html(substr($months[$prevMonth],0,3));?></th><th colspan="4"><?php echo esc_html($months[$month].' '.$year);?></th></tr><tr><th>I</th><th>II</th><th>III</th><th>IV</th></tr></thead><tbody>
        <?php $tot=array(0,0,0,0,0); foreach($units as $i=>$u):
            $prev=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount_million),0) FROM {$t['entries']} WHERE unit_id=%d AND program_id=%d AND year=%d AND month=%d",$u->id,$prog,$prevYear,$prevMonth)); $tot[0]+=$prev;
            $weeks=array(); for($w=1;$w<=4;$w++){ $v=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount_million),0) FROM {$t['entries']} WHERE unit_id=%d AND program_id=%d AND year=%d AND month=%d AND week=%d",$u->id,$prog,$year,$month,$w)); $weeks[$w]=$v;$tot[$w]+=$v; }
            ?><tr><td><?php echo $i+1;?></td><td><?php echo esc_html($u->name);?></td><td><?php echo esc_html(number_format($prev,0,',','.'));?></td><?php for($w=1;$w<=4;$w++):?><td><?php echo esc_html(number_format($weeks[$w],0,',','.'));?></td><?php endfor;?></tr>
        <?php endforeach;?></tbody><tfoot><tr><th colspan="2">Total</th><?php foreach($tot as $v):?><th><?php echo esc_html(number_format($v,0,',','.'));?></th><?php endforeach;?></tr></tfoot></table></div></div>
        <?php
    }

    private static function render_chart($year){
        global $wpdb; $t=ClaimTrack_DB::tables(); $prog=(int)$wpdb->get_var("SELECT id FROM {$t['programs']} WHERE code='TERBUKU' LIMIT 1");
        $series=array(); foreach(array($year-1,$year) as $y){$vals=array();for($m=1;$m<=12;$m++){$vals[]=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount_million),0) FROM {$t['entries']} WHERE program_id=%d AND year=%d AND month=%d",$prog,$y,$m));}$series[$y]=$vals;}
        ?>
        <div class="ct-panel ct-panel--chart"><h3>PEMBAYARAN KLAIM ASURANSI KREDIT</h3><div class="ct-chart" data-ct-chart data-series='<?php echo esc_attr(wp_json_encode($series));?>'></div><div class="ct-chart-table"><table><thead><tr><th>TAHUN</th><?php foreach(array('JAN','FEB','MAR','APR','MEI','JUN','JUL','AGS','SEP','OKT','NOV','DES') as $m):?><th><?php echo $m;?></th><?php endforeach;?></tr></thead><tbody><?php foreach($series as $y=>$vals):?><tr><th><?php echo $y;?></th><?php foreach($vals as $v):?><td><?php echo esc_html(number_format($v,0,',','.'));?></td><?php endforeach;?></tr><?php endforeach;?></tbody></table></div></div>
        <?php
    }

    private static function render_matrix($forcedProgramId=0,$forcedSection=''){
        global $wpdb; $t=ClaimTrack_DB::tables(); $months=self::month_names();
        $programId=$forcedProgramId>0?(int)$forcedProgramId:(int)($_GET['program_id']??0);
        if(!$programId)$programId=(int)$wpdb->get_var("SELECT id FROM {$t['programs']} WHERE active=1 ORDER BY dashboard_order LIMIT 1");
        $year=max(2000,min(2100,(int)($_GET['year']??wp_date('Y')))); $month=max(1,min(12,(int)($_GET['month']??wp_date('n'))));
        $program=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['programs']} WHERE id=%d",$programId));
        $programs=$wpdb->get_results("SELECT * FROM {$t['programs']} WHERE active=1 ORDER BY dashboard_order,name"); $units=$wpdb->get_results("SELECT * FROM {$t['units']} WHERE active=1 ORDER BY sort_order,name"); $providers=$wpdb->get_results("SELECT * FROM {$t['providers']} WHERE active=1 ORDER BY sort_order,name");
        $entries=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['entries']} WHERE program_id=%d AND year=%d AND month=%d",$programId,$year,$month)); $map=array(); foreach($entries as $e)$map[$e->unit_id][$e->provider_id][$e->week]=$e->amount_million;
        $section=$forcedSection!==''?sanitize_key($forcedSection):sanitize_key((string)($_GET['section']??'phase1'));
        $phaseTitle=$program?trim(($program->phase_label?$program->phase_label.' - ':'').$program->name):'Input Data';
        ?>
        <section class="ct-content ct-admin-phase-input"><div class="ct-section-head ct-admin-input-head"><div><span class="ct-admin-input-kicker">INPUT DATA KLAIM</span><h1><?php echo esc_html($phaseTitle);?></h1><p>Masukkan nominal per Unit Kerja, Asuradur, dan Minggu I-IV. Satuan input menggunakan juta rupiah.</p></div><div class="ct-admin-input-period"><span class="dashicons dashicons-calendar-alt"></span><strong><?php echo esc_html($months[$month].' '.$year);?></strong></div></div>
        <form method="get" class="ct-toolbar ct-admin-input-toolbar" data-ct-auto-period><?php if(self::$admin_portal): ?><input type="hidden" name="section" value="<?php echo esc_attr($section); ?>"><?php else:?><input type="hidden" name="view" value="matrix"><?php endif;?><?php if(!$forcedProgramId):?><select name="program_id"><?php foreach($programs as $p):?><option value="<?php echo $p->id;?>" <?php selected($programId,$p->id);?>><?php echo esc_html(($p->phase_label?$p->phase_label.' - ':'').$p->name);?></option><?php endforeach;?></select><?php else:?><input type="hidden" name="program_id" value="<?php echo (int)$programId;?>"><?php endif;?><select name="month"><?php foreach($months as $n=>$m):?><option value="<?php echo $n;?>" <?php selected($month,$n);?>><?php echo esc_html($m);?></option><?php endforeach;?></select><input type="number" name="year" value="<?php echo esc_attr($year);?>" min="2000" max="2100"><button class="ct-btn" type="submit"><span class="dashicons dashicons-update"></span> Buka Periode</button></form>
        <form method="post"><?php wp_nonce_field('claimtrack_action','claimtrack_nonce');?><input type="hidden" name="claimtrack_action" value="matrix_save"><?php if(self::$admin_portal):?><input type="hidden" name="admin_section" value="<?php echo esc_attr($section); ?>"><?php endif;?><input type="hidden" name="program_id" value="<?php echo $programId;?>"><input type="hidden" name="year" value="<?php echo $year;?>"><input type="hidden" name="month" value="<?php echo $month;?>">
        <div class="ct-panel ct-admin-matrix-panel"><div class="ct-admin-matrix-summary"><div><span class="dashicons dashicons-edit-page"></span><strong><?php echo esc_html(count($units));?> Unit Kerja</strong><small><?php echo esc_html(count($providers));?> Asuradur · Minggu I-IV</small></div><p>Isi nilai yang diperlukan lalu tekan <strong>Simpan & Sinkronkan</strong>. Kolom kosong akan menghapus nilai pada sel tersebut.</p></div><div class="ct-table-scroll"><table class="ct-table ct-matrix"><thead><tr><th rowspan="2">No</th><th rowspan="2">Unit Kerja</th><?php foreach($providers as $pr):?><th colspan="4"><?php echo esc_html($pr->name);?></th><?php endforeach;?><th rowspan="2">Total</th></tr><tr><?php foreach($providers as $pr):for($w=1;$w<=4;$w++):?><th><?php echo array(1=>'I',2=>'II',3=>'III',4=>'IV')[$w];?></th><?php endfor;endforeach;?></tr></thead><tbody>
        <?php foreach($units as $i=>$u): $rowTotal=0;?><tr><td><?php echo $i+1;?></td><td class="ct-sticky-name"><?php echo esc_html($u->name);?></td><?php foreach($providers as $pr):for($w=1;$w<=4;$w++):$v=$map[$u->id][$pr->id][$w]??'';$rowTotal+=(float)$v;?><td><?php if((self::$admin_portal && self::can_manage())):?><input type="number" step="0.01" min="0" name="matrix[<?php echo $u->id;?>][<?php echo $pr->id;?>][<?php echo $w;?>]" value="<?php echo esc_attr($v);?>" placeholder="0"><?php else:echo esc_html(number_format((float)$v,2,',','.'));endif;?></td><?php endfor;endforeach;?><td class="ct-row-total"><?php echo esc_html(number_format($rowTotal,2,',','.'));?></td></tr><?php endforeach;?></tbody></table></div>
        <?php if((self::$admin_portal && self::can_manage())):?><div class="ct-panel-actions ct-admin-matrix-actions"><p><span class="dashicons dashicons-info-outline"></span> Data disimpan langsung ke basis data ClaimTrack dan segera tersedia pada dashboard user.</p><button class="ct-btn ct-btn--primary" type="submit"><span class="dashicons dashicons-saved"></span>Simpan & Sinkronkan</button></div><?php endif;?></div></form></section>
        <?php
    }

    private static function render_master($type){
        global $wpdb; $t=ClaimTrack_DB::tables(); if(!self::can_manage())return;
        $labels=array('units'=>array('Unit Kerja','unit'),'providers'=>array('Mitra / Asuransi','provider'),'programs'=>array('Program','program')); $label=$labels[$type][0];
        $editId=(int)($_GET['edit']??0); $edit=$editId?$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t[$type]} WHERE id=%d",$editId)):null;
        $order=$type==='programs'?'dashboard_order,name':'sort_order,name'; $rows=$wpdb->get_results("SELECT * FROM {$t[$type]} ORDER BY {$order}");
        ?>
        <section class="ct-content"><div class="ct-section-head"><div><h1>CRUD <?php echo esc_html($label);?></h1><p>Tambah, ubah, nonaktifkan, dan hapus master data yang belum digunakan.</p></div></div><div class="ct-two-col"><div class="ct-panel"><h3><?php echo $edit?'Edit':'Tambah';?> <?php echo esc_html($label);?></h3><form method="post" class="ct-form"><?php wp_nonce_field('claimtrack_action','claimtrack_nonce');?><input type="hidden" name="claimtrack_action" value="<?php echo esc_attr($type==='units'?'unit_save':($type==='programs'?'program_save':'provider_save'));?>"><input type="hidden" name="id" value="<?php echo esc_attr($editId);?>"><label>Kode<input name="code" maxlength="40" required value="<?php echo esc_attr($edit->code??'');?>"></label><label>Nama<input name="name" maxlength="160" required value="<?php echo esc_attr($edit->name??'');?>"></label>
        <?php if($type==='programs'):?><label>Label Fase<input name="phase_label" placeholder="FASE 1" value="<?php echo esc_attr($edit->phase_label??'');?>"></label><label>Warna Kartu<input type="color" name="color" value="<?php echo esc_attr($edit->color??'#23b653');?>"></label><label>Urutan Dashboard<input type="number" name="dashboard_order" value="<?php echo esc_attr($edit->dashboard_order??0);?>"></label><label class="ct-check"><input type="checkbox" name="show_dashboard" <?php checked((int)($edit->show_dashboard??0),1);?>> Tampilkan sebagai kartu dashboard</label><?php else:?><label>Urutan<input type="number" name="sort_order" value="<?php echo esc_attr($edit->sort_order??0);?>"></label><?php endif;?><label class="ct-check"><input type="checkbox" name="active" <?php checked((int)($edit->active??1),1);?>> Aktif</label><div class="ct-form-actions"><button class="ct-btn ct-btn--primary">Simpan</button><?php if($edit):?><a class="ct-btn ct-btn--ghost" href="<?php echo esc_url(self::app_url(array('view'=>$type)));?>">Batal</a><?php endif;?></div></form></div>
        <div class="ct-panel"><h3>Daftar <?php echo esc_html($label);?></h3><div class="ct-table-scroll"><table class="ct-table"><thead><tr><th>Kode</th><th>Nama</th><th>Status</th><th>Aksi</th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td><?php echo esc_html($r->code);?></td><td><?php echo esc_html($r->name);?></td><td><span class="ct-badge <?php echo $r->active?'is-on':'is-off';?>"><?php echo $r->active?'Aktif':'Nonaktif';?></span></td><td class="ct-actions"><a class="ct-link" href="<?php echo esc_url(self::app_url(array('view'=>$type,'edit'=>$r->id)));?>">Edit</a><form method="post" data-ct-confirm="Hapus data ini?" data-ct-confirm-title="Hapus Data"><?php wp_nonce_field('claimtrack_action','claimtrack_nonce');?><input type="hidden" name="claimtrack_action" value="<?php echo esc_attr($type==='units'?'unit_delete':($type==='programs'?'program_delete':'provider_delete'));?>"><input type="hidden" name="id" value="<?php echo $r->id;?>"><button class="ct-link ct-link--danger">Hapus</button></form></td></tr><?php endforeach;?></tbody></table></div></div></div></section>
        <?php
    }

    private static function render_import_export(){
        global $wpdb; $t=ClaimTrack_DB::tables(); if(!self::can_import_export())return;
        $programs=$wpdb->get_results("SELECT * FROM {$t['programs']} WHERE active=1 ORDER BY dashboard_order,name");
        $units=$wpdb->get_results("SELECT * FROM {$t['units']} WHERE active=1 ORDER BY sort_order,name");
        $months=self::month_names();
        $base=array('year'=>(int)($_GET['year']??wp_date('Y')),'month'=>(int)($_GET['month']??0),'program_id'=>(int)($_GET['program_id']??0),'unit_id'=>(int)($_GET['unit_id']??0));
        $nonce=wp_create_nonce('claimtrack_export');
        $backupUrl=wp_nonce_url(self::app_url(array('view'=>'import','ct_backup'=>1)),'claimtrack_backup');
        ?>
        <section class="ct-content">
            <div class="ct-section-head"><div><h1>Import, Export, Backup & Restore</h1><p>Kelola sinkronisasi data, export laporan, backup, dan restore ClaimTrack dari satu tempat.</p></div></div>
            <div class="ct-two-col">
                <div class="ct-panel">
                    <h3>Upload CSV / XLSX</h3>
                    <p class="ct-help"><strong>Gunakan Template Excel untuk input manual.</strong> File sudah berbentuk tabel Excel dengan header, filter, dan baris Unit Kerja × Mitra × Minggu I-IV. Isi kolom <strong>Nominal</strong>, simpan, lalu upload kembali.</p>
                    <div class="ct-template-actions"><a class="ct-btn ct-btn--excel" href="<?php echo esc_url(wp_nonce_url((self::$admin_portal?self::admin_portal_url('import',array('ct_download_template_xlsx'=>1)):self::app_url(array('ct_download_template_xlsx'=>1))),'claimtrack_template_xlsx'));?>">Template Excel (Disarankan)</a><a class="ct-btn ct-btn--secondary" href="<?php echo esc_url(wp_nonce_url((self::$admin_portal?self::admin_portal_url('import',array('ct_download_template'=>1)):self::app_url(array('ct_download_template'=>1))),'claimtrack_template'));?>">Template CSV</a></div>
                    <form method="post" enctype="multipart/form-data" class="ct-form ct-import-form"><?php wp_nonce_field('claimtrack_action','claimtrack_nonce');?><input type="hidden" name="claimtrack_action" value="import"><label>File<input type="file" name="import_file" accept=".csv,.xlsx" required></label><button class="ct-btn ct-btn--primary">Upload & Sinkronkan</button></form>
                </div>
                <div class="ct-panel">
                    <h3>Download Data</h3>
                    <form method="get" class="ct-form"><?php if(self::$admin_portal):?><input type="hidden" name="section" value="import"><?php else:?><input type="hidden" name="view" value="import"><?php endif;?><label>Tahun<input type="number" name="year" value="<?php echo esc_attr($base['year']);?>"></label><label>Bulan<select name="month"><option value="0">Semua Bulan</option><?php foreach($months as $n=>$m):?><option value="<?php echo $n;?>" <?php selected($base['month'],$n);?>><?php echo esc_html($m);?></option><?php endforeach;?></select></label><label>Program<select name="program_id"><option value="0">Semua Program</option><?php foreach($programs as $p):?><option value="<?php echo $p->id;?>" <?php selected($base['program_id'],$p->id);?>><?php echo esc_html($p->name);?></option><?php endforeach;?></select></label><label>Unit Kerja<select name="unit_id"><option value="0">Semua Unit</option><?php foreach($units as $u):?><option value="<?php echo $u->id;?>" <?php selected($base['unit_id'],$u->id);?>><?php echo esc_html($u->name);?></option><?php endforeach;?></select></label><button class="ct-btn">Terapkan Filter</button></form>
                    <div class="ct-export-buttons"><?php $q=array_merge($base,array('_wpnonce'=>$nonce));?><a class="ct-btn ct-btn--excel" href="<?php echo esc_url((self::$admin_portal?self::admin_portal_url('import',array_merge($q,array('ct_export'=>'xlsx'))):self::app_url(array_merge($q,array('ct_export'=>'xlsx')))));?>">Download Excel (.xlsx)</a><a class="ct-btn ct-btn--pdf" href="<?php echo esc_url((self::$admin_portal?self::admin_portal_url('import',array_merge($q,array('ct_export'=>'pdf'))):self::app_url(array_merge($q,array('ct_export'=>'pdf')))));?>">Download PDF</a></div>
                </div>
            </div>

            <div class="ct-backup-grid">
                <article class="ct-panel ct-backup-panel">
                    <div class="ct-backup-icon"><span class="dashicons dashicons-download"></span></div>
                    <div><h3>Backup Lengkap ClaimTrack</h3><p class="ct-help">Mengunduh Unit Kerja, Program/Fase, Mitra, seluruh transaksi Minggu I-IV, E-Knowledge, berita, komentar, dan pengaturan ClaimTrack dalam satu file JSON.</p></div>
                    <a class="ct-btn ct-btn--primary" href="<?php echo esc_url($backupUrl); ?>">Download Backup (.json)</a>
                </article>
                <article class="ct-panel ct-backup-panel ct-backup-panel--restore">
                    <div class="ct-backup-icon"><span class="dashicons dashicons-backup"></span></div>
                    <div><h3>Restore Backup</h3><p class="ct-help"><strong>Restore akan mengganti data ClaimTrack saat ini</strong> dengan isi file backup. Seluruh data terkait akan disinkronkan kembali secara otomatis.</p></div>
                    <form method="post" enctype="multipart/form-data" class="ct-form ct-restore-form" data-ct-confirm="Restore akan mengganti seluruh data ClaimTrack saat ini. Lanjutkan?" data-ct-confirm-title="Konfirmasi Restore">
                        <?php wp_nonce_field('claimtrack_action','claimtrack_nonce'); ?>
                        <input type="hidden" name="claimtrack_action" value="restore_backup">
                        <label>File Backup JSON<input type="file" name="backup_file" accept=".json,application/json" required></label>
                        <button class="ct-btn ct-btn--danger" type="submit">Restore Data</button>
                    </form>
                </article>
            </div>
        </section>
        <?php
    }

    private static function render_settings($settings){
        if(!self::can_manage()) return;
        ?>
        <section class="ct-content">
            <div class="ct-section-head"><div><h1>Pengaturan ClaimTrack</h1><p>Atur identitas dashboard, kontak Admin, dan keamanan login.</p></div></div>
            <div class="ct-settings-grid ct-settings-grid--single">
                <div class="ct-panel">
                    <form method="post" class="ct-form" enctype="multipart/form-data">
                        <?php wp_nonce_field('claimtrack_action','claimtrack_nonce'); ?>
                        <input type="hidden" name="claimtrack_action" value="settings_save">
                        <div class="ct-settings-heading"><h3>Identitas Dashboard</h3><p>Pengaturan ini digunakan pada dashboard dan halaman monitoring fase.</p></div>
                        <label>Judul Dashboard<input name="dashboard_title" value="<?php echo esc_attr($settings['dashboard_title']); ?>"></label>
                        <label>Departemen<input name="department" value="<?php echo esc_attr($settings['department']); ?>"></label>
                        <label>Label Region<input name="region_label" value="<?php echo esc_attr($settings['region_label']); ?>"></label>
                        <label>Satuan Input<input value="Juta Rupiah" disabled></label>
                        <label>Nomor WhatsApp Admin<input name="admin_whatsapp" inputmode="numeric" value="<?php echo esc_attr($settings['admin_whatsapp']??''); ?>" placeholder="Contoh: 6281234567890"><small class="ct-help">Gunakan format internasional tanpa tanda +. Contoh Indonesia: 62812...</small></label>
                        <label>Logo Dashboard<input type="file" name="claimtrack_logo" accept="image/png,image/jpeg,image/webp"><small class="ct-help">Upload logo baru untuk sidebar, SW Admin, login, dan header aplikasi.</small></label>
                        <label>URL Logo Alternatif<input name="logo_url" type="url" value="<?php echo esc_attr($settings['logo_url']??''); ?>" placeholder="https://contoh.com/logo.png"><small class="ct-help">Opsional. Jika diisi, URL ini digunakan bila tidak ada upload logo.</small></label>
                        <div class="ct-settings-divider"></div>
                        <div class="ct-settings-heading"><h3>Warna Theme Claim Track</h3><p>Semua warna utama Dashboard User, SW Admin, tabel, kartu, tombol, sidebar, dan halaman login dapat diubah dari sini.</p></div>
                        <div class="ct-theme-color-grid">
                            <label>Sidebar<input type="color" name="color_sidebar" value="<?php echo esc_attr($settings['color_sidebar']); ?>"></label>
                            <label>Footer Sidebar<input type="color" name="color_sidebar_deep" value="<?php echo esc_attr($settings['color_sidebar_deep']); ?>"></label>
                            <label>Header<input type="color" name="color_header" value="<?php echo esc_attr($settings['color_header']); ?>"></label>
                            <label>Menu Aktif<input type="color" name="color_nav_active" value="<?php echo esc_attr($settings['color_nav_active']); ?>"></label>
                            <label>Garis Sidebar<input type="color" name="color_sidebar_line" value="<?php echo esc_attr($settings['color_sidebar_line']); ?>"></label>
                            <label>Background Workspace<input type="color" name="color_workspace" value="<?php echo esc_attr($settings['color_workspace']); ?>"></label>
                            <label>Panel / Card Putih<input type="color" name="color_panel" value="<?php echo esc_attr($settings['color_panel']); ?>"></label>
                            <label>KPI Utama<input type="color" name="color_kpi" value="<?php echo esc_attr($settings['color_kpi']); ?>"></label>
                            <label>KPI Gelap<input type="color" name="color_kpi_dark" value="<?php echo esc_attr($settings['color_kpi_dark']); ?>"></label>
                            <label>Border KPI<input type="color" name="color_kpi_border" value="<?php echo esc_attr($settings['color_kpi_border']); ?>"></label>
                            <label>Tombol Utama<input type="color" name="color_button" value="<?php echo esc_attr($settings['color_button']); ?>"></label>
                            <label>Header Tabel<input type="color" name="color_table" value="<?php echo esc_attr($settings['color_table']); ?>"></label>
                            <label>Subheader Tabel<input type="color" name="color_table_sub" value="<?php echo esc_attr($settings['color_table_sub']); ?>"></label>
                            <label>Header Tabel Fase<input type="color" name="color_phase_table" value="<?php echo esc_attr($settings['color_phase_table']); ?>"></label>
                            <label>Subheader Tabel Fase<input type="color" name="color_phase_table_sub" value="<?php echo esc_attr($settings['color_phase_table_sub']); ?>"></label>
                            <label>Merah / Danger<input type="color" name="color_danger" value="<?php echo esc_attr($settings['color_danger']); ?>"></label>
                            <label>Warna Teks<input type="color" name="color_text" value="<?php echo esc_attr($settings['color_text']); ?>"></label>
                            <label>Warna Teks Sekunder<input type="color" name="color_muted" value="<?php echo esc_attr($settings['color_muted']); ?>"></label>
                            <label>Login Panel Biru<input type="color" name="color_login_blue" value="<?php echo esc_attr($settings['color_login_blue']); ?>"></label>
                            <label>Login Footer<input type="color" name="color_login_footer" value="<?php echo esc_attr($settings['color_login_footer']); ?>"></label>
                            <label>Tombol Login<input type="color" name="color_login_button" value="<?php echo esc_attr($settings['color_login_button']); ?>"></label>
                        </div>
                        <div class="ct-settings-divider"></div>
                        <div class="ct-settings-heading"><h3>Cloudflare Turnstile</h3><p>Aktifkan proteksi bot pada halaman login ClaimTrack.</p></div>
                        <label class="ct-check ct-check--security"><input type="checkbox" name="turnstile_enabled" value="1" <?php checked(!empty($settings['turnstile_enabled'])); ?>><span>Aktifkan Cloudflare Turnstile pada login</span></label>
                        <label>Turnstile Site Key<input name="turnstile_site_key" value="<?php echo esc_attr($settings['turnstile_site_key']??''); ?>" autocomplete="off" placeholder="0x4AAAA..."></label>
                        <label>Turnstile Secret Key<input type="password" name="turnstile_secret_key" value="" autocomplete="new-password" placeholder="<?php echo !empty($settings['turnstile_secret_key'])?'Tersimpan, kosongkan jika tidak ingin mengganti':'Masukkan Secret Key'; ?>"></label>
                        <div class="ct-help">Secret Key tidak ditampilkan kembali. Kosongkan jika ingin mempertahankan key yang sudah tersimpan.</div>
                        <button class="ct-btn ct-btn--primary">Simpan Pengaturan</button>
                    </form>
                </div>
            </div>
        </section>
        <?php
    }

    private static function render_not_found(){ ?>
        <section class="ct-content ct-app-404"><div class="ct-panel ct-not-found-card"><div class="ct-not-found-code">404</div><h1>Halaman tidak ditemukan</h1><p>Menu atau halaman ClaimTrack yang Anda buka tidak tersedia.</p><a class="ct-btn ct-btn--primary" href="<?php echo esc_url(self::app_url()); ?>"><span class="dashicons dashicons-admin-home"></span>Kembali ke Dashboard</a></div></section>
        <?php }

    private static function render_knowledge(){
        $editId=max(0,(int)($_GET['edit_knowledge'] ?? 0));
        $editPost=$editId ? get_post($editId) : null;
        if (!($editPost instanceof WP_Post) || $editPost->post_type!=='ct_knowledge') { $editPost=null; $editId=0; }
        $items=get_posts(array('post_type'=>'ct_knowledge','post_status'=>'publish','posts_per_page'=>-1,'orderby'=>array('menu_order'=>'ASC','date'=>'DESC'),'order'=>'ASC'));
        ?>
        <section class="ct-content ct-knowledge-page">
            <div class="ct-knowledge-hero">
                <div>
                    <span class="ct-knowledge-kicker"><span class="dashicons dashicons-welcome-learn-more"></span> Knowledge Center</span>
                    <h1>E-KNOWLEDGE</h1>
                    <p>Dokumen, pedoman, dan materi kerja yang dapat dibuka langsung dari dashboard ClaimTrack.</p>
                </div>
                <div class="ct-knowledge-hero-actions">
                    <div class="ct-knowledge-count"><strong><?php echo esc_html(number_format_i18n(count($items))); ?></strong><span>Materi</span></div>
                    <?php if(self::$admin_portal && self::can_manage()): ?><button type="button" class="ct-btn ct-btn--knowledge-add" data-ct-knowledge-toggle><span class="dashicons dashicons-plus-alt2"></span>Tambah Materi</button><?php endif; ?>
                </div>
            </div>

            <?php if(self::$admin_portal && self::can_manage()): ?>
            <div class="ct-panel ct-knowledge-editor <?php echo $editPost?'is-open':''; ?>" data-ct-knowledge-editor>
                <div class="ct-knowledge-editor-head"><div><h3><?php echo $editPost?'Edit Materi':'Tambah Materi E-Knowledge'; ?></h3><p>Upload cover dan PDF. Semua data tersimpan sebagai data terstruktur ClaimTrack.</p></div><button type="button" class="ct-icon-btn" data-ct-knowledge-close aria-label="Tutup"><span class="dashicons dashicons-no-alt"></span></button></div>
                <form method="post" enctype="multipart/form-data" class="ct-form ct-knowledge-form">
                    <?php wp_nonce_field('claimtrack_action','claimtrack_nonce'); ?>
                    <input type="hidden" name="claimtrack_action" value="knowledge_save">
                    <input type="hidden" name="knowledge_id" value="<?php echo (int)$editId; ?>">
                    <label>Judul Materi<input type="text" name="knowledge_title" value="<?php echo esc_attr($editPost?$editPost->post_title:''); ?>" required placeholder="Contoh: Pedoman Klaim Asuransi Kredit"></label>
                    <label>Urutan<input type="number" name="knowledge_sort" value="<?php echo esc_attr($editPost?(int)$editPost->menu_order:0); ?>" min="0"></label>
                    <label class="ct-form-span-2">Deskripsi<textarea name="knowledge_description" rows="4" placeholder="Deskripsi singkat materi..."><?php echo esc_textarea($editPost?$editPost->post_content:''); ?></textarea></label>
                    <label>Cover Gambar<input type="file" name="knowledge_cover" accept="image/jpeg,image/png,image/webp"></label>
                    <label>File PDF<input type="file" name="knowledge_pdf" accept="application/pdf,.pdf" <?php echo $editPost?'':'required'; ?>></label>
                    <div class="ct-form-span-2 ct-form-actions"><button class="ct-btn ct-btn--primary" type="submit"><span class="dashicons dashicons-saved"></span><?php echo $editPost?'Simpan Perubahan':'Tambahkan Materi'; ?></button><?php if($editPost):?><a class="ct-btn ct-btn--light" href="<?php echo esc_url(self::app_url(array('view'=>'knowledge'))); ?>">Batal Edit</a><?php endif;?></div>
                </form>
            </div>
            <?php endif; ?>

            <?php if($items): ?>
            <div class="ct-knowledge-grid ct-knowledge-library">
                <?php foreach($items as $item):
                    $coverId=(int)get_post_meta($item->ID,'_claimtrack_knowledge_cover_id',true);
                    if(!$coverId){$coverId=(int)get_post_thumbnail_id($item->ID);}
                    $coverUrl=$coverId?wp_get_attachment_image_url($coverId,'large'):(string)get_post_meta($item->ID,'_claimtrack_knowledge_cover_url',true);
                    $pdfId=(int)get_post_meta($item->ID,'_claimtrack_knowledge_pdf_id',true);
                    $pdfUrl=$pdfId?wp_get_attachment_url($pdfId):(string)get_post_meta($item->ID,'_claimtrack_knowledge_pdf_url',true);
                    $desc=wp_trim_words(wp_strip_all_tags((string)$item->post_content),18,'…');
                ?>
                <article class="ct-knowledge-card">
                    <div class="ct-knowledge-cover <?php echo $coverUrl?'has-cover':'is-placeholder'; ?>" <?php echo $coverUrl?'style="background-image:url('.esc_url($coverUrl).')"':''; ?>>
                        <div class="ct-knowledge-cover-shade"></div>
                        <span class="ct-knowledge-glass-icon"><span class="dashicons dashicons-pdf"></span></span>
                        <div class="ct-knowledge-cover-label"><small>E-KNOWLEDGE</small><strong><?php echo esc_html($item->post_title); ?></strong></div>
                    </div>
                    <div class="ct-knowledge-card-body">
                        <div class="ct-knowledge-card-title"><span class="ct-glass-icon ct-glass-icon--small"><span class="dashicons dashicons-media-document"></span></span><div><h3><?php echo esc_html($item->post_title); ?></h3><p><?php echo esc_html($desc ?: 'Dokumen referensi ClaimTrack.'); ?></p></div></div>
                        <div class="ct-knowledge-card-actions">
                            <?php if($pdfUrl): ?><a class="ct-btn ct-btn--knowledge-open" href="<?php echo esc_url($pdfUrl); ?>" target="_blank" rel="noopener"><span class="dashicons dashicons-visibility"></span>Buka PDF</a><?php else:?><span class="ct-knowledge-no-file">PDF belum tersedia</span><?php endif; ?>
                            <?php if(self::$admin_portal && self::can_manage()): ?><div class="ct-knowledge-admin-actions"><a class="ct-icon-btn" href="<?php echo esc_url(add_query_arg('edit_knowledge',(int)$item->ID,self::app_url(array('view'=>'knowledge')))); ?>" title="Edit"><span class="dashicons dashicons-edit"></span></a><form method="post" data-ct-confirm="Hapus materi E-Knowledge ini?" data-ct-confirm-title="Hapus E-Knowledge"><?php wp_nonce_field('claimtrack_action','claimtrack_nonce'); ?><input type="hidden" name="claimtrack_action" value="knowledge_delete"><input type="hidden" name="knowledge_id" value="<?php echo (int)$item->ID; ?>"><button class="ct-icon-btn ct-icon-btn--danger" type="submit" title="Hapus"><span class="dashicons dashicons-trash"></span></button></form></div><?php endif; ?>
                        </div>
                    </div>
                </article>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="ct-panel ct-knowledge-empty"><span class="ct-empty-modal-icon"><span class="dashicons dashicons-media-document"></span></span><h3>Belum ada materi E-Knowledge</h3><p>Tambahkan PDF pertama agar dokumen tampil sebagai kartu seperti katalog.</p><?php if(self::$admin_portal && self::can_manage()):?><button type="button" class="ct-btn ct-btn--primary" data-ct-knowledge-toggle>Tambah Materi</button><?php endif;?></div>
            <?php endif; ?>
        </section>
        <?php
    }

    private static function render_achievement(){
        global $wpdb;
        $t=ClaimTrack_DB::tables();
        $year=max(2000,min(2100,(int)($_GET['year']??wp_date('Y'))));
        $programs=$wpdb->get_results("SELECT * FROM {$t['programs']} WHERE active=1 AND code<>'PENCAPAIAN' ORDER BY dashboard_order,name");
        $items=array(); $grand=0.0; $highest=null;
        foreach($programs as $p){
            $v=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount_million),0) FROM {$t['entries']} WHERE program_id=%d AND year=%d",$p->id,$year));
            $item=array('program'=>$p,'value'=>$v);
            $items[]=$item; $grand+=$v;
            if($highest===null || $v>$highest['value']){$highest=$item;}
        }
        $phaseMeta=array(
            'KDP'=>array('class'=>'phase1','icon'=>'chart-pie'),
            'DOK_LENGKAP'=>array('class'=>'phase2','icon'=>'media-document'),
            'TERBUKU'=>array('class'=>'phase3','icon'=>'yes-alt'),
        );
        $filterAction=self::$admin_portal?self::admin_portal_url('achievement'):self::app_url(array('view'=>'achievement'));
        ?>
        <section class="ct-content ct-achievement-page">
            <div class="ct-achievement-hero">
                <div class="ct-achievement-hero-copy">
                    <span class="ct-achievement-eyebrow">RINGKASAN TAHUNAN</span>
                    <h1>Pencapaian <?php echo esc_html($year);?></h1>
                    <p>Akumulasi nilai klaim setiap fase sepanjang tahun <?php echo esc_html($year);?> dalam satu tampilan yang lebih mudah dipantau.</p>
                </div>
                <form method="get" action="<?php echo esc_url($filterAction);?>" class="ct-achievement-filter" data-ct-auto-period>
                    <?php if(self::$admin_portal):?><input type="hidden" name="section" value="achievement"><?php else:?><input type="hidden" name="view" value="achievement"><?php endif;?>
                    <span class="ct-achievement-filter-icon"><span class="dashicons dashicons-calendar-alt"></span></span>
                    <label><small>Tahun</small><input type="number" name="year" value="<?php echo esc_attr($year);?>" min="2000" max="2100"></label>
                </form>
            </div>

            <div class="ct-achievement-overview">
                <article class="ct-achievement-overview-card ct-achievement-overview-card--primary">
                    <span class="ct-achievement-glass-icon"><span class="dashicons dashicons-chart-area"></span></span>
                    <div><small>TOTAL PENCAPAIAN</small><strong>IDR <?php echo esc_html(self::fmt_total($grand));?></strong><span>Akumulasi seluruh fase · <?php echo esc_html($year);?></span></div>
                </article>
                <article class="ct-achievement-overview-card">
                    <span class="ct-achievement-glass-icon"><span class="dashicons dashicons-awards"></span></span>
                    <div><small>KONTRIBUSI TERBESAR</small><strong><?php echo $highest?esc_html($highest['program']->name):'-';?></strong><span><?php echo $highest?'IDR '.esc_html(self::fmt_total($highest['value'])):'Belum ada data';?></span></div>
                </article>
                <article class="ct-achievement-overview-card">
                    <span class="ct-achievement-glass-icon"><span class="dashicons dashicons-screenoptions"></span></span>
                    <div><small>PROGRAM AKTIF</small><strong><?php echo esc_html(number_format_i18n(count($programs)));?></strong><span>Fase/program yang dimonitor</span></div>
                </article>
            </div>

            <div class="ct-achievement-section-head"><div><span>RINCIAN PENCAPAIAN</span><h2>Kontribusi per Fase</h2></div><p>Persentase dihitung terhadap total pencapaian tahun <?php echo esc_html($year);?>.</p></div>
            <?php if($items):?>
            <div class="ct-achievement-grid ct-achievement-grid--modern">
                <?php foreach($items as $item):
                    $p=$item['program']; $v=(float)$item['value']; $pct=$grand>0?min(100,max(0,($v/$grand)*100)):0;
                    $meta=$phaseMeta[$p->code]??array('class'=>'generic','icon'=>'chart-bar');
                ?>
                <article class="ct-achievement-card ct-achievement-card--<?php echo esc_attr($meta['class']);?>">
                    <div class="ct-achievement-card-head">
                        <span class="ct-achievement-glass-icon"><span class="dashicons dashicons-<?php echo esc_attr($meta['icon']);?>"></span></span>
                        <div><small><?php echo esc_html($p->phase_label?:'PROGRAM');?></small><h3><?php echo esc_html($p->name);?></h3></div>
                    </div>
                    <div class="ct-achievement-value"><span>IDR</span><strong><?php echo esc_html(self::fmt_total($v));?></strong></div>
                    <div class="ct-achievement-progress"><i style="width:<?php echo esc_attr(number_format($pct,2,'.',''));?>%"></i></div>
                    <div class="ct-achievement-card-foot"><span>Kontribusi</span><strong><?php echo esc_html(number_format($pct,1,',','.'));?>%</strong></div>
                </article>
                <?php endforeach;?>
            </div>
            <?php else:?><div class="ct-panel ct-achievement-empty"><span class="ct-achievement-glass-icon"><span class="dashicons dashicons-chart-bar"></span></span><h3>Belum ada program aktif</h3><p>Aktifkan program/fase terlebih dahulu agar pencapaian tahunan dapat ditampilkan.</p></div><?php endif;?>
        </section>
        <?php
    }
}
