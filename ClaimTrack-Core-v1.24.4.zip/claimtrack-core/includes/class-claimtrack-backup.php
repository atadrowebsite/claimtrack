<?php
if (!defined('ABSPATH')) { exit; }

class ClaimTrack_Backup {
    const FORMAT = 'claimtrack-backup';
    const FORMAT_VERSION = 5;
    const MAX_BYTES = 52428800; // 50 MB

    public static function build_payload() {
        global $wpdb;
        $t = ClaimTrack_DB::tables();
        $knowledge=array();
        foreach (get_posts(array('post_type'=>'ct_knowledge','post_status'=>'any','posts_per_page'=>-1,'orderby'=>array('menu_order'=>'ASC','ID'=>'ASC'))) as $post) {
            $cover_id=(int)get_post_meta($post->ID,'_claimtrack_knowledge_cover_id',true);
            if(!$cover_id){$cover_id=(int)get_post_thumbnail_id($post->ID);}
            $pdf_id=(int)get_post_meta($post->ID,'_claimtrack_knowledge_pdf_id',true);
            $knowledge[]=array(
                'title'=>$post->post_title,
                'content'=>$post->post_content,
                'status'=>$post->post_status,
                'menu_order'=>(int)$post->menu_order,
                'cover_id'=>$cover_id,
                'cover_url'=>$cover_id?(string)wp_get_attachment_url($cover_id):(string)get_post_meta($post->ID,'_claimtrack_knowledge_cover_url',true),
                'pdf_id'=>$pdf_id,
                'pdf_url'=>$pdf_id?(string)wp_get_attachment_url($pdf_id):(string)get_post_meta($post->ID,'_claimtrack_knowledge_pdf_url',true),
                'updated_at'=>(string)get_post_meta($post->ID,'_claimtrack_knowledge_updated_at',true),
            );
        }
        $news=array();
        foreach (get_posts(array('post_type'=>'ct_news','post_status'=>'any','posts_per_page'=>-1,'orderby'=>array('menu_order'=>'ASC','ID'=>'ASC'))) as $post) {
            $cover_id=(int)get_post_thumbnail_id($post->ID);
            $comments=array();
            foreach (get_comments(array('post_id'=>$post->ID,'status'=>'all','type'=>'comment','orderby'=>'comment_ID','order'=>'ASC')) as $comment) {
                $comments[]=array(
                    'author'=>(string)$comment->comment_author,
                    'author_email'=>(string)$comment->comment_author_email,
                    'content'=>(string)$comment->comment_content,
                    'date'=>(string)$comment->comment_date,
                    'date_gmt'=>(string)$comment->comment_date_gmt,
                    'approved'=>(string)$comment->comment_approved,
                    'user_id'=>(int)$comment->user_id,
                );
            }
            $news[]=array(
                'title'=>$post->post_title,
                'excerpt'=>$post->post_excerpt,
                'content'=>$post->post_content,
                'status'=>$post->post_status,
                'menu_order'=>(int)$post->menu_order,
                'featured'=>(int)get_post_meta($post->ID,'_claimtrack_news_featured',true),
                'cover_id'=>$cover_id,
                'cover_url'=>$cover_id?(string)wp_get_attachment_url($cover_id):'',
                'comments'=>$comments,
            );
        }
        return array(
            'format' => self::FORMAT,
            'format_version' => self::FORMAT_VERSION,
            'plugin_version' => defined('CLAIMTRACK_VERSION') ? CLAIMTRACK_VERSION : '',
            'db_version' => ClaimTrack_DB::DB_VERSION,
            'generated_at' => current_time('mysql'),
            'site_url' => home_url('/'),
            'settings' => get_option('claimtrack_settings', array()),
            'data' => array(
                'units' => $wpdb->get_results("SELECT * FROM {$t['units']} ORDER BY id", ARRAY_A),
                'programs' => $wpdb->get_results("SELECT * FROM {$t['programs']} ORDER BY id", ARRAY_A),
                'providers' => $wpdb->get_results("SELECT * FROM {$t['providers']} ORDER BY id", ARRAY_A),
                'entries' => $wpdb->get_results("SELECT * FROM {$t['entries']} ORDER BY id", ARRAY_A),
                'debitur' => $wpdb->get_results("SELECT * FROM {$t['debitur']} ORDER BY id", ARRAY_A),
                'knowledge' => $knowledge,
                'news' => $news,
                'monitoring' => ClaimTrack_Monitoring::backup(),
            ),
        );
    }

    public static function stream_backup() {
        $payload = self::build_payload();
        $json = wp_json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($json)) { wp_die('Backup ClaimTrack gagal dibuat.'); }
        $filename = 'claimtrack-backup-' . wp_date('Ymd-His') . '.json';
        nocache_headers();
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . strlen($json));
        echo $json; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        exit;
    }

    public static function restore_uploaded_file($file) {
        if (!is_array($file) || empty($file['tmp_name'])) {
            return new WP_Error('ct_restore_file', 'Pilih file backup ClaimTrack (.json).');
        }
        if (!empty($file['error'])) {
            return new WP_Error('ct_restore_upload', 'Upload file backup gagal.');
        }
        $name = sanitize_file_name((string)($file['name'] ?? ''));
        if (strtolower(pathinfo($name, PATHINFO_EXTENSION)) !== 'json') {
            return new WP_Error('ct_restore_type', 'File restore harus berformat .json hasil Backup ClaimTrack.');
        }
        $size = isset($file['size']) ? (int)$file['size'] : (is_file($file['tmp_name']) ? (int)filesize($file['tmp_name']) : 0);
        if ($size <= 0 || $size > self::MAX_BYTES) {
            return new WP_Error('ct_restore_size', 'Ukuran file backup tidak valid atau melebihi 50 MB.');
        }
        $raw = file_get_contents($file['tmp_name']);
        if ($raw === false || $raw === '') {
            return new WP_Error('ct_restore_read', 'File backup tidak dapat dibaca.');
        }
        $payload = json_decode($raw, true);
        $version=(int)($payload['format_version'] ?? 0);
        if (!is_array($payload) || ($payload['format'] ?? '') !== self::FORMAT || !in_array($version,array(1,2,3,4,self::FORMAT_VERSION),true)) {
            return new WP_Error('ct_restore_format', 'Format backup tidak dikenali atau versinya tidak didukung.');
        }
        if (empty($payload['data']) || !is_array($payload['data'])) {
            return new WP_Error('ct_restore_data', 'Backup tidak memiliki data ClaimTrack yang valid.');
        }
        foreach (array('units','programs','providers','entries','debitur') as $key) {
            if (!isset($payload['data'][$key]) || !is_array($payload['data'][$key])) {
                return new WP_Error('ct_restore_missing', 'Bagian data ' . $key . ' tidak ditemukan pada backup.');
            }
        }
        return self::restore_payload($payload);
    }

    private static function restore_payload($payload) {
        global $wpdb;
        $t = ClaimTrack_DB::tables();
        $now = current_time('mysql');
        $wpdb->query('START TRANSACTION');
        try {
            // Hapus dalam urutan aman. Tabel ClaimTrack tidak memakai FK database,
            // tetapi entries tetap diproses lebih dulu agar relasi logis konsisten.
            foreach (array('entries','providers','programs','units') as $key) {
                if ($wpdb->query("DELETE FROM {$t[$key]}") === false) {
                    throw new Exception($wpdb->last_error ?: 'Gagal membersihkan tabel ' . $key);
                }
            }

            foreach ($payload['data']['units'] as $row) {
                $data = array(
                    'id' => (int)($row['id'] ?? 0),
                    'code' => ClaimTrack_DB::normalize_code($row['code'] ?? ''),
                    'name' => sanitize_text_field((string)($row['name'] ?? '')),
                    'sort_order' => (int)($row['sort_order'] ?? 0),
                    'active' => !empty($row['active']) ? 1 : 0,
                    'created_at' => self::safe_datetime($row['created_at'] ?? '', $now),
                    'updated_at' => self::safe_datetime($row['updated_at'] ?? '', $now),
                );
                if ($data['id'] <= 0 || $data['code'] === '' || $data['name'] === '' || $wpdb->insert($t['units'], $data) === false) {
                    throw new Exception($wpdb->last_error ?: 'Data Unit Kerja pada backup tidak valid.');
                }
            }
            foreach ($payload['data']['programs'] as $row) {
                $data = array(
                    'id' => (int)($row['id'] ?? 0),
                    'code' => ClaimTrack_DB::normalize_code($row['code'] ?? ''),
                    'phase_label' => sanitize_text_field((string)($row['phase_label'] ?? '')),
                    'name' => sanitize_text_field((string)($row['name'] ?? '')),
                    'color' => sanitize_hex_color((string)($row['color'] ?? '#23b653')) ?: '#23b653',
                    'dashboard_order' => (int)($row['dashboard_order'] ?? 0),
                    'show_dashboard' => !empty($row['show_dashboard']) ? 1 : 0,
                    'active' => !empty($row['active']) ? 1 : 0,
                    'created_at' => self::safe_datetime($row['created_at'] ?? '', $now),
                    'updated_at' => self::safe_datetime($row['updated_at'] ?? '', $now),
                );
                if ($data['id'] <= 0 || $data['code'] === '' || $data['name'] === '' || $wpdb->insert($t['programs'], $data) === false) {
                    throw new Exception($wpdb->last_error ?: 'Data Program pada backup tidak valid.');
                }
            }
            foreach ($payload['data']['providers'] as $row) {
                $data = array(
                    'id' => (int)($row['id'] ?? 0),
                    'code' => ClaimTrack_DB::normalize_code($row['code'] ?? ''),
                    'name' => sanitize_text_field((string)($row['name'] ?? '')),
                    'sort_order' => (int)($row['sort_order'] ?? 0),
                    'active' => !empty($row['active']) ? 1 : 0,
                    'created_at' => self::safe_datetime($row['created_at'] ?? '', $now),
                    'updated_at' => self::safe_datetime($row['updated_at'] ?? '', $now),
                );
                if ($data['id'] <= 0 || $data['code'] === '' || $data['name'] === '' || $wpdb->insert($t['providers'], $data) === false) {
                    throw new Exception($wpdb->last_error ?: 'Data Mitra pada backup tidak valid.');
                }
            }

            $valid_units = array_fill_keys(array_map('intval', wp_list_pluck($payload['data']['units'], 'id')), true);
            $valid_programs = array_fill_keys(array_map('intval', wp_list_pluck($payload['data']['programs'], 'id')), true);
            $valid_providers = array_fill_keys(array_map('intval', wp_list_pluck($payload['data']['providers'], 'id')), true);
            foreach ($payload['data']['entries'] as $row) {
                $unit_id = (int)($row['unit_id'] ?? 0);
                $program_id = (int)($row['program_id'] ?? 0);
                $provider_id = (int)($row['provider_id'] ?? 0);
                $year = (int)($row['year'] ?? 0);
                $month = (int)($row['month'] ?? 0);
                $week = (int)($row['week'] ?? 0);
                if (empty($valid_units[$unit_id]) || empty($valid_programs[$program_id]) || empty($valid_providers[$provider_id]) || $year < 2000 || $year > 2100 || $month < 1 || $month > 12 || $week < 1 || $week > 4) {
                    throw new Exception('Relasi atau periode data klaim pada backup tidak valid.');
                }
                $data = array(
                    'id' => (int)($row['id'] ?? 0),
                    'unit_id' => $unit_id,
                    'program_id' => $program_id,
                    'provider_id' => $provider_id,
                    'year' => $year,
                    'month' => $month,
                    'week' => $week,
                    'amount_million' => (float)($row['amount_million'] ?? 0),
                    'note' => sanitize_text_field((string)($row['note'] ?? '')),
                    'created_at' => self::safe_datetime($row['created_at'] ?? '', $now),
                    'updated_at' => self::safe_datetime($row['updated_at'] ?? '', $now),
                );
                if ($data['id'] <= 0 || $wpdb->insert($t['entries'], $data) === false) {
                    throw new Exception($wpdb->last_error ?: 'Data klaim pada backup gagal dipulihkan.');
                }
            }


            if(isset($payload['data']['debitur']) && is_array($payload['data']['debitur'])){
                foreach($payload['data']['debitur'] as $row){
                    $wpdb->insert($t['debitur'],array(
                        'id'=>(int)($row['id']??0),'unit_id'=>(int)($row['unit_id']??0),
                        'program_id'=>(int)($row['program_id']??0),'provider_id'=>(int)($row['provider_id']??0),
                        'nama_nasabah'=>sanitize_text_field($row['nama_nasabah']??''),
                        'nomor_klaim'=>sanitize_text_field($row['nomor_klaim']??''),
                        'amount_million'=>(float)($row['amount_million']??0),
                        'status_klaim'=>sanitize_text_field($row['status_klaim']??'Dalam Proses'),
                        'created_at'=>self::safe_datetime($row['created_at']??'', $now),
                        'updated_at'=>self::safe_datetime($row['updated_at']??'', $now)
                    ));
                }
            }

            if (isset($payload['settings']) && is_array($payload['settings'])) {
                $current = get_option('claimtrack_settings', array());
                $settings = wp_parse_args($payload['settings'], is_array($current) ? $current : array());
                update_option('claimtrack_settings', $settings, false);
            }
            $wpdb->query('COMMIT');
        } catch (Throwable $e) {
            $wpdb->query('ROLLBACK');
            return new WP_Error('ct_restore_failed', 'Restore dibatalkan. ' . $e->getMessage());
        }

        $knowledge_count=0;
        if (isset($payload['data']['knowledge']) && is_array($payload['data']['knowledge'])) {
            $knowledge_result=self::restore_knowledge($payload['data']['knowledge']);
            if (is_wp_error($knowledge_result)) { return $knowledge_result; }
            $knowledge_count=(int)$knowledge_result;
        }

        $news_count=0;
        if (isset($payload['data']['news']) && is_array($payload['data']['news'])) {
            $news_result=self::restore_news($payload['data']['news']);
            if (is_wp_error($news_result)) { return $news_result; }
            $news_count=(int)$news_result;
        }

        if (isset($payload['data']['monitoring'])) {
            $monitoring_result=ClaimTrack_Monitoring::restore($payload['data']['monitoring']);
            if(is_wp_error($monitoring_result)) { return $monitoring_result; }
        }
        ClaimTrack_DB::mark_cpt_sync_dirty();
        ClaimTrack_DB::sync_cpt_mirror(true);
        ClaimTrack_DB::ensure_app_pages();
        return array(
            'units' => count($payload['data']['units']),
            'programs' => count($payload['data']['programs']),
            'providers' => count($payload['data']['providers']),
            'entries' => count($payload['data']['entries']),
            'knowledge' => $knowledge_count,
            'news' => $news_count,
        );
    }

    private static function restore_knowledge($rows) {
        foreach (get_posts(array('post_type'=>'ct_knowledge','post_status'=>'any','posts_per_page'=>-1,'fields'=>'ids')) as $id) { wp_delete_post((int)$id,true); }
        $count=0;
        foreach ($rows as $row) {
            $title=sanitize_text_field((string)($row['title'] ?? ''));
            if ($title==='') { continue; }
            $post_id=wp_insert_post(array(
                'post_type'=>'ct_knowledge','post_status'=>'publish','post_title'=>$title,
                'post_content'=>wp_kses_post((string)($row['content'] ?? '')),'menu_order'=>(int)($row['menu_order'] ?? 0),
            ),true);
            if (is_wp_error($post_id)) { return new WP_Error('ct_restore_knowledge','E-Knowledge gagal dipulihkan. '.$post_id->get_error_message()); }
            $post_id=(int)$post_id;
            $cover_id=(int)($row['cover_id'] ?? 0);
            $pdf_id=(int)($row['pdf_id'] ?? 0);
            if ($cover_id>0 && get_post($cover_id)) { update_post_meta($post_id,'_claimtrack_knowledge_cover_id',$cover_id); set_post_thumbnail($post_id,$cover_id); }
            if ($pdf_id>0 && get_post($pdf_id)) { update_post_meta($post_id,'_claimtrack_knowledge_pdf_id',$pdf_id); }
            if (!empty($row['cover_url'])) { update_post_meta($post_id,'_claimtrack_knowledge_cover_url',esc_url_raw((string)$row['cover_url'])); }
            if (!empty($row['pdf_url'])) { update_post_meta($post_id,'_claimtrack_knowledge_pdf_url',esc_url_raw((string)$row['pdf_url'])); }
            update_post_meta($post_id,'_claimtrack_knowledge_sort',(int)($row['menu_order'] ?? 0));
            update_post_meta($post_id,'_claimtrack_knowledge_updated_at',sanitize_text_field((string)($row['updated_at'] ?? current_time('mysql'))));
            $count++;
        }
        return $count;
    }

    private static function restore_news($rows) {
        foreach (get_posts(array('post_type'=>'ct_news','post_status'=>'any','posts_per_page'=>-1,'fields'=>'ids')) as $id) { wp_delete_post((int)$id,true); }
        $count=0;
        foreach ($rows as $row) {
            $title=sanitize_text_field((string)($row['title'] ?? ''));
            if ($title==='') { continue; }
            $post_id=wp_insert_post(array(
                'post_type'=>'ct_news','post_status'=>'publish','post_title'=>$title,
                'post_excerpt'=>sanitize_textarea_field((string)($row['excerpt'] ?? '')),
                'post_content'=>wp_kses_post((string)($row['content'] ?? '')),'menu_order'=>(int)($row['menu_order'] ?? 0),
                'comment_status'=>'open',
            ),true);
            if (is_wp_error($post_id)) { return new WP_Error('ct_restore_news','Berita gagal dipulihkan. '.$post_id->get_error_message()); }
            $post_id=(int)$post_id;
            update_post_meta($post_id,'_claimtrack_news_featured',!empty($row['featured'])?1:0);
            $cover_id=(int)($row['cover_id'] ?? 0);
            if ($cover_id>0 && get_post($cover_id)) { set_post_thumbnail($post_id,$cover_id); }
            if (!empty($row['comments']) && is_array($row['comments'])) {
                foreach ($row['comments'] as $comment) {
                    $content=trim(sanitize_textarea_field((string)($comment['content'] ?? '')));
                    if ($content==='') { continue; }
                    $user_id=(int)($comment['user_id'] ?? 0);
                    if ($user_id>0 && !get_user_by('id',$user_id)) { $user_id=0; }
                    wp_insert_comment(array(
                        'comment_post_ID'=>$post_id,
                        'comment_author'=>sanitize_text_field((string)($comment['author'] ?? 'Karyawan')),
                        'comment_author_email'=>sanitize_email((string)($comment['author_email'] ?? '')),
                        'comment_content'=>$content,
                        'comment_type'=>'comment',
                        'comment_parent'=>0,
                        'user_id'=>$user_id,
                        'comment_approved'=>in_array((string)($comment['approved'] ?? '1'),array('0','1','spam','trash'),true)?(string)($comment['approved'] ?? '1'):'1',
                        'comment_date'=>self::safe_datetime($comment['date'] ?? '',current_time('mysql')),
                        'comment_date_gmt'=>self::safe_datetime($comment['date_gmt'] ?? '',current_time('mysql',true)),
                    ));
                }
            }
            $count++;
        }
        return $count;
    }

    private static function safe_datetime($value, $fallback) {
        $value = trim((string)$value);
        if ($value !== '' && preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $value)) { return $value; }
        return $fallback;
    }
}
