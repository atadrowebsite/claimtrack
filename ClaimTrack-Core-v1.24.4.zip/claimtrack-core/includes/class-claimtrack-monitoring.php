<?php
if (!defined('ABSPATH')) { exit; }

/** Private per-record storage; all writes pass through ClaimTrack_App's capability + nonce gate. */
class ClaimTrack_Monitoring {
    public static function modules() {
        $common = array('reference'=>array('No. klaim / referensi','text'), 'debtor'=>array('Nama debitur','text'), 'unit'=>array('Unit kerja','text'), 'provider'=>array('Mitra / asuradur','text'), 'amount'=>array('Nominal (juta rupiah)','number'));
        $rejected = array(
            'area_head'=>array('Area Head',array('Area Head 1','Area Head 2','Area Head 3')),
            'bo'=>array('BO','text'),
            'unit'=>array('Uker','text'),
            'debtor'=>array('Nama Nasabah','text'),
            'account'=>array('No Rek','text'),
            'provider'=>array('Asuradur','text'),
            'policy'=>array('Policy','text'),
            'amount'=>array('Nilai Klaim (rupiah)','number'),
            'rejected'=>array('LastDate','date'),
            'reason'=>array('Alasan penolakan',array('Dokumen tidak lengkap','Lewat batas waktu','Tidak memenuhi ketentuan','Ketidaksesuaian data','Lainnya')),
            'status'=>array('Tindak lanjut',array('Belum ditindaklanjuti','Dalam review','Keberatan diajukan','Ditutup')),
            'owner'=>array('PIC','text'),
            'note'=>array('Catatan tindak lanjut','textarea'),
        );
        return array(
            'monitoring-tempo'=>array('title'=>'Monitoring Jt Tempo Klaim','intro'=>'Pantau batas waktu klaim dan prioritaskan tindak lanjut.','fields'=>$common+array('submitted'=>array('Tanggal pengajuan','date'),'due'=>array('Jatuh tempo','date'),'status'=>array('Status',array('Dalam proses','Dokumen lengkap','Selesai')),'owner'=>array('PIC','text'),'note'=>array('Tindak lanjut','textarea'))),
            'monitoring-pra-klaim'=>array('title'=>'Monitoring Pra Klaim','intro'=>'Kesiapan dokumen dan potensi pengajuan dalam satu tampilan.','fields'=>$common+array('period'=>array('Periode','month'),'collectibility'=>array('Kolektibilitas',array('Kol 2','Kol 3','Kol 4','Kol 5')),'progress'=>array('Kelengkapan dokumen (%)','number'),'due'=>array('Target pengajuan','date'),'status'=>array('Status',array('Pengumpulan dokumen','Verifikasi','Siap diajukan','Diajukan')),'owner'=>array('PIC','text'),'note'=>array('Dokumen kurang / tindak lanjut','textarea'))),
            'best-performance'=>array('title'=>'Best Performance','intro'=>'Peringkat unit berdasarkan realisasi terhadap target pada periode terpilih.','fields'=>array('unit'=>array('Unit kerja','text'),'period'=>array('Periode','month'),'target'=>array('Target (juta rupiah)','number'),'amount'=>array('Realisasi (juta rupiah)','number'),'cases'=>array('Jumlah klaim selesai','number'),'sla'=>array('Penyelesaian tepat waktu (%)','number'),'owner'=>array('PIC','text'),'note'=>array('Catatan','textarea'))),
            'klaim-ditolak-2025'=>array('title'=>'Klaim Ditolak 2025','intro'=>'Arsip penolakan tahun 2025 beserta alasan dan progres keberatan.','fields'=>$rejected),
        );
    }
    public static function bootstrap() {
        register_post_type('ct_monitor_record',array('public'=>false,'show_ui'=>false,'show_in_rest'=>false,'rewrite'=>false,'supports'=>array('title'),'can_export'=>true));
        self::migrate_rejected_2025_demo();
        if (get_option('claimtrack_monitoring_seed_v1')) { return; }
        // A unique option lock prevents concurrent first requests from duplicating demo rows.
        $lock=(int)get_option('claimtrack_monitoring_seed_lock');
        if($lock && time()-$lock>300) { delete_option('claimtrack_monitoring_seed_lock'); }
        if (!add_option('claimtrack_monitoring_seed_lock',time(),'','no')) { return; }
        $ok=true;
        foreach(self::modules() as $module=>$config) {
            if(self::rows($module)) { continue; }
            for($i=0;$i<4;$i++) {
                $day=wp_date('Y-m-d',current_time('timestamp')+($i-1)*7*DAY_IN_SECONDS);
                $row=array('reference'=>'DEMO-'.strtoupper(substr(md5($module),0,3)).'-00'.($i+1),'debtor'=>'Debitur Contoh '.($i+1),'unit'=>array('Unit Jakarta','Unit Bekasi','Unit Bogor','Unit Depok')[$i],'provider'=>array('Asuradur A','Asuradur B')[$i%2],'amount'=>array(850,640,420,280)[$i],'submitted'=>wp_date('Y-m-d',current_time('timestamp')-30*DAY_IN_SECONDS),'due'=>$day,'period'=>wp_date('Y-m'),'collectibility'=>'Kol '.($i+2),'progress'=>array(45,70,100,85)[$i],'target'=>array(700,600,500,400)[$i],'cases'=>array(12,10,8,5)[$i],'sla'=>array(98,95,92,88)[$i],'rejected'=>'2025-'.str_pad($i+6,2,'0',STR_PAD_LEFT).'-15','reason'=>array('Dokumen tidak lengkap','Lewat batas waktu','Tidak memenuhi ketentuan','Ketidaksesuaian data')[$i],'owner'=>'PIC Contoh '.($i+1),'note'=>'Data contoh untuk demonstrasi. Silakan ganti dengan data aktual.','demo'=>1);
                if(isset($config['fields']['status'])) { $row['status']=$config['fields']['status'][1][$i%count($config['fields']['status'][1])]; }
                $id=self::write($module,$row);
                if(is_wp_error($id)) { $ok=false; }
            }
        }
        if($ok) { update_option('claimtrack_monitoring_seed_v1',1,false); }
        delete_option('claimtrack_monitoring_seed_lock');
        self::migrate_rejected_2025_demo();
    }

    /**
     * Upgrade the old generic rejected-claim demo into the reference dataset.
     * Actual rows are never replaced; only an empty menu or clearly-marked demo
     * rows are eligible for this migration.
     */
    private static function migrate_rejected_2025_demo() {
        if ((string)get_option('claimtrack_rejected_2025_layout_version','') === '2') { return; }
        $rows=self::rows('klaim-ditolak-2025');
        $replace=empty($rows);
        if($rows){
            $replace=true;
            foreach($rows as $row){
                if(empty($row['demo']) || (strpos((string)($row['debtor']??''),'Debitur Contoh')===false && strpos((string)($row['reference']??''),'DEMO-')===false)){ $replace=false; break; }
            }
        }
        if(!$replace){
            // Keep older actual rows visible after the schema expands.
            foreach($rows as $row){
                $normalized=$row;
                $normalized['area_head']=$normalized['area_head']??'Area Head 1';
                $normalized['bo']=$normalized['bo']??($normalized['unit']??'');
                $normalized['account']=$normalized['account']??($normalized['reference']??'');
                $normalized['policy']=$normalized['policy']??'';
                self::write('klaim-ditolak-2025',$normalized,(int)($normalized['id']??0));
            }
            update_option('claimtrack_rejected_2025_layout_version','2',false);
            return;
        }
        foreach($rows as $row){ if(!empty($row['id'])){ wp_delete_post((int)$row['id'],true); } }
        $data=array(
            array('Area Head 1','Merauke','Unit Mandala','Nurmi','498401016704101','BRINS','00000.04984.2024.02.00001.1.Z.N',60922333,'2025-03-13'),
            array('Area Head 1','Sentani','Unit Sentani','Daimo','362501029473100','Askrindo','048.1402.2300001546/000',15075542,'2025-05-05'),
            array('Area Head 1','Sentani','Unit Bongo','Agripina Luruk','794401004683106','Askrindo','048.1402.2300002559/000',38699131,'2025-03-26'),
            array('Area Head 1','Sentani','BO Sentani','Romanus Purba','108201000866150','BSM','00000.01082.2024.07.00004.1.1',368258462,'2025-09-16'),
            array('Area Head 1','Abepura','BO Abepura','Edi Sunyoto','44601000462159','BSM','00000.00446.2024.03.00008.1.1',797183767,'2025-07-31'),
            array('Area Head 1','Abepura','SBO Waena','Luis Roring Ponto','214201000504159','BSM','00000.02142.2023.01.00005.1.1',599626796,'2025-07-31'),
            array('Area Head 1','Jayapura','Unit Entrop','Debrand Way','491401024373105','Askrindo','048.1402.2300000925/000',5343569,'2025-01-21'),
            array('Area Head 1','Jayapura','SBO Kota','Lenna','214101000389157','BSM','00000.02141.2023.11.00003.1.1',264305256,'2025-02-10'),
            array('Area Head 2','Serui','Unit Waropen','Yasinta Seuk','505401009285104','Askrindo','048.1402.2300002238/000',21558452,'2025-02-24'),
            array('Area Head 2','Serui','BO Serui','Hermang','30901501086157','BSM','00000.00309.2023.09.00003.1.1',83916032,'2025-05-05'),
            array('Area Head 2','Serui','BO Serui','Akkas','30901500222158','BSM','00000.00309.2024.03.00001.1.1',2337463686,'2025-04-29'),
            array('Area Head 3','Biak','Unit Samofa','Henci Rumkorem','489701018257107','Askrindo','048.1402.2300001495/000',18721942,'2025-03-11'),
            array('Area Head 3','Sorong','SBO Aimas','Sutrino','206401000804157','BSM','00000.02064.2023.06.00004.1.1',309254972,'2025-10-29'),
            array('Area Head 3','Fakfak','Unit Kaimana','Halmiah','489401013838100','Askrindo','047.1402.2300000451/000',41861951,'2025-11-18'),
            array('Area Head 3','Fakfak','BO Fakfak','Karolus Boromeus','108101000500158','BSM','00000.01081.2023.09.00006.1.1',340488565,'2025-07-10'),
            array('Area Head 3','Fakfak','BO Fakfak','Yuliani','108101000686158','BSM','00000.01081.2022.10.00003.1.1',135676290,'2025-06-04'),
            array('Area Head 3','Fakfak','BO Fakfak','Ricky Wijaya','108101000387152','BSM','00000.01081.2023.08.00012.1.1',70489008,'2025-09-11'),
            array('Area Head 3','Bintuni','BO Bintuni','Sumarno Ariri','108010010602150','BSM','B01.1080.2021.01.00101.DL',55508704,'2025-06-17'),
            array('Area Head 3','Manokwari','Unit Ransiki','Ahmad Jauri','496201008814104','Askrindo','047.1402.2300000988/000',50359265,'2025-11-18'),
            array('Area Head 3','Manokwari','Unit Prafi','Ratna Iriyani','495901011938104','BRINS','00000.04959.2023.02.00007.4C.2.N',11468056,'2025-05-26'),
        );
        foreach($data as $item){
            self::write('klaim-ditolak-2025',array(
                'area_head'=>$item[0],'bo'=>$item[1],'unit'=>$item[2],'debtor'=>$item[3],'account'=>$item[4],
                'provider'=>$item[5],'policy'=>$item[6],'amount'=>(float)$item[7],'rejected'=>$item[8],
                'reason'=>'Tidak memenuhi ketentuan','status'=>'Belum ditindaklanjuti','owner'=>'','note'=>'','demo'=>1,
            ));
        }
        update_option('claimtrack_rejected_2025_layout_version','2',false);
    }
    public static function rows($module) {
        $rows=array();
        foreach(get_posts(array('post_type'=>'ct_monitor_record','post_status'=>'private','posts_per_page'=>-1,'orderby'=>'ID','order'=>'DESC','meta_key'=>'_ct_module','meta_value'=>$module)) as $post) {
            $row=json_decode($post->post_content,true);
            if(is_array($row)) { $row['id']=$post->ID; $rows[]=$row; }
        }
        return $rows;
    }
    private static function write($module,$row,$id=0) {
        unset($row['id']);
        return wp_insert_post(wp_slash(array('ID'=>$id,'post_type'=>'ct_monitor_record','post_status'=>'private','post_title'=>$module.' / '.($row['reference'] ?? $row['unit']),'post_content'=>wp_json_encode($row,JSON_UNESCAPED_UNICODE),'meta_input'=>array('_ct_module'=>$module))),true);
    }
    public static function validate($module,$input) {
        $config=self::modules()[$module] ?? null;
        if(!$config) { return new WP_Error('module','Menu tidak valid.'); }
        $row=array();
        foreach($config['fields'] as $key=>$field) {
            $value=$input[$key] ?? '';
            if(!is_scalar($value)) { return new WP_Error('field','Format '.$field[0].' tidak valid.'); }
            $value=trim((string)$value); $type=$field[1];
            if($key!=='note' && $value==='') { return new WP_Error('required',$field[0].' wajib diisi.'); }
            if(is_array($type) && !in_array($value,$type,true)) { return new WP_Error('choice',$field[0].' tidak valid.'); }
            if($type==='number') {
                if(!preg_match('/^\d+(\.\d{1,2})?$/D',$value) || !is_finite((float)$value) || (float)$value>999999999999) { return new WP_Error('number',$field[0].': gunakan angka positif dengan maksimal dua desimal (contoh 1250.50).'); }
                if(in_array($key,array('progress','sla'),true) && (float)$value>100) { return new WP_Error('percent',$field[0].' maksimal 100.'); }
                if($key==='target' && (float)$value<=0) { return new WP_Error('target','Target harus lebih besar dari nol.'); }
                if($key==='cases' && floor((float)$value)!=(float)$value) { return new WP_Error('cases','Jumlah klaim harus bilangan bulat.'); }
                $value=(float)$value;
            }
            if($type==='date' || $type==='month') {
                $date=$type==='month'?$value.'-01':$value;
                $d=DateTimeImmutable::createFromFormat('!Y-m-d',$date);
                if(!$d || $d->format('Y-m-d')!==$date) { return new WP_Error('date',$field[0].' tidak valid.'); }
                if($key==='rejected' && substr($value,0,4)!=='2025') { return new WP_Error('year','Tanggal penolakan harus di tahun 2025.'); }
            }
            $row[$key]=$type==='textarea'?sanitize_textarea_field($value):sanitize_text_field((string)$value);
        }
        if($module==='monitoring-tempo' && $row['due']<$row['submitted']) { return new WP_Error('due','Jatuh tempo tidak boleh sebelum tanggal pengajuan.'); }
        $row['demo']=empty($input['demo'])?0:1;
        return $row;
    }
    public static function mutate($module,$action) {
        if(!isset(self::modules()[$module])) { return new WP_Error('module','Menu tidak valid.'); }
        $id=absint($_POST['id'] ?? 0);
        if($id && (get_post_type($id)!=='ct_monitor_record' || get_post_meta($id,'_ct_module',true)!==$module)) { return new WP_Error('record','Data tidak ditemukan pada menu ini.'); }
        if($action==='monitoring_delete') { return $id && wp_delete_post($id,true) ? true : new WP_Error('delete','Data gagal dihapus.'); }
        $row=self::validate($module,wp_unslash($_POST));
        if(is_wp_error($row)) { set_transient('ct_mon_draft_'.get_current_user_id().'_'.$module,array('input'=>wp_unslash($_POST),'id'=>$id),300); return $row; }
        return self::write($module,$row,$id);
    }
    public static function backup() {
        $data=array(); foreach(self::modules() as $module=>$c) { $data[$module]=self::rows($module); } return $data;
    }
    public static function restore($data) {
        if(!is_array($data)) { return new WP_Error('monitoring','Backup monitoring tidak valid.'); }
        $validated=array();
        foreach($data as $module=>$rows) {
            if(!isset(self::modules()[$module]) || !is_array($rows)) { return new WP_Error('monitoring','Menu backup monitoring tidak valid.'); }
            foreach($rows as $row) {
                if(!is_array($row)) { return new WP_Error('monitoring','Baris monitoring tidak valid.'); }
                if($module==='klaim-ditolak-2025'){
                    // Backward compatibility for backups made before the reference columns existed.
                    $row['area_head']=$row['area_head']??'Area Head 1';
                    $row['bo']=$row['bo']??($row['unit']??'-');
                    $row['account']=$row['account']??($row['reference']??'-');
                    $row['policy']=$row['policy']??'-';
                }
                $v=self::validate($module,$row); if(is_wp_error($v)){return $v;} $validated[$module][]=$v;
            }
        }
        $old=array(); $created=array();
        foreach($data as $module=>$rows) {
            foreach(self::rows($module) as $r){$old[]=$r['id'];}
            foreach($validated[$module] ?? array() as $r) {
                $id=self::write($module,$r);
                if(is_wp_error($id)){foreach($created as $new){wp_delete_post($new,true);}return $id;}
                $created[]=$id;
            }
        }
        foreach($old as $id){wp_delete_post($id,true);}
        update_option('claimtrack_monitoring_seed_v1',1,false);
        return count($created);
    }
    private static function selected_rows($module) {
        $q=isset($_GET['mq']) && is_scalar($_GET['mq'])?sanitize_text_field(wp_unslash($_GET['mq'])):'';
        $period=isset($_GET['mperiod']) && is_scalar($_GET['mperiod'])?sanitize_text_field(wp_unslash($_GET['mperiod'])):'';
        $rows=array_values(array_filter(self::rows($module),function($r)use($q,$period,$module){
            $date=$r['period'] ?? substr($r[$module==='klaim-ditolak-2025'?'rejected':'due'] ?? '',0,7);
            return (!$period || $date===$period) && (!$q || stripos(implode(' ',array_map('strval',$r)),$q)!==false);
        }));
        if($module==='best-performance') { usort($rows,function($a,$b){ return self::score($b)<=>self::score($a); }); }
        if($module==='monitoring-tempo') { usort($rows,function($a,$b){ return strcmp($a['due'],$b['due']); }); }
        if($module==='klaim-ditolak-2025') {
            $headOrder=array('Area Head 1'=>1,'Area Head 2'=>2,'Area Head 3'=>3);
            usort($rows,function($a,$b)use($headOrder){
                $ha=$headOrder[$a['area_head']??'']??99; $hb=$headOrder[$b['area_head']??'']??99;
                return $ha===$hb ? ((int)($a['id']??0)<=> (int)($b['id']??0)) : ($ha<=>$hb);
            });
        }
        return $rows;
    }
    private static function score($r) { return (float)($r['target'] ?? 0)>0?(float)$r['amount']/(float)$r['target']*100:0; }
    private static function deadline($r) {
        if($r['status']==='Selesai') { return 'Selesai'; }
        $days=(int)(new DateTimeImmutable(wp_date('Y-m-d')))->diff(new DateTimeImmutable($r['due']))->format('%r%a');
        return $days<0?'Lewat '.abs($days).' hari':($days===0?'Jatuh tempo hari ini':'H−'.$days);
    }
    public static function report($module) {
        $c=self::modules()[$module]; $headers=array_values(array_map(function($f){return $f[0];},$c['fields'])); $headers[]='Sumber';
        if($module==='best-performance') { $headers[]='Capaian (%)'; }
        if($module==='monitoring-tempo') { $headers[]='Sisa waktu'; }
        $data=array();
        foreach(self::selected_rows($module) as $r) {
            $line=array(); foreach($c['fields'] as $k=>$f) { $line[]=$r[$k] ?? ''; }
            $line[]=empty($r['demo'])?'Aktual':'Contoh';
            if($module==='best-performance') { $line[]=round(self::score($r),2); }
            if($module==='monitoring-tempo') { $line[]=self::deadline($r); }
            $data[]=$line;
        }
        return array('title'=>$c['title'],'subtitle'=>$module==='klaim-ditolak-2025'?'Nilai klaim dalam Rupiah • Data contoh diberi penanda':'Nominal dalam juta rupiah • Data contoh diberi penanda','headers'=>$headers,'rows'=>$data,'slug'=>$module,'sheet'=>substr($c['title'],0,31));
    }
    private static function render_phase_summary($module,$rows) {
        $units=array(); $groups=array();
        foreach($rows as $r) {
            $name=$r['unit'];
            if(!isset($units[$name])) { $units[$name]=array('count'=>0,'amount'=>0); }
            $units[$name]['count']++; $units[$name]['amount']+=(float)$r['amount'];
            $group=$module==='best-performance'?($r['period'] ?? 'Tanpa periode'):($r['status'] ?? 'Tanpa status');
            $groups[$group]=($groups[$group] ?? 0)+(float)$r['amount'];
        }
        $unitAmounts=array_map(function($u){return $u['amount'];},$units);
        ?>
        <div class="ct-mon-phase-grid">
          <div class="ct-mon-phase-block"><h3 class="ct-kdp-section-title">POSISI KLAIM PER UNIT KERJA</h3><div class="ct-mon-panel ct-mon-summary-panel"><div class="ct-mon-table ct-mon-summary-scroll" tabindex="0" role="region" aria-label="Ringkasan per unit kerja"><table class="ct-mon-summary"><thead><tr><th>No.</th><th>Unit kerja</th><th>Data</th><th>Nominal (juta)</th></tr></thead><tbody>
          <?php $i=0; foreach($units as $name=>$u): ?><tr><td><?php echo ++$i; ?></td><td><?php echo esc_html($name); ?></td><td><?php echo (int)$u['count']; ?></td><td><?php echo esc_html(number_format($u['amount'],2,',','.')); ?></td></tr><?php endforeach; ?>
          <?php if(!$units): ?><tr><td colspan="4">Belum ada data sesuai filter.</td></tr><?php endif; ?>
          </tbody><tfoot><tr><th colspan="2">TOTAL</th><th><?php echo count($rows); ?></th><th><?php echo esc_html(number_format(array_sum($unitAmounts),2,',','.')); ?></th></tr></tfoot></table></div></div></div>
          <?php self::render_donut($groups,$module==='best-performance'?'NOMINAL PER PERIODE':'NOMINAL PER STATUS'); self::render_donut($unitAmounts,'NOMINAL PER UNIT KERJA'); ?>
        </div>
        <?php
    }
    private static function render_donut($values,$title) {
        arsort($values); $total=array_sum($values);
        // Keep legends readable on large installations while preserving the total.
        $items=array(); $rest=0; $i=0;
        foreach($values as $name=>$value) { if($i++<5){$items[]=array('name'=>$name,'value'=>$value);}else{$rest+=$value;} }
        if(count($values)>5){$items[]=array('name'=>'Unit / kategori lainnya','value'=>$rest);}
        $colors=array('#19a65a','#168ee0','#efad36','#7954ba','#e66f59','#71849a');$stops=array();$offset=0;
        foreach($items as $i=>$item){$end=$offset+($total>0?$item['value']/$total*100:0);$stops[]=$colors[$i].' '.round($offset,4).'% '.round($end,4).'%';$offset=$end;}
        $gradient=$total>0?'conic-gradient('.implode(',',$stops).')':'#dfe6ef';
        ?>
        <div class="ct-mon-phase-block"><h3 class="ct-kdp-section-title"><?php echo esc_html($title); ?></h3><div class="ct-mon-panel ct-mon-chart-panel"><div class="ct-mon-donut" style="background:<?php echo esc_attr($gradient); ?>" role="img" aria-label="<?php echo esc_attr($title.'. Total '.number_format($total,2,',','.').' juta rupiah. Rincian persentase ada di legenda.'); ?>"><div><small>TOTAL (JUTA)</small><strong><?php echo esc_html(number_format($total,2,',','.')); ?></strong></div></div><ul class="ct-mon-legend"><?php foreach($items as $i=>$item): ?><li><span class="ct-mon-swatch" style="background:<?php echo esc_attr($colors[$i]); ?>"></span><span><?php echo esc_html($item['name']); ?></span><b><?php echo esc_html(number_format($total>0?$item['value']/$total*100:0,1,',','.')); ?>%</b></li><?php endforeach; ?></ul><?php if($total<=0): ?><p class="ct-mon-chart-empty">Belum ada nominal untuk ditampilkan.</p><?php endif; ?></div></div>
        <?php
    }
    private static function render_rejected_chart($items,$total) {
        $colors=array('#18a566','#168dd4','#efad36','#7954ba','#e66f59','#71849a');
        $stops=array(); $offset=0; $i=0;
        foreach($items as $name=>$value){ $end=$offset+($total>0?((float)$value/$total*100):0); $stops[]=$colors[$i].' '.round($offset,4).'% '.round($end,4).'%'; $offset=$end; $i++; }
        $gradient=$total>0?'conic-gradient('.implode(',',$stops).')':'#dce3ea';
        $center=$total>0?number_format($total/1000000000,3,'.','.'):'0.000';
        echo '<article class="ct-rejected-chart-card"><div class="ct-rejected-donut" style="background:'.esc_attr($gradient).'"><div class="ct-rejected-donut-hole"><span>TOTAL (JUTA)</span><strong>'.esc_html($center).'</strong></div></div><ul class="ct-rejected-legend">';
        $i=0; foreach($items as $name=>$value){ $percent=$total>0?((float)$value/$total*100):0; echo '<li><i style="background:'.esc_attr($colors[$i]).'"></i><span>'.esc_html($name).'</span><b>'.esc_html(number_format($percent,1,',','.')).'%</b></li>'; $i++; }
        if(!$items){ echo '<li class="is-empty">Belum ada data</li>'; }
        echo '</ul></article>';
    }
    private static function render_rejected_2025($admin,$url) {
        $module='klaim-ditolak-2025'; $c=self::modules()[$module]; $rows=self::selected_rows($module); $editing=array();
        if($admin && !empty($_GET['edit'])){ foreach(self::rows($module) as $r){ if((int)$r['id']===absint($_GET['edit'])){$editing=$r;break;} } }
        if($admin){ $draft=get_transient('ct_mon_draft_'.get_current_user_id().'_'.$module); if(is_array($draft)){ $editing=array_filter($draft['input'],'is_scalar'); $editing['id']=$draft['id']; delete_transient('ct_mon_draft_'.get_current_user_id().'_'.$module); } }
        $total=0; $heads=array(); $providers=array();
        foreach($rows as $row){ $amount=(float)($row['amount']??0); $total+=$amount; $head=(string)($row['area_head']??'Area Head 1'); $provider=(string)($row['provider']??'Lainnya'); $heads[$head]=($heads[$head]??0)+$amount; $providers[$provider]=($providers[$provider]??0)+$amount; }
        $headOrder=array('Area Head 1','Area Head 2','Area Head 3'); $orderedHeads=array(); foreach($headOrder as $head){if(isset($heads[$head])){$orderedHeads[$head]=$heads[$head];}} foreach($heads as $head=>$amount){if(!isset($orderedHeads[$head])){$orderedHeads[$head]=$amount;}}
        $providerOrder=array('Askrindo','BRINS','BSM'); $orderedProviders=array(); foreach($providerOrder as $provider){if(isset($providers[$provider])){$orderedProviders[$provider]=$providers[$provider];}} foreach($providers as $provider=>$amount){if(!isset($orderedProviders[$provider])){$orderedProviders[$provider]=$amount;}}
        $grouped=array(); foreach($rows as $row){$grouped[(string)($row['area_head']??'Area Head 1')][]=$row;}
        $fieldKeys=array('area_head','bo','unit','debtor','account','provider','policy','amount','rejected','reason','status','owner','note');
        $dateLabel=function($date){$d=DateTimeImmutable::createFromFormat('!Y-m-d',(string)$date); return $d?$d->format('d/m/Y'):(string)$date;};
        ?>
        <section class="ct-rejected-2025">
            <div class="ct-rejected-title-row"><h2>KLAIM DITOLAK TAHUN 2025</h2><span><?php echo esc_html(count($rows)); ?> data · Rp <?php echo esc_html(number_format($total,0,',','.')); ?></span></div>
            <form class="ct-rejected-filter" method="get">
                <?php foreach(array('page_id','view','section') as $key){if(isset($_GET[$key])&&is_scalar($_GET[$key])){echo '<input type="hidden" name="'.esc_attr($key).'" value="'.esc_attr(wp_unslash($_GET[$key])).'">';}} ?>
                <label>Cari data<input name="mq" placeholder="BO, Uker, nasabah, rekening, policy…" value="<?php echo esc_attr(is_scalar($_GET['mq']??'')?wp_unslash($_GET['mq']??''):''); ?>"></label>
                <label>Bulan penolakan<input type="month" name="mperiod" value="<?php echo esc_attr(is_scalar($_GET['mperiod']??'')?wp_unslash($_GET['mperiod']??''):''); ?>"></label>
                <button type="submit">Terapkan</button><a href="<?php echo esc_url(remove_query_arg(array('mq','mperiod','edit'))); ?>">Reset</a>
            </form>
            <?php if(array_filter($rows,function($row){return !empty($row['demo']);})): ?><p class="ct-rejected-note">Data pada tampilan ini berasal dari contoh referensi dan dapat diganti melalui form input di bawah.</p><?php endif; ?>
            <div class="ct-rejected-layout">
                <article class="ct-rejected-table-card"><div class="ct-rejected-table-scroll"><table class="ct-rejected-table"><thead><tr><th>No</th><th>BO</th><th>Uker</th><th>Nama Nasabah</th><th>No Rek</th><th>Asuradur</th><th>Policy</th><th>Nilai Klaim</th><th>LastDate</th><?php if($admin): ?><th>Aksi</th><?php endif; ?></tr></thead><tbody>
        <?php foreach($orderedHeads as $head=>$headTotal): ?><tr class="ct-rejected-group"><th colspan="8"><?php echo esc_html($head); ?></th><th><?php echo esc_html(number_format($headTotal,0,',','.')); ?></th><?php if($admin): ?><th></th><?php endif; ?></tr>
                    <?php foreach($grouped[$head]??array() as $i=>$row): ?><tr>
                        <td data-label="No"><?php echo (int)$i+1; ?></td><td data-label="BO"><?php echo esc_html($row['bo']??''); ?></td><td data-label="Uker"><?php echo esc_html($row['unit']??''); ?></td><td data-label="Nama Nasabah"><?php echo esc_html($row['debtor']??''); ?></td><td data-label="No Rek"><?php echo esc_html($row['account']??''); ?></td><td data-label="Asuradur"><?php echo esc_html($row['provider']??''); ?></td><td data-label="Policy"><?php echo esc_html($row['policy']??''); ?></td><td data-label="Nilai Klaim" class="is-number"><?php echo esc_html(number_format((float)($row['amount']??0),0,',','.')); ?></td><td data-label="LastDate"><?php echo esc_html($dateLabel($row['rejected']??'')); ?></td>
                        <?php if($admin): ?><td data-label="Aksi" class="ct-rejected-actions"><a href="<?php echo esc_url(add_query_arg('edit',$row['id'],$url).'#ct-rejected-editor'); ?>">Edit</a><details><summary>Hapus</summary><form method="post" action="<?php echo esc_url($url); ?>"><?php wp_nonce_field('claimtrack_action','claimtrack_nonce'); ?><input type="hidden" name="claimtrack_action" value="monitoring_delete"><input type="hidden" name="module" value="<?php echo esc_attr($module); ?>"><input type="hidden" name="id" value="<?php echo (int)$row['id']; ?>"><button type="submit">Ya</button></form></details></td><?php endif; ?>
                    </tr><?php endforeach; ?>
                <?php endforeach; ?><tr class="ct-rejected-grand-total"><th colspan="7">Total</th><th><?php echo esc_html(number_format($total,0,',','.')); ?></th><th></th><?php if($admin): ?><th></th><?php endif; ?></tr>
                <?php if(!$rows): ?><tr><td colspan="<?php echo $admin?10:9; ?>" class="is-empty">Tidak ada data yang sesuai.</td></tr><?php endif; ?>
                </tbody></table></div></article>
                <aside class="ct-rejected-charts"><div class="ct-rejected-chart-label">DISTRIBUSI NILAI KLAIM PER AREA HEAD</div><?php self::render_rejected_chart($orderedHeads,$total); ?><div class="ct-rejected-chart-label">DISTRIBUSI NILAI KLAIM PER ASURADUR</div><?php self::render_rejected_chart($orderedProviders,$total); ?></aside>
            </div>
            <?php if($admin): ?><section class="ct-rejected-editor" id="ct-rejected-editor"><div class="ct-rejected-editor-heading"><h3><?php echo $editing?'Edit Klaim Ditolak':'Input Klaim Ditolak 2025'; ?></h3><p>Isi kolom tabel sesuai data klaim. Nilai klaim menggunakan Rupiah penuh, tanpa pemisah ribuan.</p></div><form class="ct-rejected-form" method="post" action="<?php echo esc_url($url); ?>">
                <?php wp_nonce_field('claimtrack_action','claimtrack_nonce'); ?><input type="hidden" name="claimtrack_action" value="monitoring_save"><input type="hidden" name="module" value="<?php echo esc_attr($module); ?>"><input type="hidden" name="id" value="<?php echo (int)($editing['id']??0); ?>">
                <?php foreach($fieldKeys as $key): $field=$c['fields'][$key]; $type=$field[1]; $value=$editing[$key]??''; ?><label><?php echo esc_html($field[0]); ?><?php if($key!=='note'): ?><span aria-hidden="true">*</span><?php endif; ?><?php if(is_array($type)): ?><select name="<?php echo esc_attr($key); ?>" required><?php foreach($type as $option): ?><option value="<?php echo esc_attr($option); ?>" <?php selected($value,$option); ?>><?php echo esc_html($option); ?></option><?php endforeach; ?></select><?php elseif($type==='textarea'): ?><textarea name="<?php echo esc_attr($key); ?>" rows="3"><?php echo esc_textarea($value); ?></textarea><?php else: ?><input name="<?php echo esc_attr($key); ?>" type="<?php echo esc_attr($type); ?>" value="<?php echo esc_attr($value); ?>" required <?php if($type==='number'): ?>min="0" step="1"<?php endif; ?><?php if($key==='rejected'): ?> min="2025-01-01" max="2025-12-31"<?php endif; ?>><?php endif; ?></label><?php endforeach; ?>
                <label class="ct-rejected-check"><input type="checkbox" name="demo" value="1" <?php checked(!empty($editing['demo'])); ?>> Tandai sebagai data contoh</label><div class="ct-rejected-form-actions"><button type="submit">Simpan Data</button><?php if($editing): ?><a href="<?php echo esc_url($url); ?>">Batal edit</a><?php endif; ?></div>
            </form></section><?php endif; ?>
        </section>
        <?php
    }
    public static function render($module,$admin,$url) {
        if($module==='klaim-ditolak-2025'){ self::render_rejected_2025($admin,$url); return; }
        $c=self::modules()[$module]; $rows=self::selected_rows($module); $editing=array();
        if($admin && !empty($_GET['edit'])) { foreach(self::rows($module) as $r) { if($r['id']===absint($_GET['edit'])) { $editing=$r; } } }
        if($admin) { $draft=get_transient('ct_mon_draft_'.get_current_user_id().'_'.$module); if(is_array($draft)) { $editing=array_filter($draft['input'],'is_scalar'); $editing['id']=$draft['id']; delete_transient('ct_mon_draft_'.get_current_user_id().'_'.$module); } }
        $total=array_sum(array_column($rows,'amount')); $demo=count(array_filter($rows,function($r){return !empty($r['demo']);}));
        $metric=0; $label='';
        if($module==='monitoring-tempo') { $label='Melewati jatuh tempo'; foreach($rows as $r){if($r['status']!=='Selesai' && $r['due']<wp_date('Y-m-d')){$metric++;}} }
        elseif($module==='monitoring-pra-klaim') { $label='Rata-rata kelengkapan'; $metric=($rows?round(array_sum(array_column($rows,'progress'))/count($rows)):0).'%'; }
        elseif($module==='best-performance') { $label='Capaian gabungan';$target=array_sum(array_column($rows,'target'));$metric=($target?round($total/$target*100,1):0).'%'; }
        else { $label='Keberatan diajukan';foreach($rows as $r){if($r['status']==='Keberatan diajukan'){$metric++;}} }
        ?>
        <section class="ct-monitor ct-phase-content--detail ct-monitor--phase">
          <header class="ct-mon-phase-hero ct-htmlref-phase-hero">
            <div class="ct-htmlref-banner"><div class="ct-htmlref-title-row"><div class="ct-phase-title ct-kdp-title"><strong><?php echo esc_html($c['title']); ?></strong></div><div class="ct-htmlref-header-info"><span><?php echo esc_html(wp_date('d F Y')); ?></span><span>MONITORING KLAIM</span></div></div><p class="ct-mon-subtitle"><?php echo esc_html($c['intro']); ?></p></div>
            <div class="ct-provider-cards ct-htmlref-kpi-grid ct-mon-kpis">
            <?php foreach(array('Total data'=>count($rows),'Nominal (juta rupiah)'=>number_format($total,2,',','.'),$label=>$metric,'Data contoh'=>$demo) as $k=>$v): ?><article class="ct-provider-card ct-htmlref-kpi-card"><div class="ct-provider-name"><?php echo esc_html($k); ?></div><div class="ct-provider-value"><?php echo esc_html($v); ?></div></article><?php endforeach; ?>
            </div>
          </header>
          <div class="ct-mon-phase-body">
          <?php if($demo): ?><p class="ct-mon-info">Data bertanda <b>Contoh</b> adalah simulasi, bukan data klaim aktual. Ringkasan mengikuti hasil filter dan mencakup data contoh.</p><?php endif; ?>
          <form class="ct-mon-filter" method="get">
            <?php foreach(array('page_id','view','section') as $key) { if(isset($_GET[$key]) && is_scalar($_GET[$key])) { echo '<input type="hidden" name="'.esc_attr($key).'" value="'.esc_attr(wp_unslash($_GET[$key])).'">'; } } ?>
            <label>Cari data<input name="mq" placeholder="Unit, debitur, asuradur, PIC…" value="<?php echo esc_attr(is_scalar($_GET['mq'] ?? '')?wp_unslash($_GET['mq'] ?? ''):''); ?>"></label>
            <label><?php echo $module==='monitoring-tempo'?'Bulan jatuh tempo':($module==='klaim-ditolak-2025'?'Bulan penolakan':'Periode'); ?><input type="month" name="mperiod" value="<?php echo esc_attr(is_scalar($_GET['mperiod'] ?? '')?wp_unslash($_GET['mperiod'] ?? ''):''); ?>"></label><button>Terapkan</button><a href="<?php echo esc_url(remove_query_arg(array('mq','mperiod','edit'))); ?>">Reset</a>
          </form>
          <?php self::render_phase_summary($module,$rows); ?>
          <?php if($module==='best-performance' && $rows): ?><div class="ct-mon-leaders"><?php foreach(array_slice($rows,0,3) as $i=>$r): ?><article><small>PERINGKAT <?php echo (int)$i+1; ?></small><h3><?php echo esc_html($r['unit']); ?></h3><strong><?php echo esc_html(number_format(self::score($r),1,',','.')); ?>%</strong><p><?php echo esc_html($r['period']); ?> · <?php echo empty($r['demo'])?'Aktual':'Contoh'; ?></p></article><?php endforeach; ?></div><p class="ct-mon-info">Capaian = realisasi ÷ target × 100%. Tanpa filter periode, peringkat membandingkan seluruh catatan unit-periode.</p><?php endif; ?>
          <div class="ct-mon-panel"><div class="ct-mon-panel-head"><h3 class="ct-kdp-section-title">RINCIAN DATA <?php echo esc_html(strtoupper($c['title'])); ?></h3><span><?php echo count($rows); ?> catatan</span></div><div class="ct-mon-table" tabindex="0" role="region" aria-label="Tabel data, geser untuk melihat seluruh kolom"><table><thead><tr><th>No.</th><?php foreach($c['fields'] as $f): ?><th><?php echo esc_html($f[0]); ?></th><?php endforeach; ?><th>Sumber</th><?php if($module==='best-performance' || $module==='monitoring-tempo'): ?><th><?php echo $module==='best-performance'?'Capaian':'Sisa waktu'; ?></th><?php endif; ?><?php if($admin): ?><th>Aksi</th><?php endif; ?></tr></thead><tbody>
          <?php foreach($rows as $i=>$r): ?><tr><td><?php echo $i+1; ?></td><?php foreach($c['fields'] as $k=>$f): ?><td><?php if(in_array($k,array('status','reason'),true)): ?><span class="ct-mon-badge"><?php echo esc_html($r[$k] ?? ''); ?></span><?php elseif(in_array($k,array('progress','sla'),true)): ?><span><?php echo esc_html($r[$k]); ?>%</span><meter min="0" max="100" value="<?php echo esc_attr($r[$k]); ?>"><?php echo esc_html($r[$k]); ?>%</meter><?php else: echo esc_html($f[1]==='number'?number_format((float)($r[$k] ?? 0),$k==='cases'?0:2,',','.') : ($r[$k] ?? '')); endif; ?></td><?php endforeach; ?><td><span class="ct-mon-badge"><?php echo empty($r['demo'])?'Aktual':'Contoh'; ?></span></td>
          <?php if($module==='best-performance'): ?><td><strong><?php echo esc_html(number_format(self::score($r),1)); ?>%</strong></td><?php elseif($module==='monitoring-tempo'): ?><td><span class="ct-mon-badge <?php echo $r['status']!=='Selesai' && $r['due']<wp_date('Y-m-d')?'ct-mon-danger':''; ?>"><?php echo esc_html(self::deadline($r)); ?></span></td><?php endif; ?>
          <?php if($admin): ?><td><a href="<?php echo esc_url(add_query_arg('edit',$r['id'],$url).'#ct-mon-editor'); ?>">Edit</a><details class="ct-mon-delete"><summary>Hapus</summary><form method="post" action="<?php echo esc_url($url); ?>"><?php wp_nonce_field('claimtrack_action','claimtrack_nonce'); ?><input type="hidden" name="claimtrack_action" value="monitoring_delete"><input type="hidden" name="module" value="<?php echo esc_attr($module); ?>"><input type="hidden" name="id" value="<?php echo (int)$r['id']; ?>"><p>Hapus catatan ini permanen?</p><button class="ct-mon-delete-btn">Ya, hapus</button></form></details></td><?php endif; ?></tr><?php endforeach; ?>
          <?php if(!$rows): ?><tr><td colspan="<?php echo count($c['fields'])+4; ?>">Tidak ada data yang sesuai. Ubah filter<?php echo $admin?' atau tambahkan data melalui formulir di bawah.':'.'; ?></td></tr><?php endif; ?>
          </tbody></table></div></div>
          <?php if($admin): ?><div class="ct-mon-panel" id="ct-mon-editor"><h3><?php echo $editing?'Edit data':'Tambah data'; ?></h3><p>Nominal dalam juta rupiah. Gunakan titik untuk desimal, contoh 1250.50.</p><form class="ct-mon-form" method="post" action="<?php echo esc_url($url); ?>">
          <?php wp_nonce_field('claimtrack_action','claimtrack_nonce'); ?><input type="hidden" name="claimtrack_action" value="monitoring_save"><input type="hidden" name="module" value="<?php echo esc_attr($module); ?>"><input type="hidden" name="id" value="<?php echo (int)($editing['id'] ?? 0); ?>">
          <?php foreach($c['fields'] as $k=>$f): $type=$f[1]; $value=$editing[$k] ?? ''; ?><label><?php echo esc_html($f[0]); ?><?php if($k!=='note'): ?> <span aria-hidden="true">*</span><?php endif; ?>
          <?php if(is_array($type)): ?><select name="<?php echo esc_attr($k); ?>" required><?php foreach($type as $option): ?><option <?php selected($value,$option); ?>><?php echo esc_html($option); ?></option><?php endforeach; ?></select>
          <?php elseif($type==='textarea'): ?><textarea name="<?php echo esc_attr($k); ?>" rows="3"><?php echo esc_textarea($value); ?></textarea>
          <?php else: ?><input name="<?php echo esc_attr($k); ?>" type="<?php echo esc_attr($type); ?>" value="<?php echo esc_attr($value); ?>" required <?php if($type==='number'){ echo 'min="'.($k==='target'?'0.01':'0').'" step="'.($k==='cases'?'1':'0.01').'"'; if(in_array($k,array('progress','sla'),true)){echo ' max="100"';} } if($k==='rejected'){echo ' min="2025-01-01" max="2025-12-31"';} ?>><?php endif; ?></label><?php endforeach; ?>
          <label class="ct-mon-check"><input type="checkbox" name="demo" value="1" <?php checked(!empty($editing['demo'])); ?>> Tandai sebagai data contoh</label><div class="ct-mon-form-actions"><button>Simpan data</button><?php if($editing): ?><a href="<?php echo esc_url($url); ?>">Batal edit</a><?php endif; ?></div></form></div><?php endif; ?>
          </div>
        </section>
        <?php
    }
}
