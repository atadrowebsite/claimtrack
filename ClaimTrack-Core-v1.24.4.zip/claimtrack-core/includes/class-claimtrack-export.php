<?php
if (!defined('ABSPATH')) { exit; }

class ClaimTrack_Export {
    public static function get_rows($filters = array()) {
        global $wpdb;
        $t = ClaimTrack_DB::tables();
        $where = array('1=1');
        $args = array();
        if (!empty($filters['year'])) { $where[] = 'e.year=%d'; $args[] = (int)$filters['year']; }
        if (!empty($filters['month'])) { $where[] = 'e.month=%d'; $args[] = (int)$filters['month']; }
        if (!empty($filters['program_id'])) { $where[] = 'e.program_id=%d'; $args[] = (int)$filters['program_id']; }
        if (!empty($filters['unit_id'])) { $where[] = 'e.unit_id=%d'; $args[] = (int)$filters['unit_id']; }
        $sql = "SELECT e.*, u.code unit_code, u.name unit_name, p.code program_code, p.name program_name,
                       pr.code provider_code, pr.name provider_name
                FROM {$t['entries']} e
                JOIN {$t['units']} u ON u.id=e.unit_id
                JOIN {$t['programs']} p ON p.id=e.program_id
                JOIN {$t['providers']} pr ON pr.id=e.provider_id
                WHERE " . implode(' AND ', $where) . "
                ORDER BY e.year DESC,e.month DESC,e.week ASC,u.sort_order,u.name,p.dashboard_order,p.name,pr.sort_order,pr.name";
        if ($args) { $sql = $wpdb->prepare($sql, $args); }
        return $wpdb->get_results($sql, ARRAY_A);
    }

    /**
     * CSV yang nyaman dibuka pada Excel regional Indonesia.
     * Baris sep=; memastikan kolom langsung terpisah menjadi tabel.
     * Semua kombinasi Unit x Mitra x Minggu sudah disiapkan sehingga pengguna
     * cukup mengisi kolom Nominal dan, bila perlu, Catatan.
     */
    public static function stream_template_csv() {
        global $wpdb;
        $t = ClaimTrack_DB::tables();
        $units = $wpdb->get_results("SELECT name FROM {$t['units']} WHERE active=1 ORDER BY sort_order,name", ARRAY_A);
        $providers = $wpdb->get_results("SELECT name FROM {$t['providers']} WHERE active=1 ORDER BY sort_order,name", ARRAY_A);
        $program = $wpdb->get_row("SELECT name FROM {$t['programs']} WHERE active=1 AND code='KDP' LIMIT 1", ARRAY_A);
        if (!$program) { $program = array('name'=>'KDP'); }
        $year = (int) wp_date('Y');
        $month = (int) wp_date('n');
        $roman = array(1=>'I',2=>'II',3=>'III',4=>'IV');

        self::clean_buffers();
        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="claimtrack-template-import.csv"');
        header('X-Content-Type-Options: nosniff');
        // BOM + sep=; membuat Excel regional Indonesia langsung membuka CSV dalam kolom tabel.
        echo "\xEF\xBB\xBF";
        echo "sep=;\r\n";
        $out = fopen('php://output', 'w');
        $header = array('Tahun','Bulan','Minggu','Unit Kerja','Program','Mitra','Nominal','Catatan');
        fputcsv($out, $header, ';');
        if ($units && $providers) {
            foreach ($units as $u) {
                foreach ($providers as $pr) {
                    for ($week=1; $week<=4; $week++) {
                        fputcsv($out, array($year,$month,$roman[$week],$u['name'],$program['name'],$pr['name'],'',''), ';');
                    }
                }
            }
        } else {
            fputcsv($out, array($year,$month,'I','Abepura','KDP','Askrindo','',''), ';');
        }
        fclose($out);
        exit;
    }

    public static function stream_template_xlsx() {
        // Template XLSX siap-isi dibuat sebagai workbook tabel nyata, sehingga lebih nyaman untuk input manual.
        $file = CLAIMTRACK_PATH . 'assets/claimtrack-template-import.xlsx';
        if (!is_readable($file)) {
            wp_die('Template Excel tidak ditemukan. Silakan install ulang ClaimTrack Core.');
        }
        self::clean_buffers();
        nocache_headers();
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="claimtrack-template-import.xlsx"');
        header('Content-Transfer-Encoding: binary');
        header('Content-Length: ' . filesize($file));
        header('X-Content-Type-Options: nosniff');
        readfile($file);
        exit;
    }

    public static function stream_xlsx($filters) {
        $rows = self::get_rows($filters);
        $data = array();
        $data[] = array('Tahun','Bulan','Minggu','Kode Unit','Unit Kerja','Kode Program','Program','Kode Mitra','Mitra','Nominal (Juta Rupiah)','Catatan');
        $roman = array(1=>'I',2=>'II',3=>'III',4=>'IV');
        foreach ($rows as $r) {
            $data[] = array(
                (int)$r['year'], (int)$r['month'], $roman[(int)$r['week']] ?? (string)$r['week'],
                (string)$r['unit_code'], (string)$r['unit_name'], (string)$r['program_code'], (string)$r['program_name'],
                (string)$r['provider_code'], (string)$r['provider_name'], (float)$r['amount_million'], (string)$r['note']
            );
        }
        $filename = 'claimtrack-export-' . wp_date('Ymd-His') . '.xlsx';
        self::stream_xlsx_data($data, $filename, 'Data ClaimTrack');
    }

    public static function stream_pdf($filters) {
        $rows = self::get_rows($filters);
        $roman = array(1=>'I',2=>'II',3=>'III',4=>'IV');
        $tableRows = array();
        foreach ($rows as $i => $r) {
            $tableRows[] = array(
                $i+1,$r['unit_name'],$r['program_name'],$r['provider_name'],$r['year'],$r['month'],
                $roman[(int)$r['week']] ?? $r['week'],number_format((float)$r['amount_million'], 2, ',', '.')
            );
        }
        $title = 'CLAIMTRACK - LAPORAN DATA KLAIM';
        $subtitle = 'Diekspor ' . wp_date('d F Y H:i') . ' | Satuan nominal: juta rupiah';
        $pdf = new ClaimTrack_Simple_PDF();
        $bytes = $pdf->table($title, $subtitle,
            array('No','Unit Kerja','Program','Mitra','Tahun','Bulan','Mgg','Nominal'),
            $tableRows,array(28,110,105,105,45,45,35,95)
        );
        self::clean_buffers();
        nocache_headers();
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="claimtrack-export-' . wp_date('Ymd-His') . '.pdf"');
        header('Content-Length: ' . strlen($bytes));
        echo $bytes;
        exit;
    }

    /**
     * Export tabel generik untuk laporan yang dapat diunduh user dari setiap menu frontend.
     * $data harus berisi header pada baris pertama.
     */
    public static function stream_report_xlsx($data, $filename, $sheet_name='Laporan ClaimTrack') {
        if (!is_array($data) || !$data) { $data = array(array('Data')); }
        self::stream_xlsx_data($data, sanitize_file_name($filename), $sheet_name);
    }

    /** Export PDF generik dengan lebar kolom otomatis agar tabel tetap proporsional. */
    public static function stream_report_pdf($title, $subtitle, $headers, $rows, $filename) {
        $headers = array_values((array)$headers);
        $rows = array_values((array)$rows);
        if (!$headers) { $headers = array('Data'); }
        $widths = self::auto_pdf_widths($headers, $rows, 756);
        $pdf = new ClaimTrack_Simple_PDF();
        $bytes = $pdf->table((string)$title, (string)$subtitle, $headers, $rows, $widths);
        self::clean_buffers();
        nocache_headers();
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="'.sanitize_file_name($filename).'"');
        header('Content-Length: ' . strlen($bytes));
        header('X-Content-Type-Options: nosniff');
        echo $bytes;
        exit;
    }

    private static function auto_pdf_widths($headers, $rows, $total_width=756) {
        $count = max(1, count($headers));
        $weights = array_fill(0, $count, 6.0);
        foreach ($headers as $i=>$header) {
            $weights[$i] = max($weights[$i], min(24, max(5, strlen(wp_strip_all_tags((string)$header)))));
        }
        foreach (array_slice((array)$rows, 0, 50) as $row) {
            foreach (array_values((array)$row) as $i=>$value) {
                if ($i >= $count) { break; }
                $weights[$i] = max($weights[$i], min(30, max(4, strlen(wp_strip_all_tags((string)$value)))));
            }
        }
        if ($count > 1 && strtolower((string)$headers[0]) === 'no') { $weights[0] = 4.5; }
        $sum = array_sum($weights);
        $widths = array(); $used = 0;
        foreach ($weights as $i=>$w) {
            if ($i === $count-1) { $widths[] = max(38, $total_width-$used); break; }
            $val = max(38, (int)floor(($w/$sum)*$total_width));
            $widths[] = $val; $used += $val;
        }
        // Jika minimum width membuat total melebihi batas, normalisasikan kembali.
        $sumw = array_sum($widths);
        if ($sumw > $total_width) {
            $scale = $total_width / $sumw;
            $used = 0;
            foreach ($widths as $i=>$w) {
                if ($i === count($widths)-1) { $widths[$i] = max(30, $total_width-$used); }
                else { $widths[$i] = max(30, (int)floor($w*$scale)); $used += $widths[$i]; }
            }
        }
        return $widths;
    }

    private static function clean_buffers() {
        while (ob_get_level()) { @ob_end_clean(); }
    }

    private static function xml($s) {
        return htmlspecialchars((string)$s, ENT_XML1 | ENT_QUOTES, 'UTF-8');
    }

    private static function col_name($n) {
        $name='';
        while ($n>0) { $n--; $name=chr(65+($n%26)).$name; $n=intdiv($n,26); }
        return $name;
    }

    private static function safe_sheet_name($name) {
        $name = preg_replace('~[\\/?*\[\]:]~', ' ', (string)$name);
        $name = trim($name);
        return self::xml(substr($name ?: 'Sheet1', 0, 31));
    }

    /**
     * Membuat XLSX murni tanpa ketergantungan ZipArchive/PclZip.
     * Ini menghindari kegagalan export pada hosting yang extension ZIP-nya tidak aktif.
     */
    private static function stream_xlsx_data($rows, $filename, $sheetName='Data ClaimTrack') {
        if (!$rows) { $rows=array(array('Data')); }
        $sheetRows='';
        $lastCol=self::col_name(max(1,count($rows[0])));
        foreach ($rows as $ri=>$row) {
            $r=$ri+1; $cells='';
            foreach (array_values($row) as $ci=>$value) {
                $ref=self::col_name($ci+1).$r;
                $style=$ri===0 ? ' s="1"' : ($ci===9 ? ' s="2"' : '');
                $isNumber=$ri>0 && in_array($ci,array(0,1,9),true) && $value!=='' && is_numeric($value);
                if ($isNumber) {
                    $cells.='<c r="'.$ref.'"'.$style.'><v>'.self::xml($value).'</v></c>';
                } else {
                    $text=(string)$value;
                    $preserve=(preg_match('/^\s|\s$/u',$text)) ? ' xml:space="preserve"' : '';
                    $cells.='<c r="'.$ref.'" t="inlineStr"'.$style.'><is><t'.$preserve.'>'.self::xml($text).'</t></is></c>';
                }
            }
            $sheetRows.='<row r="'.$r.'">'.$cells.'</row>';
        }
        $lastRow=count($rows);
        $sheet=self::safe_sheet_name($sheetName);
        $files=array(
            '[Content_Types].xml'=>'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                .'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                .'<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                .'<Default Extension="xml" ContentType="application/xml"/>'
                .'<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
                .'<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
                .'<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
                .'</Types>',
            '_rels/.rels'=>'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                .'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                .'<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
                .'</Relationships>',
            'xl/workbook.xml'=>'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                .'<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
                .'<bookViews><workbookView xWindow="0" yWindow="0" windowWidth="24000" windowHeight="12000"/></bookViews>'
                .'<sheets><sheet name="'.$sheet.'" sheetId="1" r:id="rId1"/></sheets></workbook>',
            'xl/_rels/workbook.xml.rels'=>'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                .'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                .'<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
                .'<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
                .'</Relationships>',
            'xl/styles.xml'=>'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                .'<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
                .'<numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0.00"/></numFmts>'
                .'<fonts count="2"><font><sz val="11"/><name val="Calibri"/><family val="2"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Calibri"/><family val="2"/></font></fonts>'
                .'<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF0B4B7A"/><bgColor indexed="64"/></patternFill></fill></fills>'
                .'<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"><color rgb="FFD9E1E7"/></left><right style="thin"><color rgb="FFD9E1E7"/></right><top style="thin"><color rgb="FFD9E1E7"/></top><bottom style="thin"><color rgb="FFD9E1E7"/></bottom><diagonal/></border></borders>'
                .'<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
                .'<cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"/><xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1"/></cellXfs>'
                .'<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
                .'<dxfs count="0"/><tableStyles count="0" defaultTableStyle="TableStyleMedium2" defaultPivotStyle="PivotStyleLight16"/>'
                .'</styleSheet>',
            'xl/worksheets/sheet1.xml'=>'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                .'<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
                .'<dimension ref="A1:'.$lastCol.$lastRow.'"/>'
                .'<sheetViews><sheetView tabSelected="1" workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/><selection pane="bottomLeft" activeCell="A2" sqref="A2"/></sheetView></sheetViews>'
                .'<sheetFormatPr defaultRowHeight="15"/>'
                .'<cols><col min="1" max="3" width="11" customWidth="1"/><col min="4" max="4" width="16" customWidth="1"/><col min="5" max="5" width="22" customWidth="1"/><col min="6" max="6" width="18" customWidth="1"/><col min="7" max="7" width="20" customWidth="1"/><col min="8" max="8" width="18" customWidth="1"/><col min="9" max="9" width="20" customWidth="1"/><col min="10" max="10" width="20" customWidth="1"/><col min="11" max="11" width="34" customWidth="1"/></cols>'
                .'<sheetData>'.$sheetRows.'</sheetData>'
                .'<autoFilter ref="A1:'.$lastCol.$lastRow.'"/>'
                .'</worksheet>',
        );
        $tmp = self::create_xlsx_archive($files, $filename);
        if (is_wp_error($tmp)) { wp_die(esc_html($tmp->get_error_message())); }
        self::clean_buffers();
        nocache_headers();
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="'.sanitize_file_name($filename).'"');
        header('Content-Transfer-Encoding: binary');
        header('Content-Length: '.filesize($tmp));
        header('X-Content-Type-Options: nosniff');
        readfile($tmp);
        @unlink($tmp);
        exit;
    }

    /**
     * Membuat arsip XLSX ke file sementara. Prioritas ZipArchive, lalu PclZip bawaan WordPress,
     * dan terakhir writer ZIP STORE internal. Output diverifikasi sebelum dikirim ke browser.
     */
    private static function create_xlsx_archive($files, $filename) {
        $tmp = wp_tempnam(sanitize_file_name($filename));
        if (!$tmp) { return new WP_Error('ct_xlsx_tmp', 'Folder temporary server tidak dapat digunakan untuk export Excel.'); }

        $ok = false;
        if (class_exists('ZipArchive')) {
            $zip = new ZipArchive();
            $opened = $zip->open($tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE);
            if ($opened === true) {
                $ok = true;
                foreach ($files as $name => $content) {
                    if (!$zip->addFromString($name, (string)$content)) { $ok = false; break; }
                }
                $zip->close();
            }
        }

        if (!$ok) {
            if (!class_exists('PclZip')) {
                $pcl = ABSPATH . 'wp-admin/includes/class-pclzip.php';
                if (file_exists($pcl)) { require_once $pcl; }
            }
            if (class_exists('PclZip')) {
                $dir = trailingslashit(get_temp_dir()) . 'claimtrack-xlsx-' . strtolower(wp_generate_password(10, false, false));
                if (wp_mkdir_p($dir)) {
                    $paths = array();
                    foreach ($files as $name => $content) {
                        $path = trailingslashit($dir) . str_replace('/', DIRECTORY_SEPARATOR, $name);
                        wp_mkdir_p(dirname($path));
                        if (file_put_contents($path, (string)$content) === false) { $paths = array(); break; }
                        $paths[] = $path;
                    }
                    if ($paths) {
                        @unlink($tmp);
                        $archive = new PclZip($tmp);
                        $res = $archive->create($paths, PCLZIP_OPT_REMOVE_PATH, $dir);
                        $ok = is_array($res) && !empty($res);
                    }
                    self::remove_dir($dir);
                }
            }
        }

        if (!$ok) {
            $bytes = self::zip_store($files);
            if ($bytes !== '' && file_put_contents($tmp, $bytes) !== false) { $ok = true; }
        }

        if (!$ok || !is_file($tmp) || filesize($tmp) < 500) {
            @unlink($tmp);
            return new WP_Error('ct_xlsx_create', 'Export Excel gagal dibuat oleh server.');
        }

        // Verifikasi kontainer jika parser ZIP tersedia.
        if (class_exists('ZipArchive')) {
            $check = new ZipArchive();
            if ($check->open($tmp) !== true || $check->locateName('[Content_Types].xml') === false || $check->locateName('xl/worksheets/sheet1.xml') === false) {
                if ($check->status === ZipArchive::ER_OK) { $check->close(); }
                @unlink($tmp);
                return new WP_Error('ct_xlsx_verify', 'File Excel terbentuk tetapi struktur XLSX tidak valid.');
            }
            $check->close();
        }
        return $tmp;
    }

    private static function remove_dir($dir) {
        if (!is_dir($dir)) { return; }
        $items = scandir($dir);
        if (!is_array($items)) { return; }
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') { continue; }
            $path = $dir . DIRECTORY_SEPARATOR . $item;
            if (is_dir($path)) { self::remove_dir($path); } else { @unlink($path); }
        }
        @rmdir($dir);
    }

    /** ZIP method STORE (tanpa kompresi), fallback bila library ZIP server tidak tersedia. */
    private static function zip_store($files) {
        $data=''; $central=''; $offset=0; $entries=0;
        $time=getdate();
        $dosTime=(($time['hours'] & 0x1f)<<11) | (($time['minutes'] & 0x3f)<<5) | ((int)($time['seconds']/2) & 0x1f);
        $year=max(1980,(int)$time['year']);
        $dosDate=((($year-1980)&0x7f)<<9) | (($time['mon']&0x0f)<<5) | ($time['mday']&0x1f);
        foreach ($files as $name=>$content) {
            $name=str_replace('\\','/',$name); $content=(string)$content; $size=strlen($content); $crc=crc32($content);
            $local=pack('VvvvvvVVVvv',0x04034b50,20,0,0,$dosTime,$dosDate,$crc,$size,$size,strlen($name),0).$name.$content;
            $data.=$local;
            $central.=pack('VvvvvvvVVVvvvvvVV',0x02014b50,20,20,0,0,$dosTime,$dosDate,$crc,$size,$size,strlen($name),0,0,0,0,0,$offset).$name;
            $offset+=strlen($local); $entries++;
        }
        $centralOffset=strlen($data); $centralSize=strlen($central);
        $eocd=pack('VvvvvVVv',0x06054b50,0,0,$entries,$entries,$centralSize,$centralOffset,0);
        return $data.$central.$eocd;
    }
}

class ClaimTrack_Simple_PDF {
    private function esc($s) {
        $s = iconv('UTF-8', 'Windows-1252//TRANSLIT//IGNORE', (string)$s);
        return str_replace(array('\\','(',')',"\r","\n"), array('\\\\','\\(','\\)',' ',' '), $s);
    }

    private function text($x,$y,$size,$text,$bold=false) {
        $font = $bold ? 'F2' : 'F1';
        return "BT /{$font} {$size} Tf {$x} {$y} Td (".$this->esc($text).") Tj ET\n";
    }

    private function line($x1,$y1,$x2,$y2) { return "{$x1} {$y1} m {$x2} {$y2} l S\n"; }

    private function fit($text, $width, $size=8) {
        $maxChars = max(3, (int)floor($width / ($size * 0.52)));
        $text = (string)$text;
        if (strlen($text) <= $maxChars) { return $text; }
        return substr($text,0,max(1,$maxChars-3)) . '...';
    }

    public function table($title,$subtitle,$headers,$rows,$widths) {
        $pageW=842; $pageH=595; $left=28; $top=555; $rowH=19;
        $contentPages = array();
        $chunks = array_chunk($rows, 23);
        if (!$chunks) { $chunks = array(array()); }
        foreach ($chunks as $pageIndex => $chunk) {
            $c = "0.8 w 0 G\n";
            $c .= $this->text($left,$top,14,$title,true);
            $c .= $this->text($left,$top-18,8,$subtitle,false);
            $c .= $this->text(760,$top,8,'Hal. '.($pageIndex+1).'/'.count($chunks),false);
            $y = $top - 45;
            $x = $left;
            $c .= "0.05 0.29 0.48 rg {$left} ".($y-$rowH+4)." 756 {$rowH} re f 0 G\n";
            foreach ($headers as $i=>$h) {
                $c .= $this->text($x+3,$y-10,8,$this->fit($h,$widths[$i],8),true);
                $x += $widths[$i];
            }
            $c .= $this->line($left,$y-$rowH+4,$left+array_sum($widths),$y-$rowH+4);
            $y -= $rowH;
            foreach ($chunk as $row) {
                $x=$left;
                $c .= "0.86 G\n".$this->line($left,$y-$rowH+4,$left+array_sum($widths),$y-$rowH+4)."0 G\n";
                foreach ($row as $i=>$val) {
                    $c .= $this->text($x+3,$y-10,7.5,$this->fit($val,$widths[$i],7.5),false);
                    $x += $widths[$i];
                }
                $y -= $rowH;
            }
            $contentPages[] = $c;
        }
        return $this->build($contentPages, $pageW, $pageH);
    }

    private function build($contents, $pageW, $pageH) {
        $objects = array();
        $objects[] = '<< /Type /Catalog /Pages 2 0 R >>';
        $pageObjNums = array();
        $contentObjNums = array();
        $next = 5;
        foreach ($contents as $unused) { $pageObjNums[]=$next++; $contentObjNums[]=$next++; }
        $kids = implode(' ', array_map(fn($n)=>$n.' 0 R', $pageObjNums));
        $objects[] = '<< /Type /Pages /Kids ['.$kids.'] /Count '.count($pageObjNums).' >>';
        $objects[] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>';
        $objects[] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>';
        foreach ($contents as $i=>$content) {
            $objects[] = '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 '.$pageW.' '.$pageH.'] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents '.$contentObjNums[$i].' 0 R >>';
            $objects[] = '<< /Length '.strlen($content).' >>' . "\nstream\n" . $content . "endstream";
        }
        $pdf = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
        $offsets = array(0);
        foreach ($objects as $i=>$obj) {
            $offsets[] = strlen($pdf);
            $n = $i+1;
            $pdf .= $n." 0 obj\n".$obj."\nendobj\n";
        }
        $xref = strlen($pdf);
        $pdf .= "xref\n0 ".(count($objects)+1)."\n0000000000 65535 f \n";
        for ($i=1;$i<=count($objects);$i++) { $pdf .= sprintf('%010d 00000 n ', $offsets[$i])."\n"; }
        $pdf .= "trailer\n<< /Size ".(count($objects)+1)." /Root 1 0 R >>\nstartxref\n{$xref}\n%%EOF";
        return $pdf;
    }
}
