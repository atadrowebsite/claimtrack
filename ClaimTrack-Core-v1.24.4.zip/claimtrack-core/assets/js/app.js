(function(){
  function qs(s,c){return (c||document).querySelector(s)}
  function qsa(s,c){return Array.from((c||document).querySelectorAll(s))}
  function idNum(v){return new Intl.NumberFormat('id-ID',{maximumFractionDigits:0}).format(Number(v||0))}

  document.addEventListener('DOMContentLoaded',function(){
    var toggles=qsa('[data-ct-toggle]'), side=qs('[data-ct-sidebar]'), backdrop=qs('[data-ct-backdrop]');
    function setMenu(open){
      if(!side)return;
      side.classList.toggle('is-open',!!open);
      document.body.classList.toggle('ct-nav-open',!!open);
    }
    if(side){toggles.forEach(function(toggle){toggle.addEventListener('click',function(){setMenu(!side.classList.contains('is-open'))})});}
    if(backdrop){backdrop.addEventListener('click',function(){setMenu(false)});}
    qsa('[data-ct-sidebar] a').forEach(function(a){a.addEventListener('click',function(){if(window.innerWidth<=980)setMenu(false)})});
    window.addEventListener('resize',function(){if(window.innerWidth>980)setMenu(false)});

    qsa('[data-ct-chart]').forEach(renderChart);
    qsa('.ct-matrix input[type=number]').forEach(function(input){input.addEventListener('input',function(){
      var tr=input.closest('tr'); if(!tr)return; var total=0;
      qsa('input[type=number]',tr).forEach(function(i){total+=parseFloat(i.value||0)||0});
      var cell=qs('.ct-row-total',tr); if(cell)cell.textContent=new Intl.NumberFormat('id-ID',{minimumFractionDigits:2,maximumFractionDigits:2}).format(total);
    })});
    qsa('[data-ct-phase-donut]').forEach(initPhaseDonut);
    qsa('[data-ct-static-donut]').forEach(initStaticDonut);
    initKdpUnitFocus();
    initKdpProviderFocus();
    initAutoPeriodFilters();
    initEmptyDataModal();
    initKnowledgeEditor();
    initActionAlert();
    initConfirmActions();
    initMobilePhaseSheet();
    initMobileNavScroll();
    initPasswordToggles();
    window.addEventListener('resize',initMobileNavScroll,{passive:true});
    window.addEventListener('orientationchange',initMobileNavScroll,{passive:true});
  });

  function initPasswordToggles(){
    qsa('[data-ct-password-toggle]').forEach(function(btn){
      var field=btn.closest('.ct-password-field');
      var input=field?qs('input',field):null;
      if(!input)return;
      btn.addEventListener('click',function(){
        var show=input.type==='password';
        input.type=show?'text':'password';
        btn.setAttribute('aria-pressed',show?'true':'false');
        btn.setAttribute('aria-label',show?'Sembunyikan password':'Tampilkan password');
        var icon=qs('.dashicons',btn);
        if(icon){
          icon.classList.toggle('dashicons-visibility',!show);
          icon.classList.toggle('dashicons-hidden',show);
        }
        input.focus({preventScroll:true});
        try{input.setSelectionRange(input.value.length,input.value.length)}catch(e){}
      });
    });
  }

  function initAutoPeriodFilters(){
    qsa('[data-ct-auto-period]').forEach(function(form){
      var timer=null;
      function submitNow(){
        if(timer)clearTimeout(timer);
        form.classList.add('is-loading');
        if(typeof form.requestSubmit==='function')form.requestSubmit();else form.submit();
      }
      qsa('select',form).forEach(function(el){el.addEventListener('change',submitNow)});
      qsa('input[type=number]',form).forEach(function(el){
        el.addEventListener('change',submitNow);
        el.addEventListener('keydown',function(e){if(e.key==='Enter'){e.preventDefault();submitNow()}});
      });
    });
  }

  function initEmptyDataModal(){
    var modal=qs('[data-ct-empty-modal]');
    if(!modal)return;
    requestAnimationFrame(function(){modal.classList.add('is-visible');document.body.classList.add('ct-modal-open')});
    function close(){modal.classList.remove('is-visible');document.body.classList.remove('ct-modal-open');setTimeout(function(){if(modal.parentNode)modal.parentNode.removeChild(modal)},220)}
    qsa('[data-ct-empty-close]',modal).forEach(function(el){el.addEventListener('click',close)});
    document.addEventListener('keydown',function(e){if(e.key==='Escape')close()},{once:true});
  }

  function initKnowledgeEditor(){
    var editor=qs('[data-ct-knowledge-editor]');
    var toggles=qsa('[data-ct-knowledge-toggle]');
    if(!editor){return}
    function open(){editor.classList.add('is-open');editor.scrollIntoView({behavior:'smooth',block:'start'})}
    function close(){editor.classList.remove('is-open')}
    toggles.forEach(function(btn){btn.addEventListener('click',open)});
    qsa('[data-ct-knowledge-close]',editor).forEach(function(btn){btn.addEventListener('click',close)});
  }


  function initActionAlert(){
    var modal=qs('[data-ct-action-alert]');
    if(!modal)return;
    requestAnimationFrame(function(){modal.classList.add('is-visible');document.body.classList.add('ct-modal-open')});
    function close(){
      modal.classList.remove('is-visible');document.body.classList.remove('ct-modal-open');
      setTimeout(function(){if(modal.parentNode)modal.parentNode.removeChild(modal)},220);
      try{
        var u=new URL(window.location.href);['ct_msg','ct_type','ct_event'].forEach(function(k){u.searchParams.delete(k)});history.replaceState({},'',u.pathname+(u.search?'?'+u.searchParams.toString():'')+u.hash);
      }catch(e){}
    }
    qsa('[data-ct-action-alert-close]',modal).forEach(function(el){el.addEventListener('click',close)});
    document.addEventListener('keydown',function(e){if(e.key==='Escape')close()},{once:true});
  }

  function initConfirmActions(){
    qsa('form[data-ct-confirm]').forEach(function(form){
      form.addEventListener('submit',function(e){
        if(form.getAttribute('data-ct-confirmed')==='1')return;
        e.preventDefault();
        var title=form.getAttribute('data-ct-confirm-title')||'Konfirmasi';
        var message=form.getAttribute('data-ct-confirm')||'Lanjutkan proses ini?';
        var modal=document.createElement('div');modal.className='ct-confirm-modal';
        modal.innerHTML='<div class="ct-confirm-backdrop" data-confirm-cancel></div><div class="ct-confirm-card"><span class="ct-confirm-icon"><span class="dashicons dashicons-warning"></span></span><h3>'+escapeHtml(title)+'</h3><p>'+escapeHtml(message)+'</p><div class="ct-confirm-actions"><button type="button" class="ct-btn ct-btn--light" data-confirm-cancel>Batal</button><button type="button" class="ct-btn ct-btn--danger-solid" data-confirm-ok>Ya, Lanjutkan</button></div></div>';
        document.body.appendChild(modal);document.body.classList.add('ct-modal-open');requestAnimationFrame(function(){modal.classList.add('is-visible')});
        function remove(){modal.classList.remove('is-visible');document.body.classList.remove('ct-modal-open');setTimeout(function(){if(modal.parentNode)modal.remove()},180)}
        qsa('[data-confirm-cancel]',modal).forEach(function(btn){btn.addEventListener('click',remove)});
        qs('[data-confirm-ok]',modal).addEventListener('click',function(){form.setAttribute('data-ct-confirmed','1');remove();setTimeout(function(){if(typeof form.requestSubmit==='function')form.requestSubmit();else form.submit()},70)});
      });
    });
  }


  function initMobileNavScroll(){
    if(window.innerWidth>1024)return;
    qsa('.ct-mobile-nav, .ct-mobile-nav--complete, .ct-admin-mobile-nav').forEach(function(nav){
      var active=qs('.is-active',nav);
      if(!active)return;
      requestAnimationFrame(function(){
        if(nav.scrollWidth<=nav.clientWidth+4)return;
        try{active.scrollIntoView({behavior:'auto',block:'nearest',inline:'center'})}catch(e){}
      });
    });
  }

  function initMobilePhaseSheet(){
    var sheet=qs('[data-ct-mobile-phase-sheet]'); if(!sheet)return;
    function open(){sheet.classList.add('is-open');sheet.setAttribute('aria-hidden','false');document.body.classList.add('ct-sheet-open')}
    function close(){sheet.classList.remove('is-open');sheet.setAttribute('aria-hidden','true');document.body.classList.remove('ct-sheet-open')}
    qsa('[data-ct-mobile-phase-open]').forEach(function(btn){btn.addEventListener('click',open)});
    qsa('[data-ct-mobile-phase-close]',sheet).forEach(function(btn){btn.addEventListener('click',close)});
    qsa('a',sheet).forEach(function(a){a.addEventListener('click',close)});
    document.addEventListener('keydown',function(e){if(e.key==='Escape'&&sheet.classList.contains('is-open'))close()});
  }

  function initKdpUnitFocus(){
    var buttons=qsa('[data-ct-unit-focus]');
    if(!buttons.length)return;
    var unitPanel=qs('[data-ct-static-donut][data-donut-kind="unit"]');
    function activate(id){
      buttons.forEach(function(b){b.classList.toggle('is-active',b.getAttribute('data-ct-unit-focus')===String(id))});
      qsa('[data-unit-row]').forEach(function(row){row.classList.toggle('is-focus',row.getAttribute('data-unit-row')===String(id))});
      if(unitPanel){
        unitPanel.dispatchEvent(new CustomEvent('ct:focus-item',{detail:{id:'unit-'+String(id)}}));
      }
    }
    buttons.forEach(function(b){b.addEventListener('click',function(){activate(b.getAttribute('data-ct-unit-focus'))})});
  }

  function initKdpProviderFocus(){
    qsa('[data-ct-static-donut][data-donut-kind="provider"]').forEach(function(panel){
      var buttons=qsa('[data-ct-provider-focus]',panel);
      buttons.forEach(function(button){button.addEventListener('click',function(){
        buttons.forEach(function(b){
          var selected=b===button;
          b.classList.toggle('is-active',selected);
          b.setAttribute('aria-pressed',String(selected));
        });
        panel.dispatchEvent(new CustomEvent('ct:focus-item',{detail:{id:'provider-'+button.getAttribute('data-ct-provider-focus')}}));
      })});
    });
  }

  function initStaticDonut(panel){
    var items=[]; try{items=JSON.parse(panel.getAttribute('data-items')||'[]')}catch(e){return}
    items=(items||[]).filter(function(it){return Number(it.value||0)>0});
    var ring=qs('[data-ct-static-ring]',panel), labels=qs('[data-ct-static-labels]',panel);
    if(!ring)return;
    var total=items.reduce(function(a,it){return a+Number(it.value||0)},0);
    var totalLabel=panel.getAttribute('data-total-label')||'Total KDP';
    var palette=['#e94e8d','#ff8a22','#ffc328','#26bbb9','#6b50ae','#4279d8','#ef5d52','#45a66b','#8a65c7','#2d9ec1','#f09245','#5a8f5c','#b55d8f'];
    var tooltip=document.createElement('div');tooltip.className='ct-chart-tooltip ct-static-donut-tooltip';panel.appendChild(tooltip);
    var sticky=false,active=-1;

    if(!items.length||total<=0){ring.style.background='#e7edf1';if(labels)labels.innerHTML='<span class="ct-donut-empty">Belum ada data</span>';return}

    var starts=[],ends=[],stops=[],acc=0;
    items.forEach(function(it,i){
      var pct=Number(it.value||0)/total*100,start=acc,end=acc+pct;starts[i]=start;ends[i]=end;acc=end;
      stops.push(palette[i%palette.length]+' '+start.toFixed(3)+'% '+end.toFixed(3)+'%');
    });
    ring.style.background='conic-gradient(from -90deg,'+stops.join(',')+')';

    function pctText(v){return (Number(v||0)/total*100).toFixed(2)+'%'}
    function pointForIndex(i,radius){
      var mid=(starts[i]+ends[i])/2;
      var rad=((mid/100)*360-90)*Math.PI/180;
      return {x:50+Math.cos(rad)*radius,y:50+Math.sin(rad)*radius};
    }
    function placeTooltipByIndex(i){
      var box=panel.getBoundingClientRect(), rb=ring.getBoundingClientRect(), pt=pointForIndex(i,37);
      var x=(rb.left-box.left)+(pt.x/100)*rb.width;
      var y=(rb.top-box.top)+(pt.y/100)*rb.height;
      tooltip.style.left=Math.max(85,Math.min(box.width-85,x))+'px';
      tooltip.style.top=Math.max(62,Math.min(box.height-10,y))+'px';
    }
    function placeTooltip(clientX,clientY){
      var box=panel.getBoundingClientRect();
      tooltip.style.left=Math.max(85,Math.min(box.width-85,clientX-box.left))+'px';
      tooltip.style.top=Math.max(62,Math.min(box.height-10,clientY-box.top))+'px';
    }
    function show(i,e,makeSticky){
      var it=items[i];if(!it)return;active=i;
      tooltip.innerHTML='<strong>'+escapeHtml(it.name)+'</strong><span>'+escapeHtml(totalLabel)+'</span><b>IDR '+idNum(it.value)+' juta</b><small>'+pctText(it.value)+' dari total</small>';
      if(e&&typeof e.clientX==='number')placeTooltip(e.clientX,e.clientY);else placeTooltipByIndex(i);
      tooltip.classList.add('is-visible');ring.classList.add('is-chart-active');
      qsa('.ct-kdp-donut-label',labels).forEach(function(l,li){l.classList.toggle('is-active',Number(l.getAttribute('data-index'))===i)});
      if(makeSticky)sticky=true;
    }
    function hide(force){if(sticky&&!force)return;sticky=false;active=-1;tooltip.classList.remove('is-visible');ring.classList.remove('is-chart-active');qsa('.ct-kdp-donut-label',labels).forEach(function(l){l.classList.remove('is-active')})}
    function segmentAt(clientX,clientY){
      var r=ring.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2,dx=clientX-cx,dy=clientY-cy,dist=Math.sqrt(dx*dx+dy*dy),outer=r.width/2,inner=outer*.43;
      if(dist<inner||dist>outer)return -1;
      var deg=(Math.atan2(dy,dx)*180/Math.PI+450)%360,pct=deg/360*100;
      for(var i=0;i<items.length;i++){if(pct>=starts[i]-0.0001&&pct<=ends[i]+0.0001)return i}
      return items.length-1;
    }

    if(labels){
      labels.innerHTML='';
      var count=Math.max(1,Math.min(Number(panel.getAttribute('data-label-count')||4),items.length));
      var ranked=items.map(function(it,i){return {i:i,v:Number(it.value||0)}}).sort(function(a,b){return b.v-a.v}).slice(0,count);
      ranked.forEach(function(r){
        var i=r.i,it=items[i],pt=pointForIndex(i,31),lab=document.createElement('button');
        lab.type='button';lab.className='ct-kdp-donut-label';lab.setAttribute('data-index',String(i));
        lab.style.left=pt.x+'%';lab.style.top=pt.y+'%';
        lab.innerHTML='<strong>'+escapeHtml(it.name)+'</strong><span>'+pctText(it.value)+'</span>';
        lab.addEventListener('mouseenter',function(e){if(!sticky)show(i,e,false)});
        lab.addEventListener('mousemove',function(e){if(!sticky)placeTooltip(e.clientX,e.clientY)});
        lab.addEventListener('mouseleave',function(){hide(false)});
        lab.addEventListener('click',function(e){e.stopPropagation();if(sticky&&active===i)hide(true);else{sticky=true;show(i,e,true)}});
        labels.appendChild(lab);
      });
    }
    ring.addEventListener('mousemove',function(e){if(sticky)return;var i=segmentAt(e.clientX,e.clientY);if(i>=0)show(i,e,false);else hide(false)});
    ring.addEventListener('mouseleave',function(){hide(false)});
    ring.addEventListener('click',function(e){var i=segmentAt(e.clientX,e.clientY);if(i<0){hide(true);return}if(sticky&&active===i)hide(true);else{sticky=true;show(i,e,true)}});
    panel.addEventListener('ct:focus-item',function(e){
      var id=e.detail&&e.detail.id;var i=items.findIndex(function(it){return String(it.id)===String(id)});if(i>=0){sticky=true;show(i,null,true)}else{hide(true)}
    });
    document.addEventListener('click',function(e){if(sticky&&!panel.contains(e.target)&&!e.target.closest('[data-ct-unit-focus]'))hide(true)});
  }

  function initPhaseDonut(panel){
    var data={}; try{data=JSON.parse(panel.getAttribute('data-units')||'{}')}catch(e){return}
    var ring=qs('[data-ct-donut-ring]',panel), unitEl=qs('[data-ct-donut-unit]',panel), totalEl=qs('[data-ct-donut-total]',panel), legend=qs('[data-ct-donut-legend]',panel);
    var buttons=qsa('[data-ct-unit]');
    var palette=['#e64d8b','#ff8b24','#f5c42d','#27b8b6','#6b50ae','#3f8de3','#ef5b4b','#38a169'];
    var tooltip=document.createElement('div'); tooltip.className='ct-chart-tooltip'; panel.appendChild(tooltip);
    var currentParts=[], currentTotal=0, sticky=false, activeIndex=-1;

    function placeTooltip(clientX,clientY){
      var box=panel.getBoundingClientRect();
      var x=Math.max(82,Math.min(box.width-82,clientX-box.left));
      var y=Math.max(58,Math.min(box.height-8,clientY-box.top));
      tooltip.style.left=x+'px'; tooltip.style.top=y+'px';
    }
    function showPart(index,clientX,clientY,makeSticky){
      var p=currentParts[index]; if(!p)return;
      activeIndex=index;
      var pct=currentTotal?Number(p.value||0)/currentTotal*100:0;
      tooltip.innerHTML='<strong>'+escapeHtml(p.name||'Mitra')+'</strong><span>Total nominatif</span><b>IDR '+idNum(p.value)+' juta</b><small>'+pct.toFixed(1)+'% dari total unit kerja</small>';
      if(typeof clientX==='number')placeTooltip(clientX,clientY);
      tooltip.classList.add('is-visible');
      if(makeSticky)sticky=true;
      if(ring)ring.classList.add('is-chart-active');
      qsa('.ct-donut-legend-row',legend).forEach(function(row,i){row.classList.toggle('is-active',i===index)});
    }
    function hideTip(force){
      if(sticky&&!force)return;
      sticky=false;activeIndex=-1;tooltip.classList.remove('is-visible');
      if(ring)ring.classList.remove('is-chart-active');
      qsa('.ct-donut-legend-row',legend).forEach(function(row){row.classList.remove('is-active')});
    }
    function partAt(clientX,clientY){
      if(!ring||!currentParts.length||currentTotal<=0)return -1;
      var r=ring.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2,dx=clientX-cx,dy=clientY-cy;
      var dist=Math.sqrt(dx*dx+dy*dy), outer=r.width/2, inner=outer*.64;
      if(dist<inner||dist>outer)return -1;
      var deg=(Math.atan2(dy,dx)*180/Math.PI+450)%360, pct=deg/360*100,acc=0;
      for(var i=0;i<currentParts.length;i++){
        acc+=(Number(currentParts[i].value||0)/currentTotal)*100;
        if(pct<=acc+0.0001)return i;
      }
      return currentParts.length-1;
    }
    function select(id){
      sticky=false;hideTip(true);
      var item=data[String(id)]; if(!item)return;
      buttons.forEach(function(b){b.classList.toggle('is-active',b.getAttribute('data-ct-unit')===String(id))});
      if(unitEl)unitEl.textContent=item.name||'-';
      if(totalEl)totalEl.textContent=idNum(item.total);
      var parts=(item.providers||[]).filter(function(p){return Number(p.value||0)>0});
      var total=Number(item.total||0); currentParts=parts;currentTotal=total;
      if(!parts.length || total<=0){
        if(ring)ring.style.background='#e7edf1';
        if(legend)legend.innerHTML='<div class="ct-help">Belum ada nilai pada periode ini.</div>';
        return;
      }
      var stops=[],acc=0;
      parts.forEach(function(p,i){
        var pct=(Number(p.value||0)/total)*100, start=acc, end=acc+pct; acc=end;
        stops.push(palette[i%palette.length]+' '+start.toFixed(2)+'% '+end.toFixed(2)+'%');
      });
      if(ring)ring.style.background='conic-gradient('+stops.join(',')+')';
      if(legend){
        legend.innerHTML='';
        parts.forEach(function(p,i){
          var pct=total?Number(p.value||0)/total*100:0;
          var row=document.createElement('div'); row.className='ct-donut-legend-row'; row.setAttribute('data-part-index',String(i));
          row.innerHTML='<i></i><span></span><b></b><small></small>';
          qs('i',row).style.background=palette[i%palette.length];
          qs('span',row).textContent=p.name;
          qs('b',row).textContent=idNum(p.value);
          qs('small',row).textContent=pct.toFixed(1)+'%';
          row.addEventListener('mouseenter',function(e){if(!sticky)showPart(i,e.clientX,e.clientY,false)});
          row.addEventListener('mousemove',function(e){if(!sticky)placeTooltip(e.clientX,e.clientY)});
          row.addEventListener('mouseleave',function(){hideTip(false)});
          row.addEventListener('click',function(e){e.stopPropagation();sticky=(activeIndex===i)?!sticky:true;if(sticky)showPart(i,e.clientX,e.clientY,true);else hideTip(true)});
          legend.appendChild(row);
        });
      }
    }
    if(ring){
      ring.addEventListener('mousemove',function(e){if(sticky)return;var i=partAt(e.clientX,e.clientY);if(i>=0)showPart(i,e.clientX,e.clientY,false);else hideTip(false)});
      ring.addEventListener('mouseleave',function(){hideTip(false)});
      ring.addEventListener('click',function(e){var i=partAt(e.clientX,e.clientY);if(i<0){hideTip(true);return} if(sticky&&activeIndex===i){hideTip(true)}else{sticky=true;showPart(i,e.clientX,e.clientY,true)}});
    }
    document.addEventListener('click',function(e){if(sticky&&!panel.contains(e.target))hideTip(true)});
    buttons.forEach(function(b){b.addEventListener('click',function(){select(b.getAttribute('data-ct-unit'))})});
    var selected=panel.getAttribute('data-selected') || Object.keys(data)[0];
    if(selected)select(selected);
  }

  function escapeHtml(v){
    return String(v==null?'':v).replace(/[&<>'"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c]});
  }

  function renderChart(el){
    var series={}; try{series=JSON.parse(el.getAttribute('data-series')||'{}')}catch(e){return}
    var years=Object.keys(series); if(!years.length)return;
    var tooltipLabel=el.getAttribute('data-tooltip-label')||'Total pembayaran klaim';
    var w=1100,h=320,p={l:64,r:24,t:34,b:44};
    var all=[]; years.forEach(function(y){all=all.concat(series[y].map(Number))});
    var max=Math.max.apply(null,all.concat([1])); max=Math.ceil(max/1000)*1000;
    var ns='http://www.w3.org/2000/svg'; var svg=document.createElementNS(ns,'svg'); svg.setAttribute('viewBox','0 0 '+w+' '+h);
    var tooltip=document.createElement('div');tooltip.className='ct-chart-tooltip';var sticky=false,active=null;
    function place(clientX,clientY){var box=el.getBoundingClientRect();tooltip.style.left=Math.max(80,Math.min(box.width-80,clientX-box.left))+'px';tooltip.style.top=Math.max(48,Math.min(box.height-6,clientY-box.top))+'px'}
    function show(rect,year,month,value,e,makeSticky){
      if(active&&active!==rect)active.classList.remove('is-active');active=rect;rect.classList.add('is-active');
      tooltip.innerHTML='<strong>'+escapeHtml(year)+' · '+escapeHtml(['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des'][month])+'</strong><span>'+escapeHtml(tooltipLabel)+'</span><b>IDR '+idNum(value)+' juta</b>';
      if(e)place(e.clientX,e.clientY);tooltip.classList.add('is-visible');if(makeSticky)sticky=true;
    }
    function hide(force){if(sticky&&!force)return;sticky=false;tooltip.classList.remove('is-visible');if(active){active.classList.remove('is-active');active=null}}
    for(var g=0;g<=4;g++){
      var gy=p.t+(h-p.t-p.b)*(g/4); var line=document.createElementNS(ns,'line'); line.setAttribute('x1',p.l);line.setAttribute('x2',w-p.r);line.setAttribute('y1',gy);line.setAttribute('y2',gy);line.setAttribute('stroke','#dfe5ea');svg.appendChild(line);
      var txt=document.createElementNS(ns,'text');txt.setAttribute('x',4);txt.setAttribute('y',gy+4);txt.setAttribute('font-size','12');txt.setAttribute('fill','#6d7983');txt.textContent=Math.round(max*(1-g/4)).toLocaleString('id-ID');svg.appendChild(txt);
    }
    var plotW=w-p.l-p.r, groupW=plotW/12, barW=Math.min(18,(groupW-10)/Math.max(1,years.length));
    var fills=['#378bea','#ef4738','#20a36a','#8e5bd2'];
    for(var m=0;m<12;m++){
      years.forEach(function(y,yi){
        var v=Number(series[y][m]||0),bh=(h-p.t-p.b)*(v/max),x=p.l+m*groupW+(groupW-years.length*barW)/2+yi*barW;
        var rect=document.createElementNS(ns,'rect');rect.setAttribute('x',x);rect.setAttribute('y',h-p.b-bh);rect.setAttribute('width',barW-2);rect.setAttribute('height',bh);rect.setAttribute('rx','1.5');rect.setAttribute('fill',fills[yi%fills.length]);rect.setAttribute('data-ct-bar','1');
        var title=document.createElementNS(ns,'title');title.textContent=y+' / bulan '+(m+1)+': '+v.toLocaleString('id-ID')+' juta';rect.appendChild(title);
        rect.addEventListener('mouseenter',function(e){if(!sticky)show(rect,y,m,v,e,false)});
        rect.addEventListener('mousemove',function(e){if(!sticky)place(e.clientX,e.clientY)});
        rect.addEventListener('mouseleave',function(){hide(false)});
        rect.addEventListener('click',function(e){e.stopPropagation();if(sticky&&active===rect){hide(true)}else{sticky=true;show(rect,y,m,v,e,true)}});
        svg.appendChild(rect)
      });
      var label=document.createElementNS(ns,'text');label.setAttribute('x',p.l+m*groupW+groupW/2);label.setAttribute('y',h-12);label.setAttribute('text-anchor','middle');label.setAttribute('font-size','11');label.setAttribute('fill','#58656f');label.textContent=['JAN','FEB','MAR','APR','MEI','JUN','JUL','AGS','SEP','OKT','NOV','DES'][m];svg.appendChild(label);
    }
    years.forEach(function(y,yi){var x=380+yi*85;var r=document.createElementNS(ns,'rect');r.setAttribute('x',x);r.setAttribute('y',7);r.setAttribute('width',10);r.setAttribute('height',10);r.setAttribute('fill',fills[yi%fills.length]);svg.appendChild(r);var t=document.createElementNS(ns,'text');t.setAttribute('x',x+15);t.setAttribute('y',16);t.setAttribute('font-size','12');t.setAttribute('fill','#56616a');t.textContent=y;svg.appendChild(t)});
    el.innerHTML='';el.appendChild(svg);el.appendChild(tooltip);
    document.addEventListener('click',function(e){if(sticky&&!el.contains(e.target))hide(true)});
  }

})();


// v1.21.3 nominative demo
document.addEventListener('click',function(e){
 var b=e.target.closest('.ct-kdp-nominative-button');
 if(!b)return;
 var r=document.getElementById('ct-kdp-nominative-result');
 if(!r)return;
 r.classList.add('is-open');
 var unit=b.getAttribute('data-kdp-unit-name')||'';
 var title=r.querySelector('strong');
 if(title){title.textContent='Data Debitur KDP - '+unit;}
 r.querySelectorAll('tbody tr[data-kdp-unit]').forEach(function(row){
   row.style.display=(unit===''||row.getAttribute('data-kdp-unit')===unit)?'':'none';
 });
});
